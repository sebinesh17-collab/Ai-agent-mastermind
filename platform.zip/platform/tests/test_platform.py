"""Platform test suite. Runs against an isolated temporary data root.

    python3 -m unittest discover -s tests -v        (from the platform root)

Covers: agent registry counts and field completeness, model discovery and
routing, orchestration graph semantics, generated-site build and checks,
localization honesty, feedback pipeline, maintenance/rollback, path isolation
and secret handling.
"""
from __future__ import annotations

import os
import shutil
import tempfile
import unittest

TMP_ROOT = tempfile.mkdtemp(prefix="nvidia-wep-tests-")
os.environ["PLATFORM_DATA_DIR"] = TMP_ROOT
# copy the catalogue snapshot so offline refresh still has data
os.makedirs(TMP_ROOT, exist_ok=True)

from app import (agent_data, db, engines, generation, models, orchestrator,  # noqa: E402
                 registry, skills as skill_catalog, util, verify)


def setUpModule() -> None:
    snapshot = util.ROOT / "assets" / "nvidia_catalog_snapshot.json"
    if snapshot.exists():
        shutil.copy(snapshot, os.path.join(TMP_ROOT, "nvidia_catalog_snapshot.json"))
    db.init_db()
    models.refresh_models()
    registry.generate_registry(force=True)


def tearDownModule() -> None:
    shutil.rmtree(TMP_ROOT, ignore_errors=True)


def make_project(prompt: str, name: str = "Test Site") -> dict:
    db.insert("projects", {
        "id": util.new_id("prj_"), "name": name, "prompt": prompt, "ptype": "services",
        "industry": "Services", "status": "intake", "active_version": 0, "brief_json": "{}",
        "requirements_json": "{}", "plan_json": "{}", "research_json": "{}", "resources_json": "{}",
        "arch_json": "{}", "design_json": "{}", "stack_json": "{}", "acceptance_json": "{}",
        "deploy_json": "{}", "blueprint_json": "{}", "created_at": util.now_iso(),
        "updated_at": util.now_iso(),
    })
    return dict(db.query("SELECT * FROM projects ORDER BY created_at DESC LIMIT 1")[0])


def run_to_completion(project: dict, kind: str = "full_build", payload: dict | None = None,
                      approve: bool = True, limit: int = 90) -> tuple[str, list[dict]]:
    result = orchestrator.start_run(project, kind, payload or {})
    run_id = result["run_id"]
    import time
    for _ in range(limit):
        time.sleep(0.5)
        run = db.query_one("SELECT status FROM runs WHERE id=?", (run_id,))
        if run["status"] in {"succeeded", "succeeded_with_warnings", "failed", "cancelled"}:
            break
        if run["status"] == "awaiting_approval" and approve:
            for task in db.query("SELECT id FROM tasks WHERE run_id=? AND status='awaiting_approval'", (run_id,)):
                orchestrator.approve_task(task["id"])
    tasks = [dict(t) for t in db.query("SELECT * FROM tasks WHERE run_id=? ORDER BY seq", (run_id,))]
    return run_id, tasks


# ---------------------------------------------------------------------------


class TestAgentRegistry(unittest.TestCase):
    def test_exact_counts(self):
        stats = registry.registry_stats()
        self.assertEqual(stats["total"], 1050, "registry must contain exactly 1,050 roles")
        self.assertEqual(stats["core"], 1000)
        self.assertEqual(stats["extension"], 50)
        self.assertEqual(stats["department_count"], 25)

    def test_every_department_has_forty_roles(self):
        for dept in registry.registry_stats()["departments"]:
            self.assertEqual(dept["roles"], 40, f"{dept['department']} must have 40 roles")

    def test_validation_report_passes(self):
        report = registry.validate_records(registry.build_records())
        self.assertTrue(report["ok"], f"registry validation failed: {report['errors']}")
        self.assertEqual(report["counts"]["unavailable_model_capabilities"], [])

    def test_identifiers_and_names_unique(self):
        ids = [r[0] for r in db.query("SELECT id FROM agents")]
        names = [r[0] for r in db.query("SELECT name FROM agents")]
        self.assertEqual(len(ids), len(set(ids)))
        self.assertEqual(len(names), len(set(names)))

    def test_every_record_has_all_required_fields(self):
        for row in db.query("SELECT * FROM agents"):
            agent = registry.db_row_to_dict(row)
            for field in registry.REQUIRED_FIELDS:
                value = agent.get(field)
                self.assertNotIn(value, (None, "", [], {}), f"{agent['id']}.{field} is empty")

    def test_tool_and_skill_references_resolve(self):
        for row in db.query("SELECT * FROM agents"):
            agent = registry.db_row_to_dict(row)
            for tool in agent["tools"]:
                self.assertIn(tool["tool"], skill_catalog.TOOLS)
            for skill in agent["skills"]["refs"]:
                registered = skill["id"] in skill_catalog.SKILLS
                explicitly_pending = skill["status"] in {"derived_pending_review", "pending"}
                self.assertTrue(registered or explicitly_pending, f"unresolved skill {skill['id']}")

    def test_agents_are_searchable(self):
        result = registry.list_agents(search="accessibility", limit=5)
        self.assertGreater(result["total"], 0)

    def test_department_names_match_specification(self):
        expected = {d["name"] for d in agent_data.DEPARTMENTS}
        actual = {r["department"] for r in db.query("SELECT DISTINCT department FROM agents WHERE group_type='core'")}
        self.assertEqual(expected, actual)


class TestModelRegistry(unittest.TestCase):
    def test_catalogue_discovered(self):
        stats = models.registry_stats()
        self.assertGreater(stats["catalog_present"], 10, "expected the NVIDIA catalogue to provide models")

    def test_capability_routing_returns_candidates(self):
        for capability in ["Complex planning", "Code generation", "Translation", "Image understanding",
                           "Semantic search", "Classification"]:
            cands = models.candidates_for(capability, limit=3)
            self.assertTrue(cands, f"no candidates for {capability}")
            for cand in cands:
                row = db.query_one("SELECT * FROM models WHERE id=?", (cand["model_id"],))
                self.assertIn(capability, util.jload(row["capabilities_json"], []))

    def test_routing_decision_is_recorded(self):
        decision = models.route("Code generation", run_id="test-run", task_id="test-task")
        self.assertTrue(decision["chosen_model"])
        row = db.query_one("SELECT * FROM routing_decisions ORDER BY id DESC LIMIT 1")
        self.assertEqual(row["chosen_model"], decision["chosen_model"])
        self.assertTrue(row["reason"])

    def test_unverified_call_is_honest_without_key(self):
        db.set_setting("nvidia_api_key", "")
        result = models.health_check("z-ai/glm-5.3")
        self.assertFalse(result["ok"])
        self.assertEqual(result["status"], "blocked_no_api_key")
        invoke = models.invoke("z-ai/glm-5.3", [{"role": "user", "content": "hi"}])
        self.assertFalse(invoke["ok"])
        self.assertEqual(invoke["status"], "blocked_no_api_key")

    def test_spec_candidates_map_to_real_catalogue_ids(self):
        catalogue = {row["id"] for row in db.query("SELECT id FROM models WHERE catalog_present=1")}
        for spec_name, live_id in models.SPEC_CANDIDATES.items():
            self.assertIn(live_id, catalogue, f"spec candidate {spec_name} -> {live_id} not in catalogue")

    def test_no_model_is_claimed_as_freely_available(self):
        for row in db.query("SELECT * FROM models WHERE catalog_present=1"):
            self.assertIn("key", (row["access_restrictions"] or "").lower() + (row["usage_limits"] or "").lower())


class TestGenerationAndVerification(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.project = make_project(
            "A dental clinic in Coimbatore called Test Smile that needs services, team, FAQ and a booking form.",
            "Test Smile")
        cls.run_id, cls.tasks = run_to_completion(cls.project, "full_build")
        cls.root = util.PROJECTS_DIR / cls.project["id"] / "v1"
        cls.report = util.jload((cls.root / "checks" / "verification_report.json").read_text(), {})

    def test_run_succeeds(self):
        run = db.query_one("SELECT status FROM runs WHERE id=?", (self.run_id,))
        self.assertIn(run["status"], {"succeeded", "succeeded_with_warnings"})

    def test_no_task_failed(self):
        failed = [t for t in self.tasks if t["status"] == "failed"]
        self.assertEqual([t["name"] for t in failed], [])

    def test_every_task_has_an_agent_and_routing_reason(self):
        for task in self.tasks:
            self.assertTrue(task["agent_id"], f"{task['name']} has no agent assigned")
            self.assertTrue(task["model_reason"], f"{task['name']} has no routing reason recorded")

    def test_site_files_generated(self):
        for name in ("index.html", "services.html", "team.html", "contact.html"):
            self.assertTrue((self.root / "site" / name).exists(), f"{name} missing")
        self.assertTrue((self.root / "site" / "css" / "styles.css").exists())
        self.assertTrue((self.root / "site" / "js" / "main.js").exists())
        self.assertTrue((self.root / "site" / "sitemap.xml").exists())

    def test_real_build_executes(self):
        build = verify.run_build(self.root)
        self.assertTrue(build["exit_code"] == 0, f"build failed: {build['stdout']} {build['stderr']}")
        self.assertTrue((self.root / "dist" / "manifest.json").exists())

    def test_verification_report_passes(self):
        self.assertTrue(self.report, "no verification report written")
        self.assertEqual(self.report["totals"]["blockers"], 0)
        self.assertEqual(self.report["totals"]["majors"], 0)
        self.assertEqual(self.report["verdict"], "pass")

    def test_generated_pages_have_required_structure(self):
        pages = verify.parse_pages(self.root)
        self.assertGreaterEqual(len(pages), 3)
        for rel, page in pages.items():
            parser = page["parser"]
            self.assertEqual(sum(1 for lvl, _ in parser.headings if lvl == 1), 1, f"{rel}: h1 count")
            self.assertTrue(parser.html_attrs.get("lang"), f"{rel}: lang attribute")
            self.assertFalse(parser.inline_handlers, f"{rel}: inline handlers present")

    def test_no_placeholder_text_leaks_as_final_copy(self):
        for path in (self.root / "site").rglob("*.html"):
            text = path.read_text(encoding="utf-8").lower()
            self.assertNotIn("lorem ipsum", text)

    def test_export_package_contains_site(self):
        result = engines.export_version(self.project["id"])
        self.assertTrue(result["ok"], result.get("detail"))
        import zipfile
        with zipfile.ZipFile(result["zip"]) as zf:
            names = zf.namelist()
        self.assertIn("site/index.html", names)
        self.assertIn("README.md", names)
        self.assertEqual(len(names), len(set(names)), "export must not contain duplicate entries")


class TestOrchestrationSemantics(unittest.TestCase):
    def test_task_graph_is_acyclic(self):
        graph = orchestrator.graph_for("full_build", {})
        keys = [g["key"] for g in graph]
        self.assertEqual(len(keys), len(set(keys)))
        for i, task in enumerate(graph):
            for dep in task.get("deps", []):
                self.assertIn(dep, keys)
                self.assertLess(keys.index(dep), i, "dependencies must precede their dependants")

    def test_failed_dependency_blocks_only_its_branch(self):
        project = make_project("A bakery called Branch Test needing menu, hours and contact.", "Branch Test")
        run_id, tasks = run_to_completion(project, "full_build")
        statuses = {t["status"] for t in tasks}
        self.assertTrue(statuses & {"done"})
        self.assertTrue(all(s in {"done", "skipped_blocked", "failed", "skipped"} for s in statuses))

    def test_deploy_requires_human_approval(self):
        project = make_project("A studio called Gate Test needing a portfolio site.", "Gate Test")
        run_id, tasks = run_to_completion(project, "full_build")
        result = orchestrator.start_run(project, "deploy", {})
        import time
        import time as _t
        gated = []
        for _ in range(60):
            _t.sleep(0.5)
            gated = [dict(t) for t in db.query(
                "SELECT * FROM tasks WHERE run_id=? AND status='awaiting_approval'", (result["run_id"],))]
            if gated:
                break
        self.assertTrue(gated, "deploy task must pause for approval")
        orchestrator.approve_task(gated[0]["id"])
        for _ in range(60):
            _t.sleep(0.5)
            run = db.query_one("SELECT status FROM runs WHERE id=?", (result["run_id"],))
            if run["status"] in {"succeeded", "succeeded_with_warnings", "failed"}:
                break
        self.assertIn(run["status"], {"succeeded", "succeeded_with_warnings"})

    def test_deployment_is_not_claimed_as_executed(self):
        project = make_project("A studio called Deploy Honesty needing a site.", "Deploy Honesty")
        run_to_completion(project, "full_build")
        run_id, tasks = run_to_completion(project, "deploy")
        deploy_task = [t for t in tasks if t["name"].lower().startswith("execute deployment")][0]
        self.assertEqual(deploy_task["status"], "skipped_blocked")
        self.assertIn("not executed", deploy_task["error"].lower() + deploy_task["output_json"].lower())


class TestLocalization(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.project = make_project("A clinic called Locale Test needing services and contact pages.", "Locale Test")
        run_to_completion(cls.project, "full_build")
        cls.root = util.PROJECTS_DIR / cls.project["id"] / "v1"

    def test_glossary_translation_produces_locale_files(self):
        result = engines.translate_project(self.project, self.root, "ta")
        self.assertTrue(result["ok"])
        self.assertGreater(result["coverage"], 0)
        self.assertTrue((self.root / "locales" / "ta" / "index.html").exists())
        self.assertTrue((self.root / "locales" / "ta" / "missing.json").exists())

    def test_coverage_is_reported_not_invented(self):
        result = engines.translate_project(self.project, self.root, "hi")
        self.assertLess(result["coverage"], 100, "curated glossary cannot cover all copy")
        self.assertGreater(result["pending"], 0)
        self.assertIn(result["status"], {"partial", "blocked_insufficient_coverage"})
        self.assertIn("no NVIDIA API key", result["detail"])

    def test_lang_attribute_is_updated(self):
        result = engines.translate_project(self.project, self.root, "ta")
        html = (self.root / result["artifact_dir"] / "index.html").read_text(encoding="utf-8")
        self.assertIn('<html lang="ta"', html)

    def test_rtl_locale_sets_direction(self):
        engines.translate_project(self.project, self.root, "ar")
        html = (self.root / "locales" / "ar" / "index.html").read_text(encoding="utf-8")
        self.assertIn('dir="rtl"', html)

    def test_unsupported_language_reports_zero_coverage(self):
        result = engines.translate_project(self.project, self.root, "ja")
        self.assertEqual(result["coverage"], 0.0)
        self.assertEqual(result["status"], "blocked_insufficient_coverage")


class TestFeedbackAndMaintenance(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.project = make_project("A shop called Feedback Test needing products and contact.", "Feedback Test")
        run_to_completion(cls.project, "full_build")

    def test_feedback_is_classified_and_redacted(self):
        result = engines.analyze_feedback(self.project["id"],
                                          "The checkout is broken and confusing. Call me on +91 90000 11111 or m@example.com")
        self.assertEqual(result["category"], "bug")
        self.assertEqual(result["priority"], "high")
        self.assertNotIn("m@example.com", result["text"])
        self.assertTrue(util.jload(result["analysis_json"])["redactions"])

    def test_feedback_becomes_a_real_run(self):
        result = engines.analyze_feedback(self.project["id"], "Please add a language switcher for Tamil visitors.")
        converted = engines.feedback_to_task(result["id"])
        self.assertTrue(converted["ok"])
        run_id, tasks = run_to_completion(self.project, "feedback_improvement", {"feedback_id": result["id"]})
        improve = [t for t in tasks if "bounded improvement" in t["name"].lower()][0]
        self.assertEqual(improve["status"], "done")
        root = util.PROJECTS_DIR / self.project["id"] / f"v{db.query_one('SELECT MAX(version) v FROM project_versions WHERE project_id=?', (self.project['id'],))['v']}"
        self.assertTrue((root / "IMPROVEMENTS.md").exists())

    def test_duplicate_feedback_detected(self):
        text = "The menu page takes too long to load on my phone."
        engines.analyze_feedback(self.project["id"], text)
        again = engines.analyze_feedback(self.project["id"], text + " Also on tablet.")
        self.assertTrue(again["duplicate_of"])

    def test_monitors_open_incidents_and_repair_plan(self):
        result = engines.run_monitors(self.project["id"])
        self.assertTrue(result["ok"])
        incidents = db.query("SELECT * FROM incidents WHERE project_id=? AND status='open'", (self.project["id"],))
        self.assertTrue(incidents, "placeholder launch blockers should raise an incident")
        plan = engines.incident_repair_plan(self.project["id"])
        self.assertGreater(plan["open_incidents"], 0)
        self.assertTrue(plan["plan"][0]["recommended_actions"])

    def test_rollback_moves_to_previous_version(self):
        check_root = util.PROJECTS_DIR / self.project["id"] / f"v{db.query_one('SELECT MAX(version) v FROM project_versions WHERE project_id=?', (self.project['id'],))['v']}"
        result = engines.rollback_project(self.project["id"])
        self.assertTrue(result["ok"], result.get("detail", ""))
        active = db.query_one("SELECT active_version FROM projects WHERE id=?", (self.project["id"],))["active_version"]
        self.assertEqual(active, result["to_version"])

    def test_marketing_never_claims_publication(self):
        result = engines.marketing_assets(self.project)
        self.assertNotEqual(result["publishing"]["state"], "ready")
        for asset in result["assets"]:
            self.assertEqual(asset["status"], "ready_for_review")

    def test_media_reports_missing_encoder(self):
        result = engines.media_assets(self.project)
        self.assertTrue(result["artifacts"])
        self.assertIn(result["status"], {"blocked_no_encoder", "ready_to_render"})
        if result["status"] == "blocked_no_encoder":
            self.assertIn("not installed", result["detail"])

    def test_email_states_outbox_mode_when_unconfigured(self):
        db.set_setting("smtp_host", "")
        result = engines.email_send(self.project["id"], "owner@example.com", "Test", "Body")
        self.assertEqual(result["status"], "queued_in_outbox")
        self.assertIn("not configured", result["detail"])


class TestIsolationAndSecrets(unittest.TestCase):
    def test_safe_join_blocks_traversal(self):
        root = util.PROJECTS_DIR / "iso-test"
        root.mkdir(parents=True, exist_ok=True)
        for bad in ("../escape.txt", "../../etc/passwd", "a/../../b.txt"):
            with self.assertRaises(ValueError):
                util.safe_join(root, bad)

    def test_secrets_never_returned_by_settings_api(self):
        db.set_setting("nvidia_api_key", "nvapi-secret-value-should-never-be-returned")
        masked = db.get_settings(masked=True)
        self.assertEqual(masked["nvidia_api_key"], "")
        self.assertTrue(masked["nvidia_api_key_present"])
        self.assertNotIn("nvapi-secret-value-should-never-be-returned", util.jdump(masked))
        db.set_setting("nvidia_api_key", "")

    def test_secret_meta_is_masked(self):
        db.set_setting("nvidia_api_key", "nvapi-abcdefghijklmnop")
        row = db.query_one("SELECT * FROM secrets_meta WHERE key='nvidia_api_key'")
        self.assertNotIn("abcdefghijklmnop", row["masked"])
        db.set_setting("nvidia_api_key", "")

    def test_generator_refuses_to_escape_version_root(self):
        """A malicious blueprint page path must not be able to write outside the version root."""
        from unittest import mock
        project = make_project("A cafe called Iso Test needing menu and contact.", "Iso Test")
        root = util.PROJECTS_DIR / project["id"] / "v1"
        root.mkdir(parents=True, exist_ok=True)
        blueprint = generation.build_blueprint(project)
        blueprint["pages"].append({"slug": "escape", "title": "Escape", "file": "../../escape.html"})
        with mock.patch.object(generation, "build_blueprint", return_value=blueprint):
            with self.assertRaises(ValueError):
                generation.generate_project_files(project, root)
        self.assertFalse((util.PROJECTS_DIR / project["id"] / "escape.html").exists())

    def test_ledger_covers_every_capability_state(self):
        rows = db.query("SELECT DISTINCT status_code FROM ledger")
        codes = {r["status_code"] for r in rows}
        self.assertTrue(codes.issubset({1, 2, 3, 4, 5}))
        self.assertIn(1, codes, "at least one capability must be implemented and verified")


if __name__ == "__main__":
    unittest.main(verbosity=2)
