# Architecture

## 1. Shape of the system

```
                      ┌──────────────────────────────────────────────┐
   browser console ──▶│ FastAPI service (app/server.py)              │
   /static/index.html │  REST API · console UI · site preview routes │
                      └───────────────┬──────────────────────────────┘
                                      │
        ┌─────────────────────────────┼───────────────────────────────────┐
        ▼                             ▼                                   ▼
┌────────────────┐          ┌──────────────────┐               ┌────────────────────┐
│ Orchestrator   │          │ Agent registry   │               │ Model registry     │
│ DAG + workers  │◀────────▶│ 1,050 roles      │◀─────────────▶│ discovery/routing  │
│ checkpoints    │          │ (app/registry.py)│               │ (app/models.py)    │
└───────┬────────┘          └──────────────────┘               └─────────┬──────────┘
        │                                                               │
        ▼                                                               ▼
┌──────────────────────────────────────┐                    ┌───────────────────────┐
│ Department engines (app/engines.py)  │                    │ NVIDIA catalogue      │
│ intake·planning·research·resources·  │                    │ /v1/models (discovery)│
│ licensing·architecture·design·       │                    │ /v1/chat/completions  │
│ feedback·localization·maintenance·   │                    │ (requires API key)    │
│ marketing·media·email·deployment     │                    └───────────────────────┘
└───────┬──────────────────────────────┘
        │
        ├──────────▶ Generation (app/generation.py) ──▶ project version on disk (site/, build, checks)
        └──────────▶ Verification (app/verify.py) ────▶ build subprocess + 119 deterministic checks
```

Persistence is SQLite (`data/platform.db`); project versions are plain directories
(`data/projects/<project_id>/v<n>/`). Both are deliberately inspectable: a reviewer can read the
database, read the generated files and re-run every check.

## 2. Data model (SQLite)

| Table | Purpose |
| --- | --- |
| `settings`, `secrets_meta` | Configuration; secrets stored locally, never returned unmasked |
| `projects` | Prompt, extracted brief, requirements, plan, research, resources, architecture, design, acceptance, blueprint |
| `project_versions` | Immutable version records with root path, manifest and latest test totals |
| `runs`, `tasks`, `task_logs` | Orchestration state; the tasks table **is** the checkpoint store |
| `agent_runs` | One row per agent execution: model, timings, summary, error |
| `artifacts` | Every file the platform produced, with path, size and SHA-256 |
| `agents`, `skills`, `tools` | The 1,050-role registry and its reference catalogues |
| `models`, `routing_decisions` | Model registry and an auditable reason for every routing choice |
| `resources` | Open-source resources with source URL, licence, verification method, adopted/rejected |
| `feedback` | Feedback with category, sentiment, priority, duplicate link, redacted text, status |
| `localization_jobs` | Per-locale jobs with coverage, engine, QA checks, artifact paths |
| `incidents`, `monitor_checks` | Maintenance findings and their resolution workflow |
| `marketing_assets`, `email_messages` | Draft marketing artifacts; outbound messages and their real delivery status |
| `ledger`, `audit_log` | Capability status codes (1–5) and an append-only action log |

## 3. Orchestration

1. `start_run(project, kind, payload)` inserts a `runs` row and one task row per graph node.
2. A daemon thread (`_execute_run`) loops: find tasks whose dependencies are satisfied, dispatch up
   to `max_parallel_tasks` concurrently, persist each result, repeat. The loop is bounded (60
   rounds) so it can never spin forever.
3. Failure semantics: a failed task blocks **only its dependants** (`skipped_blocked` with the
   reason); independent branches still complete. Successful results are never discarded.
4. High-impact tasks (`deploy_execute`, `publish`, `rollback`) enter `awaiting_approval` and wait for
   an explicit user action via `POST /api/tasks/{id}/approve`.
5. Cancellation sets a flag on the run and the worker; running tasks finish, pending tasks do not start.
6. Checkpoints live in the database, so an interrupted process resumes at boot
   (`resume_interrupted_runs`).

Task graphs: `full_build` (17 tasks), `feedback_improvement` (6), `maintenance` (3), `deployment`
(2, gated), `translation`, `marketing`, `media`, `clarification`, `export`.

## 4. Model routing

- Discovery: `GET {base}/models` (no credential) → 80 catalogue entries → classification into 21
  capability categories using a curated knowledge table for known identifiers plus an explicit
  `catalog_present_unclassified` state for anything unknown (never assumed).
- Routing: `models.route(capability, …)` ranks candidates from a deterministic routing table,
  filters to catalogue-present models with the required capability (and vision modality where
  needed), then records the decision, the reason and the alternatives in `routing_decisions`.
- Execution: `models.invoke()` performs a real HTTPS call with retries, exponential backoff and
  audit logging that excludes credentials. No key → an explicit `blocked_no_api_key` result.

## 5. Generation and verification contract

Each version is a self-contained project:

```
site/            deployable static site (pages, css, js, assets, sitemap.xml, robots.txt)
content/         content.json, requirements.json, blueprint.json, architecture.json, roadmap.json
build.mjs        Node build: validates pages, minifies into dist/, writes dist/manifest.json
build.py         pure-Python fallback build
tests/checks.mjs deterministic page checks (links, ids, labels, structural requirements)
checks/          verification_report.json + .txt (per version)
checklists/      launch checklist
NOTICE.md        third-party notices with licence status
DEPLOYMENT.md    deployment plan and per-target commands
locales/<lang>/  translated pages, strings.json, missing.json
```

Verification categories and representative rules:

| Category | Examples |
| --- | --- |
| build | real subprocess exit code |
| application | page count, title, single `h1`, unique ids, no inline handlers, internal links resolve, assets exist, sitemap completeness |
| accessibility | `lang`, alt text, width/height, labelled inputs, heading order, descriptive link text, zoomable viewport |
| seo | title/description lengths, canonical, Open Graph, JSON-LD parses, word count |
| security | secret patterns, `noopener`, no plain-HTTP resources, no `eval`/`document.write`/remote scripts |
| performance | total and per-page payload budgets, local-only stylesheet, deferred scripts, CSS size, dist manifest |
| data & docs | structured content present, requirements snapshot, README documents the build command |

Repair rules map specific check codes to deterministic fixes (regenerate missing page, rewrite
sitemap, re-render pages from blueprint + content). Everything else is returned for human review.

## 6. Isolation and safety

- `util.safe_join` guards every generated write and every file-serving route; traversal attempts raise
  and are covered by tests.
- Generated code is never executed; only the project's own build script runs, as a subprocess with a
  timeout, inside the project version directory. No generated artefact is executed as the platform.
- Secrets: stored in the local database, never returned by the API, masked in `secrets_meta`, and
  excluded from model request logs.
- Publishing/deployment actions require explicit authorization flags set by the user.

## 7. Extension points

- **Add a department or role:** extend `app/agent_data.py`, regenerate the registry; validation
  enforces the exact 40-per-department and 1,050-total rules.
- **Add a model:** extend `MODEL_KNOWLEDGE` and `ROUTING_TABLE` in `app/models.py`; discovery keeps
  the catalogue authoritative.
- **Add a workflow:** add a graph to `orchestrator.graph_for` and a handler to `HANDLERS`.
- **Add a check:** add a function to `app/verify.py` and it appears in every future report and gate.
- **Swap persistence:** the SQLite surface is confined to `app/db.py`.
