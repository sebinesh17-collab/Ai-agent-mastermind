// Build: validate pages, then emit a minified dist/ with a manifest.
import { readFileSync, writeFileSync, mkdirSync, readdirSync, statSync } from 'node:fs';
import { join, extname, relative } from 'node:path';
import { createHash } from 'node:crypto';

const root = 'site';
const out = 'dist';
const errors = [];

function walk(dir) {
  return readdirSync(dir).flatMap((entry) => {
    const full = join(dir, entry);
    return statSync(full).isDirectory() ? walk(full) : [full];
  });
}

const minifyCss = (css) => css
  .replace(/\/\*[\s\S]*?\*\//g, '')
  .replace(/\s*([{}:;,>])\s*/g, '$1')
  .replace(/;}/g, '}')
  .replace(/\s+/g, ' ')
  .trim();

const minifyJs = (js) => js
  .replace(/^\s*\/\/.*$/gm, '')
  .replace(/\/\*[\s\S]*?\*\//g, '')
  .replace(/\n\s+/g, '\n')
  .trim();

mkdirSync(out, { recursive: true });
const manifest = { pages: [], assets: [], builtAt: new Date().toISOString() };
let totalBytes = 0;

for (const file of walk(root)) {
  const rel = relative(root, file);
  const ext = extname(file);
  let body = readFileSync(file);
  let outPath = join(out, rel);

  if (ext === '.html') {
    const text = body.toString('utf8');
    if (!/<html[\s>]/i.test(text)) errors.push(`${rel}: missing <html> element`);
    if (!/<title>[^<]{4,}<\/title>/i.test(text)) errors.push(`${rel}: missing or too-short <title>`);
    if (!/name="description"\s+content="[^"]{20,}"/i.test(text)) errors.push(`${rel}: meta description missing or short`);
    if (!/<h1[\s>]/i.test(text)) errors.push(`${rel}: missing <h1>`);
    if (/lorem ipsum/i.test(text)) errors.push(`${rel}: contains placeholder lorem ipsum`);
    const lang = (text.match(/<html[^>]*lang="([^"]+)"/i) || [])[1];
    if (!lang) errors.push(`${rel}: <html> has no lang attribute`);
    const imgs = text.match(/<img\b[^>]*>/gi) || [];
    for (const img of imgs) {
      if (!/\balt=/.test(img)) errors.push(`${rel}: <img> without alt attribute -> ${img.slice(0, 60)}`);
      if (!/\bwidth=|\bheight=/.test(img)) errors.push(`${rel}: <img> without explicit dimensions -> ${img.slice(0, 60)}`);
    }
    if (/\son(click|load|error|mouseover|submit)=/i.test(text)) errors.push(`${rel}: inline event handler found`);
    body = Buffer.from(text.replace(/\n\s*\n/g, '\n'));
    manifest.pages.push({ file: rel, bytes: body.length, sha256: createHash('sha256').update(body).digest('hex') });
  } else if (ext === '.css') {
    body = Buffer.from(minifyCss(body.toString('utf8')));
    manifest.assets.push({ file: rel, bytes: body.length, minified: true });
  } else if (ext === '.js') {
    body = Buffer.from(minifyJs(body.toString('utf8')));
    manifest.assets.push({ file: rel, bytes: body.length, minified: true });
  } else {
    manifest.assets.push({ file: rel, bytes: body.length, minified: false });
  }

  totalBytes += body.length;
  mkdirSync(join(out, rel.split('/').slice(0, -1).join('/') || '.'), { recursive: true });
  writeFileSync(outPath, body);
}

manifest.totalBytes = totalBytes;

if (errors.length) {
  console.error(`BUILD FAILED with ${errors.length} problem(s):`);
  for (const e of errors) console.error(' - ' + e);
  process.exitCode = 1;
} else {
  writeFileSync(join(out, 'manifest.json'), JSON.stringify(manifest, null, 2));
  console.log(`BUILD OK: ${manifest.pages.length} pages, ${manifest.assets.length} assets, ${totalBytes} bytes -> dist/`);
}
