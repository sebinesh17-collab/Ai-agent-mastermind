(function () {
  "use strict";
  var toggle = document.querySelector('.nav-toggle');
  var nav = document.getElementById('site-nav');
  if (toggle && nav) {
    toggle.addEventListener('click', function () {
      var open = nav.classList.toggle('open');
      toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
  }
  var year = document.querySelector('[data-year]');
  if (year) { year.textContent = String(new Date().getFullYear()); }

  var form = document.querySelector('.contact-form');
  if (form) {
    var status = form.querySelector('.form-status');
    form.addEventListener('submit', function (event) {
      event.preventDefault();
      var ok = true;
      ['name', 'email', 'message'].forEach(function (id) {
        var field = form.querySelector('#' + id);
        if (!field) { return; }
        var valid = field.value.trim().length > 1;
        if (id === 'email') { valid = /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(field.value.trim()); }
        field.setAttribute('aria-invalid', valid ? 'false' : 'true');
        if (!valid) { ok = false; }
      });
      status.textContent = ok
        ? 'Thank you. Your enquiry was validated locally. Connect this form to your mail endpoint or CRM before launch.'
        : 'Please correct the highlighted fields and try again.';
      status.style.color = ok ? 'var(--primary)' : '#e5484d';
    });
  }
})();
