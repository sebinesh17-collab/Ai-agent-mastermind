"""Optional pure-Python build (mirrors build.mjs) for environments without Node."""
import hashlib, json, re, shutil
from pathlib import Path

root, out = Path("site"), Path("dist")
errors, manifest = [], {"pages": [], "assets": []}
if out.exists():
    shutil.rmtree(out)

for path in sorted(root.rglob("*")):
    if path.is_dir():
        continue
    rel = path.relative_to(root).as_posix()
    target = out / rel
    target.parent.mkdir(parents=True, exist_ok=True)
    if path.suffix == ".html":
        text = path.read_text(encoding="utf-8")
        if not re.search(r"<title>[^<]{4,}</title>", text):
            errors.append(f"{rel}: missing title")
        if not re.search(r'name="description"\s+content="[^"]{20,}"', text):
            errors.append(f"{rel}: meta description missing")
        if not re.search(r"<h1[\s>]", text):
            errors.append(f"{rel}: missing h1")
        body = re.sub(r"\n\s*\n", "\n", text).encode()
        manifest["pages"].append({"file": rel, "bytes": len(body), "sha256": hashlib.sha256(body).hexdigest()})
    else:
        body = path.read_bytes()
        manifest["assets"].append({"file": rel, "bytes": len(body)})
    target.write_bytes(body)

if errors:
    print("BUILD FAILED:")
    for e in errors:
        print(" -", e)
    raise SystemExit(1)
(out / "manifest.json").write_text(json.dumps(manifest, indent=2))
print(f"BUILD OK: {len(manifest['pages'])} pages, {len(manifest['assets'])} assets -> dist/")
