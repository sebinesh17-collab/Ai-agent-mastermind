# Launch checklist

- [ ] 1. Replace every placeholder value: address, phone, email, opening hours, statistics.
- [ ] 2. Replace the placeholder gallery and team imagery, or remove those sections.
- [ ] 3. Point the contact form at a real endpoint (form service, mailto handler, or your own API).
- [ ] 4. Update absolute URLs (`canonical`, `og:*`, `sitemap.xml`) from `https://example.com` to the live domain.
- [ ] 5. Confirm robots.txt and sitemap.xml are reachable at the domain root.
- [ ] 6. Run `node build.mjs` and confirm exit code 0, then upload `dist/`.
