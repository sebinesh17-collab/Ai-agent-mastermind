// Deterministic page checks: internal links, duplicate ids, headings, forms.
import { readFileSync, readdirSync } from 'node:fs';
import { join } from 'node:path';

const root = 'site';
let failures = 0;
const note = (ok, message) => { console.log((ok ? 'PASS ' : 'FAIL ') + message); if (!ok) failures++; };

const pages = readdirSync(root).filter((f) => f.endsWith('.html'));
const html = Object.fromEntries(pages.map((f) => [f, readFileSync(join(root, f), 'utf8')]));

note(pages.length >= 3, `at least 3 pages generated (found ${pages.length})`);

for (const [file, text] of Object.entries(html)) {
  const ids = [...text.matchAll(/\sid="([^"]+)"/g)].map((m) => m[1]);
  const dupes = ids.filter((id, i) => ids.indexOf(id) !== i);
  note(dupes.length === 0, `${file}: no duplicate ids${dupes.length ? ' -> ' + dupes.join(', ') : ''}`);

  const anchors = [...text.matchAll(/href="([^"#][^"]*?)"/g)].map((m) => m[1]).filter((h) => !/^(https?:|mailto:|tel:)/.test(h));
  const missing = anchors.filter((h) => !pages.includes(h.split('#')[0]));
  note(missing.length === 0, `${file}: all internal links resolve${missing.length ? ' -> ' + missing.join(', ') : ''}`);

  const labels = [...text.matchAll(/<label\s+for="([^"]+)"/g)].map((m) => m[1]);
  note(labels.length > 0, `${file}: form labels present where forms exist`.replace('form labels present where forms exist', labels.length ? 'label/for pairs present' : 'no forms on this page (labels not required)'));
}

for (const [file, text] of Object.entries(html)) {
  const required = ['name="viewport"', 'charset="utf-8"', 'og:title', 'application/ld+json'];
  for (const token of required) {
    note(text.includes(token), `${file}: contains ${token}`);
  }
  break; // structural requirements checked on the entry page; per-page in build.mjs
}

console.log(failures === 0 ? 'CHECKS PASSED' : `CHECKS FAILED (${failures})`);
process.exitCode = failures === 0 ? 0 : 1;
