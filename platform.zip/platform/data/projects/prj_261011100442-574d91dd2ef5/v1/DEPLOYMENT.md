# Deployment plan — Smile Care Dental (v1)

## What ships
- `site/` — the complete static site (HTML, CSS, JS, SVG assets, sitemap.xml, robots.txt)
- `content/` — structured content and requirements used to render the pages
- `build.mjs` / `build.py` — reproducible build
- `checklists/` — launch checklist produced by the platform

## Pre-deployment checklist
1. Replace every placeholder value: address, phone, email, opening hours, statistics.
2. Replace the placeholder gallery and team imagery, or remove those sections.
3. Point the contact form at a real endpoint (form service, mailto handler, or your own API).
4. Update absolute URLs (`canonical`, `og:*`, `sitemap.xml`) from `https://example.com` to the live domain.
5. Confirm robots.txt and sitemap.xml are reachable at the domain root.
6. Run `node build.mjs` and confirm exit code 0, then upload `dist/`.

## Deployment options
| Target | Command / method | Notes |
| --- | --- | --- |
| Static host (Netlify, Cloudflare Pages, Vercel static) | connect repo or drag `dist/` | zero config, add custom domain |
| Object storage + CDN (S3 + CloudFront) | `aws s3 sync dist/ s3://bucket --delete` then invalidate | set `Cache-Control: max-age=31536000` for hashed assets |
| nginx | copy `dist/` to `/var/www/site` | add `charset utf-8;` and gzip/brotli |

## Rollback
Keep the previous `dist/` directory (or object-storage version) — restoring it is a file copy with no database state to reverse.
