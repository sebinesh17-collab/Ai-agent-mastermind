#!/usr/bin/env bash
# Boot the platform: API + console UI on 0.0.0.0:${PORT:-8000}
set -euo pipefail
cd "$(dirname "$0")"

PORT="${PORT:-8000}"

if ! python3 -c "import fastapi, uvicorn" 2>/dev/null; then
  echo "installing dependencies (fastapi, uvicorn, python-multipart)…"
  python3 -m pip install --quiet --disable-pip-version-check fastapi "uvicorn[standard]" python-multipart
fi

echo "starting NVIDIA Multi-Agent Website Engineering Platform on http://0.0.0.0:${PORT}"
exec python3 -m uvicorn app.server:app --host 0.0.0.0 --port "${PORT}"
