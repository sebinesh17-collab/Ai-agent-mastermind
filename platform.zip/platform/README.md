# NVIDIA Multi-Agent Website Engineering and Autonomous Maintenance Platform

Single-user private edition · `1.0.0-single-user` · FastAPI + SQLite + real static-site generation

This is a working platform, not a mockup. It turns a natural-language brief into a real, multi-page,
buildable, verified static website, and then keeps working on it: translation, feedback-driven
improvement, maintenance monitoring, incident handling and packaging for deployment.

Everything the platform claims is backed by files on disk, database rows or command output. Where
something cannot be done in this environment (no NVIDIA API key, no ffmpeg, no hosting target), the
platform says so explicitly instead of simulating success. See `FINAL_REPORT.md` for the full,
evidence-linked status.

---

## Quick start

```bash
cd /home/user/platform
./run.sh                     # installs deps if missing, serves on http://0.0.0.0:8000
```

Open the console, paste a brief such as:

> A dental clinic in Coimbatore called Smile Care that needs a website with services, team, patient
> FAQ and a booking enquiry form. Include Tamil support.

and press **Start full build**. The orchestrator runs a 17-task pipeline — intake, planning,
research, resource discovery, licensing, architecture, design, generation, build, verification,
SEO/performance review, security review, repair, acceptance, documentation and packaging — with a
live task log showing the agent, the model chosen, the reason for that choice, evidence and
artefacts. On first boot the platform also seeds one demo project so the console is never empty.

Other entry points:

```bash
python3 -m unittest discover -s tests -v   # 45 tests against an isolated data root
python3 -m app.report                      # regenerate FINAL_REPORT.md from live state
python3 -m app validate                    # force a registry rebuild + validation
PORT=9000 ./run.sh                         # different port
```

## What it does

| Area | Behaviour |
| --- | --- |
| **Agent registry** | Exactly 1,050 role definitions: 1,000 core roles in 25 departments (40 each) + 50 extension roles (15+15+10+10). Each role carries instructions, responsibilities, skills, eligible models, routing criteria, tool scopes, input/output schemas, dependencies, quality checks, security restrictions, timeout, retry and concurrency policy, approval policy, success criteria and failure format. Validated by tests and at `/api/registry/validate`. |
| **Model registry** | Discovers the live NVIDIA catalogue (80 models, no credential needed for discovery), records capabilities, modalities, tool-calling, deployment mode, access restrictions and verification status. Capability-based routing records every decision with its reason. Inference and health checks require an NVIDIA API key. |
| **Orchestration** | Real workflow engine: dependency graphs, bounded parallel execution, persisted checkpoints, retries with backoff, branch isolation on failure, cancellation, human-approval gates and resume-after-restart. |
| **Website generation** | Multi-page static sites per archetype (clinic, restaurant, portfolio, SaaS, ecommerce, agency, education, services): semantic HTML, design tokens, one small script, generated SVG assets, sitemap, robots, JSON-LD, structured content, build tooling, README. |
| **Verification** | A real Node/Python build subprocess decides pass/fail, plus 119 deterministic checks: application, accessibility, SEO, security, performance, data and documentation. Repair rules fix what they can prove and hand the rest back. |
| **Localization** | Curated glossaries (Tamil, Hindi, Arabic incl. RTL, French, Spanish, German) with measured coverage, missing-string reports, placeholder/terminology/expansion checks; live translation when a verified model and key are present. |
| **Feedback** | Classification, sentiment, priority, duplicate detection, PII redaction; conversion into a real improvement run that applies bounded content changes in a **new version** (so rollback stays possible) and defers structural requests to `content/roadmap.json`. |
| **Maintenance** | On-demand monitors, incident records with repair plans and rollback-risk assessment, version rollback, maintenance schedule. |
| **Marketing & media** | Social/email/blog/analytics artifacts as drafts, UTM plans, storyboard + SRT + ffmpeg render command. Publishing stays blocked until an account is connected and explicitly authorized. |
| **Packaging** | Versioned zip export with a deployment plan and launch checklist; deployment execution is deliberately not claimed. |

## Honest limitations (short version)

- **Live model inference needs `NVIDIA_API_KEY`.** Discovery, routing and decision logging work
  without it; generation calls then report `skipped_blocked` with the exact reason.
- **Translation coverage is partial** for full copy (glossary covers site shell; gaps are listed).
- **No live deployment, no social publishing, no video encoding** (no target/credentials/ffmpeg).
- **Single-user, no login.** The console is private to this deployment. Add authentication before
  exposing it anywhere shared.
- **Scale stack not implemented:** SQLite + in-process workers instead of PostgreSQL/Redis/queue.
- **Visual checks are structural**, not pixel diffs (no headless browser here).

Full list with per-item status codes: `FINAL_REPORT.md` §12–14 and the in-app **Overview → capability
ledger**.

## Configuration

Set from the console (**Settings**) or via environment variables. Secrets are stored in the local
SQLite database and are never returned by the API (the settings endpoint only reports whether a
secret is present, plus a masked fragment of its length).

| Key | Purpose |
| --- | --- |
| `platform_name` / `PLATFORM_NAME` | Configurable platform name |
| `nvidia_api_key` / `NVIDIA_API_KEY` | Live inference, health checks, live translation |
| `nvidia_base_url` / `NVIDIA_BASE_URL` | Defaults to `https://integrate.api.nvidia.com/v1` |
| `enable_live_models` | Master switch for provider calls |
| `max_parallel_tasks` | Orchestrator concurrency (default 4) |
| `smtp_host`, `smtp_port`, `smtp_user`, `smtp_password`, `smtp_from` | Real email sending; otherwise messages queue in the local outbox |
| `social_authorized`, `deploy_authorized` | Explicit user authorization gates |
| `PLATFORM_DATA_DIR` | Data root override (database, projects, exports) |

## Layout

```
app/            server, orchestrator, registry, models, engines, generation, verify, db, report
app/static/     single-page console (no external assets)
data/           platform.db, projects/<id>/v<n>/…, exports/, registry_report.*
tests/          test_platform.py (45 tests)
FINAL_REPORT.md evidence-based implementation report
ARCHITECTURE.md system, data and workflow documentation
```

Project versions on disk contain the deployable site (`site/`), the build (`build.mjs`,
`build.py`), checks (`tests/checks.mjs`), verification reports (`checks/`), content, notices,
launch checklist and `DEPLOYMENT.md`.

## Security notes

- Single-user, local-first: no login screen, no public endpoints beyond the console API, and the
  process binds to the port you choose.
- All generated writes and file reads are path-guarded to the project version root or the export
  directory (`util.safe_join`), enforced by tests.
- Secrets are never echoed back; model calls log without credentials; the audit log records actor,
  action and target for every mutation.
- Generated sites are statically checked for secrets, insecure resources, remote scripts, inline
  handlers, `target="_blank"` without `noopener` and form submission over plain HTTP.
