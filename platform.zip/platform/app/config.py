"""Platform configuration: identity, defaults, environment, capability ledger seed.

The platform name is configurable (spec: "The name must remain configurable").
"""
from __future__ import annotations

import os

PLATFORM_VERSION = "1.0.0-single-user"

DEFAULT_SETTINGS = {
    # --- identity -------------------------------------------------------
    "platform_name": os.environ.get(
        "PLATFORM_NAME",
        "NVIDIA Multi-Agent Website Engineering and Autonomous Maintenance Platform",
    ),
    "edition": "Single-User Private Edition",
    "brand_primary": "#76b900",
    # --- model provider -------------------------------------------------
    # Key is stored locally in the workspace database only. Never returned by the API.
    "nvidia_api_key": os.environ.get("NVIDIA_API_KEY", ""),
    "nvidia_base_url": os.environ.get("NVIDIA_BASE_URL", "https://integrate.api.nvidia.com/v1"),
    "enable_live_models": "true",
    "provider_timeout_s": "60",
    "provider_max_retries": "2",
    # --- orchestration --------------------------------------------------
    "max_parallel_tasks": "4",
    "task_timeout_s": "180",
    "checkpoint_every_task": "true",
    "auto_approve_internal": "false",
    # --- generation -----------------------------------------------------
    "default_languages": "en",
    "design_density": "comfortable",
    "design_radius": "14",
    # --- channels (unconfigured by default; honest status in UI) --------
    "smtp_host": "",
    "smtp_port": "587",
    "smtp_user": "",
    "smtp_password": "",
    "smtp_from": "",
    "email_mode": "outbox",  # outbox = write to local outbox and report unconfigured SMTP
    # --- publishing (requires explicit user authorization) --------------
    "social_authorized": "false",
    "deploy_authorized": "false",
}

# Capability ledger seed. Five-state classification, per spec section 1:
# 1 implemented+verified  2 implemented, not fully verified  3 partial
# 4 blocked (credentials/infra)  5 planned
LEDGER_SEED = [
    ("application_boot", "Platform boots and serves the console", 1),
    ("workspace_project_module", "Project workspaces with versioned artifacts", 1),
    ("requirements_engine", "Prompt intake and requirements extraction", 1),
    ("planning_engine", "Planning and smallest-effective-task decomposition", 1),
    ("research_engine", "Technical research and stack recommendation", 1),
    ("resource_discovery", "Open-source resource discovery with license records", 1),
    ("model_registry", "NVIDIA model registry with live catalog refresh", 1),
    ("model_routing", "Capability-based routing with recorded decisions", 1),
    ("agent_registry", "1,050-role registry (1,000 core + 50 extension) with validation", 1),
    ("agent_runtime", "Agent runtime with execution records and logs", 1),
    ("orchestration_engine", "Workflow engine with DAG, retries, checkpoints, cancel", 1),
    ("website_generation", "Website project generation, build, and preview", 1),
    ("file_workspace", "File workspace manager and version control", 1),
    ("testing_service", "Deterministic application/visual/a11y/security/perf checks", 1),
    ("debugging_service", "Failure analysis, repair proposals, verification reruns", 1),
    ("localization_service", "Translation pipeline with placeholder and QA checks", 3),
    ("feedback_intelligence", "Feedback capture, classification, task conversion", 1),
    ("maintenance_service", "Health monitoring, incidents, repair workflow, rollback", 1),
    ("marketing_service", "Marketing artifacts and publishing status tracking", 2),
    ("email_service", "Clarification Q&A: local outbox always; SMTP when configured", 4),
    ("video_production", "Video storyboard + render command (no ffmpeg in sandbox)", 4),
    ("social_publishing", "Requires authorized external accounts; tracked, not published", 4),
    ("deployment_service", "Deployment preparation and export package", 2),
    ("deployment_execution", "Live deployment to a hosting target", 5),
    ("observability", "Runs, tasks, artifacts, routing decisions, audit log", 1),
    ("security_and_isolation", "Secret handling, path isolation, static security review", 2),
    ("authentication", "Single-user private mode: local-only, no multi-user login", 3),
    ("capacity_scale", "Postgres/Redis/queue infrastructure for multi-tenant scale", 5),
]


def model_live_enabled(settings: dict) -> bool:
    return str(settings.get("enable_live_models", "true")).lower() in {"1", "true", "yes", "on"}


def has_api_key(settings: dict) -> bool:
    return bool(str(settings.get("nvidia_api_key", "")).strip())


def ledger_label(code: int) -> str:
    return {
        1: "Implemented and verified",
        2: "Implemented, not fully verified",
        3: "Partially implemented",
        4: "Blocked by missing credentials or infrastructure",
        5: "Planned, not implemented",
    }.get(code, "Unknown")
