"""Allow `python3 -m app.report` and a convenience CLI for the platform."""
import sys

if len(sys.argv) > 1 and sys.argv[1] == "report":
    from . import report
    report.main()
elif len(sys.argv) > 1 and sys.argv[1] == "validate":
    from . import db, registry
    db.init_db()
    result = registry.generate_registry(force=True)
    print("registry validation:", "PASS" if result["ok"] else "FAIL", result["report"]["counts"])
elif len(sys.argv) > 1 and sys.argv[1] == "serve":
    import uvicorn
    uvicorn.run("app.server:app", host="0.0.0.0", port=int(sys.argv[2]) if len(sys.argv) > 2 else 8000)
else:
    from . import report
    report.main()
