"""Agent registry generation, persistence and validation.

Builds exactly 1,000 core roles (25 departments x 40) plus exactly 50
extension roles, each with the full field set required by the specification,
then validates the registry structurally and semantically.
"""
from __future__ import annotations

import re

from . import db, models, skills as skill_catalog, util
from .agent_data import (DEPARTMENTS, DEPT_MODEL_PREFERENCE, DEPT_SKILLS, DEPT_TOOLS,
                         EXTENSION_GROUPS, EXT_MODEL_PREFERENCE, EXT_TOOLS)

DEFINITION_VERSION = "1.0.0"

ANALYSIS_DEPTS = {"intake", "planning", "research", "oss", "licensing", "architecture", "ux",
                  "seo", "content", "marketing", "ai", "qa", "security", "performance", "a11y",
                  "maintenance", "media"}
CODE_DEPTS = {"frontend", "backend", "middleware", "data", "design", "devops", "debugging"}

APPROVAL_PATTERNS = [
    ("deploy", "requires_human_approval"), ("publish", "requires_human_approval"),
    ("publishing", "requires_human_approval"), ("rollback", "requires_human_approval"),
    ("migration", "requires_human_approval"), ("terms of service", "review_before_external_use"),
    ("privacy policy", "review_before_external_use"),
]

DEPT_ARTIFACTS = {
    "intake": ["project_brief", "clarifying_questions", "assumption_register"],
    "planning": ["plan", "task_graph", "acceptance_criteria"],
    "research": ["research_report", "stack_recommendation"],
    "oss": ["resource_records", "recommendation_report"],
    "licensing": ["license_register", "attribution_notice"],
    "architecture": ["architecture_spec", "api_contracts", "architecture_diagram"],
    "data": ["schema_sql", "migrations", "seed_data"],
    "ux": ["journey_map", "flow_spec"],
    "design": ["design_tokens", "component_spec", "style_guide"],
    "frontend": ["source_files", "pages", "frontend_tests"],
    "backend": ["source_files", "api_handlers", "backend_tests"],
    "middleware": ["openapi_spec", "integration_adapters", "contract_tests"],
    "ai": ["model_registry_update", "routing_decisions", "evaluation_report"],
    "qa": ["test_cases", "test_report", "defect_list"],
    "debugging": ["root_cause_report", "patch", "verification_log"],
    "security": ["threat_model", "security_findings", "sbom"],
    "performance": ["performance_report", "budget_definition"],
    "a11y": ["accessibility_report", "i18n_checklist"],
    "seo": ["seo_report", "structured_data"],
    "content": ["content_documents", "style_guide"],
    "email": ["email_drafts", "outbox_records"],
    "devops": ["build_scripts", "deployment_plan", "export_package"],
    "maintenance": ["monitor_results", "incident_records", "maintenance_plan"],
    "media": ["storyboard", "render_command", "subtitle_files"],
    "marketing": ["marketing_assets", "publish_status", "analytics_report"],
}

EXT_ARTIFACTS = {
    "translation": ["translated_pages", "locale_files", "translation_qa_report"],
    "feedback": ["feedback_records", "feedback_analysis", "improvement_tasks"],
    "maintenance_ext": ["monitoring_report", "repair_plan", "rollback_assessment"],
    "delivery": ["specification", "generated_site", "acceptance_report"],
}

DEPT_CONTEXT = {
    "intake": ["project prompt", "prior brief versions"],
    "planning": ["project brief", "requirements register"],
    "research": ["requirements register", "target platform constraints"],
    "oss": ["stack recommendation", "license policy"],
    "licensing": ["resource records", "distribution model"],
    "architecture": ["requirements", "stack recommendation", "resource records"],
    "data": ["architecture spec", "entity list"],
    "ux": ["project brief", "personas"],
    "design": ["design brief", "brand signals"],
    "frontend": ["design spec", "architecture spec", "content documents"],
    "backend": ["architecture spec", "data schema", "api contracts"],
    "middleware": ["api contracts", "architecture spec"],
    "ai": ["model registry", "capability requirements"],
    "qa": ["acceptance criteria", "generated project version"],
    "debugging": ["check output", "logs for failing task", "affected source files"],
    "security": ["generated project version", "architecture spec"],
    "performance": ["served pages", "build manifest"],
    "a11y": ["generated pages", "design tokens"],
    "seo": ["generated pages", "project brief"],
    "content": ["project brief", "brand voice definition"],
    "email": ["open questions", "project brief"],
    "devops": ["generated project version", "acceptance report"],
    "maintenance": ["monitor results", "previous release notes"],
    "media": ["project brief", "marketing plan"],
    "marketing": ["project brief", "brand assets"],
}

DEPT_QUALITY_CHECKS = {
    "intake": ["every open question has an owner or default", "brief fields are populated"],
    "planning": ["every requirement maps to at least one task", "task graph is acyclic"],
    "research": ["claims carry a source and date", "no unverified version assertions"],
    "oss": ["every resource has provenance and license status", "no unmaintained package recommended without note"],
    "licensing": ["every external asset has a license verdict", "attribution requirements captured"],
    "architecture": ["every component has a responsibility", "contracts are typed"],
    "data": ["schema applies cleanly", "foreign keys declared", "rollback path exists"],
    "ux": ["primary journey has no dead end", "error states defined"],
    "design": ["contrast ratios pass for text styles", "tokens used consistently"],
    "frontend": ["markup parses", "no inline event handlers", "labels present on inputs"],
    "backend": ["handlers validate input", "errors do not leak internals"],
    "middleware": ["spec validates", "retries are bounded"],
    "ai": ["routing decision recorded with reason", "no unverified model used"],
    "qa": ["tests are deterministic", "failures produce reproductions"],
    "debugging": ["root cause evidenced by output", "fix verified by rerun"],
    "security": ["no hardcoded secrets", "findings include locations"],
    "performance": ["measurements recorded", "budget stated numerically"],
    "a11y": ["automated a11y rules execute on every page", "results recorded"],
    "seo": ["title and description present", "structured data parses"],
    "content": ["no placeholder lorem ipsum in published copy", "claims are checkable"],
    "email": ["sending state reported honestly", "no secrets in message bodies"],
    "devops": ["build command reproduces artifact", "rollback path documented"],
    "maintenance": ["checks actually executed", "incidents link to evidence"],
    "media": ["render command is executable", "missing tooling reported"],
    "marketing": ["publishing status reflects reality", "no fabricated metrics"],
}

DEPENDENCY_HINT = {
    "planning": ["intake"], "research": ["planning"], "oss": ["research"], "licensing": ["oss"],
    "architecture": ["research", "planning"], "data": ["architecture"], "ux": ["intake"],
    "design": ["ux"], "frontend": ["design", "architecture"], "backend": ["architecture", "data"],
    "middleware": ["backend"], "ai": ["architecture"], "qa": ["frontend", "backend"],
    "debugging": ["qa"], "security": ["frontend", "backend"], "performance": ["frontend", "backend"],
    "a11y": ["frontend"], "seo": ["frontend"], "content": ["intake"], "email": ["intake"],
    "devops": ["qa", "security"], "maintenance": ["devops"], "media": ["content"], "marketing": ["content", "seo"],
}


def _slug(text: str) -> str:
    return re.sub(r"[^a-z0-9]+", "_", text.lower()).strip("_")


def _timeout_for(dept_key: str, role: str) -> int:
    base = 240 if dept_key in CODE_DEPTS else 180
    if any(word in role.lower() for word in ("deploy", "migration", "render", "build")):
        base = 300
    if any(word in role.lower() for word in ("classification", "scout", "checker", "reviewer")):
        base = min(base, 120)
    return base


def _concurrency(dept_key: str) -> str:
    if dept_key in CODE_DEPTS:
        return "serialized_per_project_version"
    return "parallel_safe"


def _approval(role: str) -> str:
    lowered = role.lower()
    for pat, verdict in APPROVAL_PATTERNS:
        if pat in lowered:
            return verdict
    return "not_required"


def _tool_scopes(tool_ids: list[str]) -> list[dict]:
    out = []
    for tid in tool_ids:
        meta = skill_catalog.TOOLS.get(tid, (tid, "read", ""))
        scope = meta[1]
        out.append({
            "tool": tid,
            "scope": scope,
            "network": tid in skill_catalog.NETWORK_TOOLS,
            "requires_user_authorization": tid in skill_catalog.HIGH_IMPACT_TOOLS and "write" in scope,
        })
    return out


def _input_schema(dept_key: str, role: str) -> dict:
    return {
        "type": "object",
        "title": f"{role} input",
        "required": ["task_id", "project_id", "instruction"],
        "properties": {
            "task_id": {"type": "string"},
            "project_id": {"type": "string"},
            "instruction": {"type": "string", "description": "task-scoped instruction from the orchestrator"},
            "context_refs": {"type": "array", "items": {"type": "string"},
                             "description": "artifact ids or paths the agent may read"},
            "constraints": {"type": "array", "items": {"type": "string"}},
            "department": {"const": dept_key},
        },
    }


def _output_schema(dept_key: str, role: str) -> dict:
    return {
        "type": "object",
        "title": f"{role} output",
        "required": ["status", "summary", "artifacts", "evidence"],
        "properties": {
            "status": {"enum": ["succeeded", "failed", "blocked"]},
            "summary": {"type": "string"},
            "artifacts": {"type": "array", "items": {"type": "object", "properties": {
                "kind": {"type": "string"}, "path": {"type": "string"}}}},
            "evidence": {"type": "array", "items": {"type": "string"},
                         "description": "command output, file hashes, tool results"},
            "open_questions": {"type": "array", "items": {"type": "string"}},
            "failure": {"type": "object", "properties": {
                "code": {"type": "string"}, "message": {"type": "string"},
                "reproduction": {"type": "string"}}},
            "routing_decision": {"type": "object", "description": "model, reason and alternatives considered"},
        },
    }


def _eligible_models(capabilities: list[str]) -> tuple[list[str], list[str], dict]:
    """Resolve concrete verified model ids for the role's capability profile."""
    resolved: list[str] = []
    unavailable: list[dict] = []
    per_cap: dict[str, list[str]] = {}
    for cap in capabilities:
        cands = models.candidates_for(cap, limit=3)
        ids = [c["model_id"] for c in cands]
        per_cap[cap] = ids
        if not ids:
            unavailable.append({"capability": cap,
                                "reason": "no catalogue-present model verified for this capability"})
        for mid in ids:
            if mid not in resolved:
                resolved.append(mid)
    policy = {
        "capability_profile": capabilities,
        "candidates_per_capability": per_cap,
        "resolution": "resolved_from_live_registry" if resolved else "pending_registry_refresh",
    }
    return resolved, unavailable, policy


def _instructions(role: str, dept_name: str, purpose: str) -> str:
    return (
        f"You are the {role}, a specialist AI engineer inside the {dept_name} department of this platform.\n"
        f"Mission: {purpose}\n"
        "Operating rules:\n"
        f"1. Stay strictly inside your specialty; do not redesign unrelated parts of the project, and never rewrite the whole architecture for a small change.\n"
        "2. Every claim you make must point to a file, hash, command output or provider response stored as evidence. If you did not verify it, say so explicitly.\n"
        "3. Read only the context refs attached to your task; request more context instead of guessing.\n"
        "4. Return schema-valid output. When blocked, return status=blocked with the exact missing input, credential or permission.\n"
        "5. Never invent test results, never describe an unexecuted command as passing, and never fabricate model output.\n"
        "6. Respect tool scopes in your permissions list; high-impact tools require recorded user authorization.\n"
    )


def _responsibilities(role: str, dept_key: str) -> list[str]:
    base = [
        f"Deliver the '{role}' work item for every task routed to you.",
        "Produce artifacts with stable paths, checksums and a plain-language summary.",
        "Record evidence for each assertion (stdout, hashes, parsed results, sources).",
        "Raise blockers immediately with the smallest missing piece required to continue.",
    ]
    if dept_key in CODE_DEPTS:
        base.append("Change the minimum number of files required, and keep the project buildable after every edit.")
    else:
        base.append("Keep recommendations actionable and scoped to the current project version.")
    return base


def _model_criteria(caps: list[str], dept_key: str) -> tuple[str, str, str]:
    preferred = (
        f"Choose the highest-ranked catalogue-verified model whose capability profile includes "
        f"{', '.join(caps)}. Prefer models already verified by a live call; prefer tool-calling and "
        "structured-output support when the task needs machine-readable results."
    )
    fallback = (
        "On provider timeout, rate limit or 5xx, retry with exponential backoff, then fall back to the "
        "next ranked candidate in the recorded routing decision. Never switch to a model that lacks a "
        "required capability (for example a text-only model for image or translation work): report the "
        "task as blocked instead."
    )
    route = f"primary capability categories: {', '.join(caps)} (department default routing for {dept_key})"
    return preferred, fallback, route


def build_records() -> list[dict]:
    records: list[dict] = []
    # --- core: 25 x 40 ---
    for d_idx, dept in enumerate(DEPARTMENTS, start=1):
        dept_key = dept["key"]
        caps = DEPT_MODEL_PREFERENCE[dept_key]
        pool_skills = DEPT_SKILLS[dept_key]
        tools = list(DEPT_TOOLS[dept_key])
        for r_idx, role in enumerate(dept["specialties"], start=1):
            agent_id = f"AGT-CORE-{d_idx:02d}-{r_idx:02d}"
            role_tag = _slug(role)
            role_skill = f"{dept_key}__{role_tag}"
            skills_refs = [{"id": s, "name": skill_catalog.SKILLS[s][0], "status": "registered"} for s in pool_skills]
            skills_refs.append({"id": role_skill, "name": f"{role} Practice", "status": "derived_pending_review"})
            model_ids, unavailable, policy = _eligible_models(caps)
            preferred, fallback, route = _model_criteria(caps, dept_key)
            role_tools = list(tools)
            if any(w in role.lower() for w in ("test", "verif", "audit", "checker")):
                role_tools.append("check_runner")
            if any(w in role.lower() for w in ("secret", "credential", "vulnerab", "injection")):
                role_tools.append("security_scanner")
            role_tools = sorted(set(role_tools))
            records.append({
                "id": agent_id,
                "gid": d_idx * 100 + r_idx,
                "name": role,
                "department": dept["name"],
                "group_type": "core",
                "purpose": f"{role} within {dept['name']}: {dept['purpose'].rstrip('.')}.",
                "instructions": _instructions(role, dept["name"], dept["purpose"]),
                "responsibilities": _responsibilities(role, dept_key),
                "skills": skills_refs,
                "eligible_models": model_ids,
                "models_unavailable": unavailable,
                "model_policy": policy,
                "preferred_criteria": preferred,
                "fallback_criteria": fallback,
                "routing_rule": route,
                "tools": _tool_scopes(role_tools),
                "input_schema": _input_schema(dept_key, role),
                "output_schema": _output_schema(dept_key, role),
                "required_context": DEPT_CONTEXT.get(dept_key, ["project brief"]),
                "dependencies": DEPENDENCY_HINT.get(dept_key) or ["none: entry point of the workflow graph"],
                "expected_artifacts": DEPT_ARTIFACTS.get(dept_key, ["report"]),
                "quality_checks": [f"{role} self-check: " + q for q in DEPT_QUALITY_CHECKS.get(dept_key, ["output is evidence-linked"])],
                "security_restrictions": [
                    "No access to platform secrets or other projects' data.",
                    "Writes are confined to the active project version root.",
                    "Network tools may only reach allow-listed documentation and provider endpoints.",
                ] + (["Must not transmit personal data; redact identifiers from logs."] if dept_key in {"security", "email", "marketing", "a11y"} else []),
                "timeout_s": _timeout_for(dept_key, role),
                "retry_policy": {"max_attempts": 2, "backoff": "exponential",
                                 "retry_on": ["provider_timeout", "rate_limit", "transient_network"],
                                 "no_retry_on": ["validation_error", "authorization_required"]},
                "concurrency_policy": _concurrency(dept_key),
                "human_approval": _approval(role),
                "success_criteria": [
                    "Output validates against the role output schema.",
                    "Expected artifacts exist with recorded hashes.",
                    "Declared quality checks were executed and recorded.",
                ],
                "failure_format": '{"status":"failed","code":"...","message":"...","reproduction":"...","evidence":["..."]}',
                "definition_version": DEFINITION_VERSION,
            })

    # --- extension: 50 ---
    ext_start = 9001
    for g_idx, group in enumerate(EXTENSION_GROUPS):
        gkey = group["key"]
        caps = EXT_MODEL_PREFERENCE[gkey]
        tools = EXT_TOOLS[gkey]
        for r_idx, role in enumerate(group["roles"], start=1):
            agent_id = f"AGT-EXT-{gkey.upper()[:4]}-{r_idx:02d}"
            role_skill = f"ext_{gkey}__{_slug(role)}"
            model_ids, unavailable, policy = _eligible_models(caps)
            preferred, fallback, route = _model_criteria(caps, gkey)
            skills_refs = [{"id": s, "name": skill_catalog.SKILLS[s][0], "status": "registered"}
                           for s in (["translation", "terminology_management", "localization_qa"] if gkey == "translation" else
                                     ["defect_analysis", "defect_analysis", "analytics_interpretation"] if gkey == "feedback" else
                                     ["monitoring", "incident_response", "rollback_planning"] if gkey == "maintenance_ext" else
                                     ["system_design", "test_design", "deployment"])]
            skills_refs = list({s["id"]: s for s in skills_refs}.values())
            skills_refs.append({"id": role_skill, "name": f"{role} Practice", "status": "derived_pending_review"})
            records.append({
                "id": agent_id,
                "gid": ext_start + g_idx * 100 + r_idx,
                "name": role,
                "department": group["name"] + " (Extension)",
                "group_type": "extension",
                "purpose": f"{role} inside the extension group '{group['name']}': {group['purpose'].rstrip('.')}.",
                "instructions": _instructions(role, group["name"] + " (Extension)", group["purpose"]),
                "responsibilities": _responsibilities(role, gkey),
                "skills": skills_refs,
                "eligible_models": model_ids,
                "models_unavailable": unavailable,
                "model_policy": policy,
                "preferred_criteria": preferred,
                "fallback_criteria": fallback,
                "routing_rule": route,
                "tools": _tool_scopes(sorted(set(tools))),
                "input_schema": _input_schema(gkey, role),
                "output_schema": _output_schema(gkey, role),
                "required_context": DEPT_CONTEXT.get({"translation": "content", "feedback": "intake",
                                                       "maintenance_ext": "maintenance", "delivery": "planning"}[gkey],
                                                      ["project brief"]),
                "dependencies": {"translation": ["content", "seo"], "feedback": ["maintenance"],
                                 "maintenance_ext": ["devops"], "delivery": ["planning", "qa"]}[gkey],
                "expected_artifacts": EXT_ARTIFACTS[gkey],
                "quality_checks": DEPT_QUALITY_CHECKS.get(
                    {"translation": "content", "feedback": "intake", "maintenance_ext": "maintenance",
                     "delivery": "devops"}[gkey], ["output is evidence-linked"]),
                "security_restrictions": [
                    "No access to platform secrets or other projects' data.",
                    "Writes are confined to the active project version root.",
                    "External publishing is gated behind explicit user authorization records.",
                ],
                "timeout_s": _timeout_for(gkey, role),
                "retry_policy": {"max_attempts": 2, "backoff": "exponential",
                                 "retry_on": ["provider_timeout", "rate_limit", "transient_network"],
                                 "no_retry_on": ["validation_error", "authorization_required"]},
                "concurrency_policy": _concurrency(gkey),
                "human_approval": _approval(role),
                "success_criteria": [
                    "Output validates against the role output schema.",
                    "Expected artifacts exist with recorded hashes.",
                    "Declared quality checks were executed and recorded.",
                ],
                "failure_format": '{"status":"failed","code":"...","message":"...","reproduction":"...","evidence":["..."]}',
                "definition_version": DEFINITION_VERSION,
            })
    return records


REQUIRED_FIELDS = [
    "id", "name", "department", "group_type", "purpose", "instructions", "responsibilities",
    "skills", "eligible_models", "preferred_criteria", "fallback_criteria", "tools",
    "input_schema", "output_schema", "required_context", "dependencies", "expected_artifacts",
    "quality_checks", "security_restrictions", "timeout_s", "retry_policy", "concurrency_policy",
    "human_approval", "success_criteria", "failure_format", "definition_version",
]


def validate_records(records: list[dict]) -> dict:
    report: dict = {"ok": True, "checks": {}, "errors": []}

    def check(name: str, ok: bool, detail: str = ""):
        report["checks"][name] = {"ok": bool(ok), "detail": detail}
        if not ok:
            report["ok"] = False
            report["errors"].append(f"{name}: {detail}")

    ids = [r["id"] for r in records]
    names = [r["name"] for r in records]
    core = [r for r in records if r["group_type"] == "core"]
    ext = [r for r in records if r["group_type"] == "extension"]
    check("total_records_exactly_1050", len(records) == 1050, f"found {len(records)}")
    check("core_records_exactly_1000", len(core) == 1000, f"found {len(core)}")
    check("extension_records_exactly_50", len(ext) == 50, f"found {len(ext)}")
    check("unique_identifiers", len(set(ids)) == len(ids), f"{len(ids) - len(set(ids))} duplicates")
    check("unique_names", len(set(names)) == len(names), f"{len(names) - len(set(names))} duplicates")
    check("no_id_overlap_between_groups",
          not (set(r["id"] for r in core) & set(r["id"] for r in ext)), "core/extension ids must not overlap")

    per_dept: dict[str, int] = {}
    for r in core:
        per_dept[r["department"]] = per_dept.get(r["department"], 0) + 1
    check("exactly_25_departments", len(per_dept) == 25, f"found {len(per_dept)}")
    bad_depts = {d: n for d, n in per_dept.items() if n != 40}
    check("every_department_has_40_roles", not bad_depts, str(bad_depts))
    check("department_names_match_spec",
          set(per_dept) == {d["name"] for d in DEPARTMENTS}, "department names must match the specification list")
    ext_groups = {}
    for r in ext:
        ext_groups[r["department"]] = ext_groups.get(r["department"], 0) + 1
    check("extension_group_sizes_15_15_10_10",
          sorted(ext_groups.values()) == [10, 10, 15, 15], str(ext_groups))

    missing = []
    for r in records:
        for field in REQUIRED_FIELDS:
            value = r.get(field)
            if value in (None, "", [], {}):
                missing.append(f"{r['id']}.{field}")
    check("all_required_fields_populated", not missing,
          f"{len(missing)} empty fields, e.g. {missing[:5]}")

    registered_tools = set(skill_catalog.TOOLS)
    unknown_tools = sorted({t["tool"] for r in records for t in r["tools"]} - registered_tools)
    check("every_tool_reference_registered", not unknown_tools, str(unknown_tools))

    registered_skills = set(skill_catalog.SKILLS)
    unknown_skills, pending_skills = [], 0
    for r in records:
        for s in r["skills"]:
            if s["id"] not in registered_skills:
                if s["status"] in {"derived_pending_review", "pending"}:
                    pending_skills += 1
                else:
                    unknown_skills.append(f"{r['id']}.{s['id']}")
    check("skill_refs_registered_or_pending", not unknown_skills, str(unknown_skills[:5]))

    live_models = {row["id"] for row in db.query("SELECT id FROM models WHERE catalog_present=1")}
    unresolved = []
    for r in records:
        for mid in r["eligible_models"]:
            if mid not in live_models:
                unresolved.append(f"{r['id']}:{mid}")
    check("model_refs_validated_or_marked_unavailable",
          not unresolved, f"{len(unresolved)} refs not catalogue-present, e.g. {unresolved[:5]}")

    report["counts"] = {
        "total": len(records), "core": len(core), "extension": len(ext),
        "departments": len(per_dept),
        "pending_skill_refs": pending_skills,
        "unavailable_model_capabilities": sorted({u["capability"] for r in records for u in r["models_unavailable"]}),
        "distinct_models_referenced": len({m for r in records for m in r["eligible_models"]}),
    }
    report["per_department"] = per_dept
    report["extension_groups"] = ext_groups
    return report


def generate_registry(force: bool = False) -> dict:
    existing = db.query_one("SELECT COUNT(*) c FROM agents")["c"]
    if existing and not force:
        return {"ok": True, "skipped": True, "existing": existing,
                "detail": "registry already populated; pass force=True to regenerate"}
    records = build_records()
    report = validate_records(records)
    if force:
        db.execute("DELETE FROM agents")
    with db.cursor() as conn:
        for r in records:
            conn.execute(
                """INSERT OR REPLACE INTO agents (
                    id, gid, name, department, group_type, purpose, instructions,
                    responsibilities_json, skills_json, eligible_models_json,
                    preferred_criteria, fallback_criteria, tools_json,
                    input_schema_json, output_schema_json, required_context_json,
                    dependencies_json, expected_artifacts_json, quality_checks_json,
                    security_restrictions_json, timeout_s, retry_policy_json,
                    concurrency_policy, human_approval, success_criteria_json,
                    failure_format, definition_version, created_at
                ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (r["id"], r["gid"], r["name"], r["department"], r["group_type"], r["purpose"],
                 r["instructions"], util.jdump(r["responsibilities"]),
                 util.jdump({"refs": r["skills"], "model_policy": r["model_policy"]}),
                 util.jdump(r["eligible_models"]), r["preferred_criteria"], r["fallback_criteria"],
                 util.jdump(r["tools"]), util.jdump(r["input_schema"]), util.jdump(r["output_schema"]),
                 util.jdump(r["required_context"]), util.jdump(r["dependencies"]),
                 util.jdump(r["expected_artifacts"]), util.jdump(r["quality_checks"]),
                 util.jdump(r["security_restrictions"]), r["timeout_s"], util.jdump(r["retry_policy"]),
                 r["concurrency_policy"], r["human_approval"], util.jdump(r["success_criteria"]),
                 r["failure_format"], r["definition_version"], util.now_iso()),
            )
    # register derived skills as explicitly-pending entries
    for r in records:
        for s in r["skills"]:
            if s["id"] not in skill_catalog.SKILLS:
                db.upsert("skills", {"id": s["id"], "name": s["name"],
                                     "category": "role_derived", "description": "Derived per-role practice area.",
                                     "verification_status": "derived_pending_review"}, "id")
    for sid, (name, cat, desc) in skill_catalog.SKILLS.items():
        db.upsert("skills", {"id": sid, "name": name, "category": cat, "description": desc,
                             "verification_status": "registered"}, "id")
    for tid, (name, scope, desc) in skill_catalog.TOOLS.items():
        db.upsert("tools", {"id": tid, "name": name, "scope": scope, "description": desc,
                            "execution": "sandboxed" if scope.startswith("execute") else "in-process"}, "id")
    write_registry_report(report)
    db.ledger_set("agent_registry", 1,
                  evidence="registry.generate_registry() seeded agents table; validation report at data/registry_report.json",
                  limitations="Role definitions are generated deterministically; derived per-role skills are flagged derived_pending_review.")
    db.audit("system", "registry_generate", "agents", report["counts"])
    return {"ok": report["ok"], "skipped": False, "report": report}


def write_registry_report(report: dict) -> None:
    path = util.DATA_DIR / "registry_report.json"
    path.write_text(util.jdump(report))
    (util.DATA_DIR / "registry_report.txt").write_text(render_registry_report_text(report))


def render_registry_report_text(report: dict) -> str:
    lines = ["AGENT REGISTRY VALIDATION REPORT", "=" * 60, ""]
    for name, res in report["checks"].items():
        lines.append(f"[{'PASS' if res['ok'] else 'FAIL'}] {name}" + (f"  ({res['detail']})" if res["detail"] else ""))
    lines += ["", "Counts: " + util.jdump(report.get("counts", {})), "",
              "Roles per department:"]
    for dept, n in sorted(report.get("per_department", {}).items()):
        lines.append(f"  {n:>3}  {dept}")
    lines.append("")
    for group, n in sorted(report.get("extension_groups", {}).items()):
        lines.append(f"  {n:>3}  {group}")
    lines.append("")
    lines.append("OVERALL: " + ("PASS" if report["ok"] else "FAIL"))
    return "\n".join(lines)


def list_agents(search: str = "", department: str = "", group_type: str = "",
                skill: str = "", tool: str = "", model: str = "", limit: int = 60,
                offset: int = 0) -> dict:
    where, params = [], []
    if search:
        where.append("(name LIKE ? OR purpose LIKE ? OR instructions LIKE ?)")
        like = f"%{search}%"
        params += [like, like, like]
    if department:
        where.append("department = ?")
        params.append(department)
    if group_type:
        where.append("group_type = ?")
        params.append(group_type)
    if skill:
        where.append("skills_json LIKE ?")
        params.append(f"%{skill}%")
    if tool:
        where.append("tools_json LIKE ?")
        params.append(f"%{tool}%")
    if model:
        where.append("eligible_models_json LIKE ?")
        params.append(f"%{model}%")
    clause = (" WHERE " + " AND ".join(where)) if where else ""
    total = db.query_one(f"SELECT COUNT(*) c FROM agents{clause}", params)["c"]
    rows = db.query(f"SELECT * FROM agents{clause} ORDER BY gid LIMIT ? OFFSET ?", params + [limit, offset])
    return {"total": total, "limit": limit, "offset": offset,
            "items": [agent_public(db_row_to_dict(r)) for r in rows]}


def db_row_to_dict(row) -> dict:
    return {
        "id": row["id"], "gid": row["gid"], "name": row["name"], "department": row["department"],
        "group_type": row["group_type"], "purpose": row["purpose"], "instructions": row["instructions"],
        "responsibilities": util.jload(row["responsibilities_json"], []),
        "skills": util.jload(row["skills_json"], {}),
        "eligible_models": util.jload(row["eligible_models_json"], []),
        "preferred_criteria": row["preferred_criteria"], "fallback_criteria": row["fallback_criteria"],
        "tools": util.jload(row["tools_json"], []),
        "input_schema": util.jload(row["input_schema_json"], {}),
        "output_schema": util.jload(row["output_schema_json"], {}),
        "required_context": util.jload(row["required_context_json"], []),
        "dependencies": util.jload(row["dependencies_json"], []),
        "expected_artifacts": util.jload(row["expected_artifacts_json"], []),
        "quality_checks": util.jload(row["quality_checks_json"], []),
        "security_restrictions": util.jload(row["security_restrictions_json"], []),
        "timeout_s": row["timeout_s"], "retry_policy": util.jload(row["retry_policy_json"], {}),
        "concurrency_policy": row["concurrency_policy"], "human_approval": row["human_approval"],
        "success_criteria": util.jload(row["success_criteria_json"], []),
        "failure_format": row["failure_format"], "definition_version": row["definition_version"],
    }


def agent_public(agent: dict) -> dict:
    """Trim instructions for list views."""
    out = dict(agent)
    out["instructions"] = util.truncate(agent["instructions"], 200)
    return out


def get_agent(agent_id: str) -> dict | None:
    row = db.query_one("SELECT * FROM agents WHERE id=? OR name=?", (agent_id, agent_id))
    if row is None:
        return None
    agent = db_row_to_dict(row)
    agent["executions"] = execution_history(row["id"], 20)
    return agent


def execution_history(agent_id: str, limit: int = 20) -> list[dict]:
    rows = db.query(
        """SELECT ar.*, t.name task_name, t.status task_status FROM agent_runs ar
           LEFT JOIN tasks t ON t.id = ar.task_id WHERE ar.agent_id=?
           ORDER BY ar.id DESC LIMIT ?""", (agent_id, limit))
    return [dict(r) for r in rows]


def resolve_by_department(dept_key: str, role_hint: str = "") -> dict | None:
    """Pick a concrete agent for orchestration: department + best-matching role name."""
    dept_name = None
    for d in DEPARTMENTS:
        if d["key"] == dept_key:
            dept_name = d["name"]
            break
    if dept_name is None:
        return None
    rows = db.query("SELECT * FROM agents WHERE department=?", (dept_name,))
    if not rows:
        return None
    candidates = [db_row_to_dict(r) for r in rows]
    if role_hint:
        hint = role_hint.lower()
        tokens = [t for t in re.split(r"[^a-z0-9]+", hint) if len(t) > 3]
        scored = sorted(candidates, key=lambda a: -sum(1 for t in tokens if t in a["name"].lower()))
        if scored and any(t in scored[0]["name"].lower() for t in tokens):
            return scored[0]
    return candidates[0]


def resolve_extension(group_key: str, role_hint: str = "") -> dict | None:
    group = next((g for g in EXTENSION_GROUPS if g["key"] == group_key), None)
    if group is None:
        return None
    rows = db.query("SELECT * FROM agents WHERE department=?", (group["name"] + " (Extension)",))
    if not rows:
        return None
    candidates = [db_row_to_dict(r) for r in rows]
    if role_hint:
        hint = role_hint.lower()
        tokens = [t for t in re.split(r"[^a-z0-9]+", hint) if len(t) > 3]
        scored = sorted(candidates, key=lambda a: -sum(1 for t in tokens if t in a["name"].lower()))
        if scored and any(t in scored[0]["name"].lower() for t in tokens):
            return scored[0]
    return candidates[0]


def registry_stats() -> dict:
    total = db.query_one("SELECT COUNT(*) c FROM agents")["c"]
    core = db.query_one("SELECT COUNT(*) c FROM agents WHERE group_type='core'")["c"]
    ext = db.query_one("SELECT COUNT(*) c FROM agents WHERE group_type='extension'")["c"]
    depts = db.query("SELECT department, COUNT(*) c FROM agents WHERE group_type='core' GROUP BY department ORDER BY department")
    return {"total": total, "core": core, "extension": ext,
            "departments": [{"department": d["department"], "roles": d["c"]} for d in depts],
            "department_count": len(depts)}


def departments() -> list[dict]:
    return [{"key": d["key"], "name": d["name"], "roles": 40} for d in DEPARTMENTS] + \
           [{"key": g["key"] + "_ext", "name": g["name"] + " (Extension)", "roles": len(g["roles"])}
            for g in EXTENSION_GROUPS]
