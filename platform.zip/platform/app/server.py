"""Single-user API server: REST endpoints, project file preview, console UI."""
from __future__ import annotations

import mimetypes
import os
import shutil
from pathlib import Path

from fastapi import Body, FastAPI, HTTPException, Query
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse, PlainTextResponse
from fastapi.staticfiles import StaticFiles

from . import (config, db, engines, generation, models, orchestrator, registry, skills,
               util, verify)

app = FastAPI(title="NVIDIA Multi-Agent Website Engineering Platform",
              version=config.PLATFORM_VERSION,
              description="Single-user private edition. Private to the owner of this deployment.")
app.mount("/static", StaticFiles(directory=str(util.STATIC_DIR)), name="static")


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------


def _row_to_project(row) -> dict:
    if row is None:
        return {}
    project = dict(row)
    for key in ("brief_json", "requirements_json", "plan_json", "research_json", "resources_json",
                "arch_json", "design_json", "stack_json", "acceptance_json", "deploy_json"):
        project[key.replace("_json", "")] = util.jload(row[key], {})
    return project


def _version_root_or_404(project_id: str, version: int | None = None) -> tuple[Path, dict]:
    if version is None:
        row = db.query_one("SELECT * FROM project_versions WHERE project_id=? ORDER BY version DESC LIMIT 1", (project_id,))
    else:
        row = db.query_one("SELECT * FROM project_versions WHERE project_id=? AND version=?", (project_id, version))
    if row is None:
        raise HTTPException(404, "no generated version for this project yet")
    return Path(row["root"]), dict(row)


# ---------------------------------------------------------------------------
# platform status
# ---------------------------------------------------------------------------


@app.get("/api/health")
def health():
    return {"ok": True, "platform": config.DEFAULT_SETTINGS["platform_name"],
            "version": config.PLATFORM_VERSION, "time": util.now_iso(),
            "single_user": True}


@app.get("/api/status")
def status():
    settings = db.get_settings()
    masked = db.get_settings(masked=True)
    counts = {
        "projects": db.query_one("SELECT COUNT(*) c FROM projects")["c"],
        "runs": db.query_one("SELECT COUNT(*) c FROM runs")["c"],
        "tasks": db.query_one("SELECT COUNT(*) c FROM tasks")["c"],
        "artifacts": db.query_one("SELECT COUNT(*) c FROM artifacts")["c"],
        "feedback": db.query_one("SELECT COUNT(*) c FROM feedback")["c"],
        "incidents_open": db.query_one("SELECT COUNT(*) c FROM incidents WHERE status='open'")["c"],
        "verifications": db.query_one("SELECT COUNT(*) c FROM artifacts WHERE kind='verification_report'")["c"],
    }
    running = [dict(r) for r in db.query("SELECT id, kind, status, project_id FROM runs WHERE status IN ('running','queued','awaiting_approval') ORDER BY started_at DESC LIMIT 10")]
    return {
        "platform": {
            "name": config.DEFAULT_SETTINGS["platform_name"],
            "version": config.PLATFORM_VERSION,
            "edition": config.DEFAULT_SETTINGS["edition"],
            "nvidia_key_configured": config.has_api_key(settings),
            "live_models_enabled": config.model_live_enabled(settings),
        },
        "models": models.registry_stats(),
        "agents": registry.registry_stats(),
        "counts": counts,
        "running_runs": running,
        "settings": {k: v for k, v in masked.items() if not k.endswith("_present")},
        "secrets_present": {k: masked.get(f"{k}_present", False) for k in db.SECRET_KEYS},
        "environment": {
            "python": os.sys.version.split()[0],
            "node": shutil.which("node") or "",
            "ffmpeg": shutil.which("ffmpeg") or "",
            "git": shutil.which("git") or "",
            "database": str(util.DB_PATH),
        },
    }


@app.get("/api/ledger")
def ledger():
    rows = [dict(r) for r in db.query("SELECT * FROM ledger ORDER BY status_code, capability")]
    return {"items": rows, "counts_by_status": {
        code: sum(1 for r in rows if r["status_code"] == code) for code in (1, 2, 3, 4, 5)}}


@app.get("/api/audit")
def audit(limit: int = 200):
    return {"items": [dict(r) for r in db.query("SELECT * FROM audit_log ORDER BY id DESC LIMIT ?", (limit,))]}


@app.get("/api/settings")
def get_settings():
    masked = db.get_settings(masked=True)
    return {"settings": {k: v for k, v in masked.items() if not k.endswith("_present")},
            "secrets_present": {k: masked.get(f"{k}_present", False) for k in db.SECRET_KEYS},
            "secret_keys": sorted(db.SECRET_KEYS)}


@app.post("/api/settings")
def update_settings(payload: dict = Body(...)):
    allowed = set(config.DEFAULT_SETTINGS) | {k for k in config.DEFAULT_SETTINGS}
    changed = []
    for key, value in payload.items():
        if key not in allowed:
            continue
        db.set_setting(key, str(value))
        changed.append(key)
    db.audit("user", "settings_updated", "", {"keys": changed})
    return {"ok": True, "changed": changed}


# ---------------------------------------------------------------------------
# model registry
# ---------------------------------------------------------------------------


@app.post("/api/models/refresh")
def refresh_models(verify_health: bool = False):
    stats = models.refresh_models(verify_health=verify_health)
    return stats


@app.get("/api/models")
def list_models(q: str = "", capability: str = "", present: bool = True, limit: int = 200):
    where, params = [], []
    if present:
        where.append("catalog_present=1")
    if q:
        where.append("(id LIKE ? OR display_name LIKE ?)")
        params += [f"%{q}%", f"%{q}%"]
    if capability:
        where.append("capabilities_json LIKE ?")
        params.append(f"%{capability}%")
    clause = (" WHERE " + " AND ".join(where)) if where else ""
    rows = db.query(f"SELECT * FROM models{clause} ORDER BY id LIMIT ?", params + [limit])
    items = []
    for row in rows:
        item = dict(row)
        for key in ("capabilities_json", "input_modalities_json", "output_modalities_json",
                    "agent_eligibility_json", "fallback_candidates_json"):
            item[key.replace("_json", "")] = util.jload(row[key], [])
        items.append(item)
    return {"items": items, "stats": models.registry_stats(), "capabilities": models.CAPABILITIES,
            "spec_candidates": models.SPEC_CANDIDATES}


@app.get("/api/models/stats")
def model_stats():
    return models.registry_stats()


@app.get("/api/models/{model_id:path}/check")
def check_model(model_id: str):
    return models.health_check(model_id)


@app.post("/api/models/invoke")
def invoke_model(payload: dict = Body(...)):
    model_id = payload.get("model_id", "")
    message = payload.get("message", "")
    if not model_id or not message:
        raise HTTPException(400, "model_id and message are required")
    return models.invoke(model_id, [{"role": "user", "content": message}],
                         max_tokens=int(payload.get("max_tokens", 400)))


@app.get("/api/routing")
def routing_log(limit: int = 100):
    return {"items": [dict(r) for r in db.query(
        "SELECT * FROM routing_decisions ORDER BY id DESC LIMIT ?", (limit,))]}


# ---------------------------------------------------------------------------
# agent registry
# ---------------------------------------------------------------------------


@app.get("/api/agents")
def list_agents(q: str = "", department: str = "", group_type: str = "", skill: str = "",
                tool: str = "", model: str = "", limit: int = 60, offset: int = 0):
    return registry.list_agents(q, department, group_type, skill, tool, model, limit, offset)


@app.get("/api/agents/{agent_id}")
def get_agent(agent_id: str):
    agent = registry.get_agent(agent_id)
    if not agent:
        raise HTTPException(404, "agent not found")
    return agent


@app.get("/api/departments")
def departments():
    return {"items": registry.departments(),
            "skills": [{"id": k, "name": v[0], "category": v[1]} for k, v in skills.SKILLS.items()],
            "tools": [{"id": k, "name": v[0], "scope": v[1]} for k, v in skills.TOOLS.items()]}


@app.get("/api/registry/report")
def registry_report():
    path = util.DATA_DIR / "registry_report.json"
    report = util.jload(path.read_text(encoding="utf-8"), {}) if path.exists() else {}
    text = util.DATA_DIR / "registry_report.txt"
    return {"report": report, "text": text.read_text(encoding="utf-8") if text.exists() else ""}


@app.post("/api/registry/validate")
def validate_registry():
    records = registry.build_records()
    report = registry.validate_records(records)
    registry.write_registry_report(report)
    db.audit("user", "registry_validated", "agents", report["counts"])
    return report


# ---------------------------------------------------------------------------
# projects and runs
# ---------------------------------------------------------------------------


@app.post("/api/projects")
def create_project(payload: dict = Body(...)):
    prompt = util.squeeze(payload.get("prompt", ""))
    if len(prompt) < 12:
        raise HTTPException(400, "prompt is too short — describe the website you need")
    name = util.squeeze(payload.get("name", "")) or engines.extract_name(prompt) or "Untitled website"
    archetype, label = generation.classify_archetype(prompt)
    project_id = util.new_id("prj_")
    db.insert("projects", {
        "id": project_id, "name": name, "prompt": prompt, "ptype": archetype, "industry": label,
        "status": "intake", "active_version": 0, "brief_json": "{}", "requirements_json": "{}",
        "plan_json": "{}", "research_json": "{}", "resources_json": "{}", "arch_json": "{}",
        "design_json": "{}", "stack_json": "{}", "acceptance_json": "{}", "deploy_json": "{}",
        "created_at": util.now_iso(), "updated_at": util.now_iso(),
    })
    db.audit("user", "project_created", project_id, {"archetype": archetype, "name": name})
    return {"ok": True, "project_id": project_id, "name": name, "archetype": archetype}


@app.get("/api/projects")
def list_projects():
    rows = db.query("SELECT * FROM projects ORDER BY created_at DESC")
    items = []
    for row in rows:
        project = _row_to_project(row)
        version = db.query_one("SELECT version, tests_json, created_at FROM project_versions "
                               "WHERE project_id=? ORDER BY version DESC LIMIT 1", (row["id"],))
        project["latest_version"] = dict(version) if version else None
        project["latest_tests"] = util.jload(version["tests_json"], {}) if version else {}
        items.append(project)
    return {"items": items}


@app.get("/api/projects/{project_id}")
def get_project(project_id: str):
    row = db.query_one("SELECT * FROM projects WHERE id=?", (project_id,))
    if row is None:
        raise HTTPException(404, "project not found")
    project = _row_to_project(row)
    project["versions"] = [dict(v) for v in db.query(
        "SELECT version, label, notes, created_at, tests_json FROM project_versions WHERE project_id=? ORDER BY version DESC",
        (project_id,))]
    project["runs"] = [dict(r) for r in db.query(
        "SELECT id, kind, status, started_at, finished_at FROM runs WHERE project_id=? ORDER BY started_at DESC LIMIT 20",
        (project_id,))]
    project["artifacts"] = [dict(a) for a in db.query(
        "SELECT * FROM artifacts WHERE project_id=? ORDER BY created_at DESC LIMIT 100", (project_id,))]
    project["feedback"] = [dict(f) for f in db.query(
        "SELECT * FROM feedback WHERE project_id=? ORDER BY created_at DESC LIMIT 50", (project_id,))]
    project["localization"] = [dict(l) for l in db.query(
        "SELECT * FROM localization_jobs WHERE project_id=? ORDER BY created_at DESC LIMIT 20", (project_id,))]
    project["incidents"] = [dict(i) for i in db.query(
        "SELECT * FROM incidents WHERE project_id=? ORDER BY detected_at DESC LIMIT 50", (project_id,))]
    project["marketing"] = [dict(m) for m in db.query(
        "SELECT * FROM marketing_assets WHERE project_id=? ORDER BY created_at DESC LIMIT 50", (project_id,))]
    project["emails"] = [dict(e) for e in db.query(
        "SELECT * FROM email_messages WHERE project_id=? ORDER BY created_at DESC LIMIT 50", (project_id,))]
    project["monitors"] = [dict(m) for m in db.query(
        "SELECT * FROM monitor_checks WHERE project_id=? ORDER BY ts DESC LIMIT 30", (project_id,))]
    return project


@app.post("/api/projects/{project_id}/run")
def run_project(project_id: str, payload: dict = Body(default={})):
    row = db.query_one("SELECT * FROM projects WHERE id=?", (project_id,))
    if row is None:
        raise HTTPException(404, "project not found")
    kind = payload.get("kind", "full_build")
    result = orchestrator.start_run(dict(row), kind, payload)
    if not result.get("ok"):
        raise HTTPException(400, result.get("detail", "could not start run"))
    return result


@app.get("/api/projects/{project_id}/translate")
def translate_preview(project_id: str, lang: str):
    root, _ = _version_root_or_404(project_id)
    return {"available_glossary": sorted(engines.GLOSSARY.keys()),
            "language": lang, "glossary_entries": len(engines.GLOSSARY.get(lang, {}))}


@app.post("/api/projects/{project_id}/translate")
def translate(project_id: str, payload: dict = Body(default={})):
    row = db.query_one("SELECT * FROM projects WHERE id=?", (project_id,))
    if row is None:
        raise HTTPException(404, "project not found")
    targets = payload.get("targets") or ["ta"]
    return orchestrator.start_run(dict(row), "translation", {"targets": targets})


@app.post("/api/projects/{project_id}/feedback")
def add_feedback(project_id: str, payload: dict = Body(...)):
    row = db.query_one("SELECT * FROM projects WHERE id=?", (project_id,))
    if row is None:
        raise HTTPException(404, "project not found")
    text = util.squeeze(payload.get("text", ""))
    if len(text) < 5:
        raise HTTPException(400, "feedback text is required")
    analysis = engines.analyze_feedback(project_id, text, payload.get("channel", "console"),
                                       payload.get("author", ""))
    return analysis


@app.post("/api/feedback/{feedback_id}/improve")
def improve_from_feedback(feedback_id: str):
    result = engines.feedback_to_task(feedback_id)
    if not result.get("ok"):
        raise HTTPException(400, result.get("detail", "could not convert feedback"))
    return result


@app.get("/api/projects/{project_id}/release-notes")
def release_notes(project_id: str):
    return PlainTextResponse(engines.release_notes(project_id))


@app.post("/api/projects/{project_id}/monitor")
def monitor(project_id: str):
    row = db.query_one("SELECT * FROM projects WHERE id=?", (project_id,))
    if row is None:
        raise HTTPException(404, "project not found")
    return orchestrator.start_run(dict(row), "maintenance", {})


@app.post("/api/projects/{project_id}/marketing")
def marketing(project_id: str):
    row = db.query_one("SELECT * FROM projects WHERE id=?", (project_id,))
    if row is None:
        raise HTTPException(404, "project not found")
    result = engines.marketing_assets(dict(row))
    db.audit("user", "marketing_generated", project_id, {"assets": len(result["assets"])})
    return result


@app.post("/api/projects/{project_id}/media")
def media(project_id: str):
    row = db.query_one("SELECT * FROM projects WHERE id=?", (project_id,))
    if row is None:
        raise HTTPException(404, "project not found")
    return engines.media_assets(dict(row))


@app.post("/api/projects/{project_id}/clarify")
def clarify(project_id: str):
    result = engines.clarification_questions(project_id)
    if not result.get("ok"):
        raise HTTPException(400, result.get("detail", "could not create clarification"))
    return result


@app.post("/api/projects/{project_id}/email")
def send_email(project_id: str, payload: dict = Body(...)):
    return engines.email_send(project_id, payload.get("to", ""), payload.get("subject", "(no subject)"),
                              payload.get("body", ""))


@app.post("/api/projects/{project_id}/export")
def export_project(project_id: str, version: int | None = None):
    result = engines.export_version(project_id, version)
    if not result.get("ok"):
        raise HTTPException(400, result.get("detail", "export failed"))
    return result


@app.get("/api/projects/{project_id}/deployment-plan")
def deployment_plan(project_id: str, version: int | None = None):
    row = db.query_one("SELECT * FROM projects WHERE id=?", (project_id,))
    if row is None:
        raise HTTPException(404, "project not found")
    target = db.query_one("SELECT * FROM project_versions WHERE project_id=? ORDER BY version DESC LIMIT 1", (project_id,))
    if target is None:
        raise HTTPException(400, "no version generated yet")
    plan = engines.deployment_plan(dict(row), Path(target["root"]), target["version"])
    plan["deployed"] = False
    plan["deploy_status"] = "not_deployed"
    plan["deploy_detail"] = ("Deployment execution is not implemented: no hosting target or credentials are configured. "
                            "The package and plan are ready to hand over.")
    return plan


@app.get("/api/incidents")
def incidents(project_id: str = ""):
    if project_id:
        rows = db.query("SELECT * FROM incidents WHERE project_id=? ORDER BY detected_at DESC", (project_id,))
    else:
        rows = db.query("SELECT * FROM incidents ORDER BY detected_at DESC LIMIT 200")
    return {"items": [dict(r) for r in rows]}


@app.post("/api/incidents/{incident_id}/resolve")
def resolve_incident(incident_id: str, payload: dict = Body(default={})):
    return engines.resolve_incident(incident_id, payload.get("resolution", ""), bool(payload.get("rollback")))


@app.get("/api/emails")
def emails(project_id: str = ""):
    if project_id:
        rows = db.query("SELECT * FROM email_messages WHERE project_id=? ORDER BY created_at DESC", (project_id,))
    else:
        rows = db.query("SELECT * FROM email_messages ORDER BY created_at DESC LIMIT 200")
    return {"items": [dict(r) for r in rows]}


@app.get("/api/runs")
def runs(project_id: str = "", limit: int = 50):
    if project_id:
        rows = db.query("SELECT * FROM runs WHERE project_id=? ORDER BY started_at DESC LIMIT ?", (project_id, limit))
    else:
        rows = db.query("SELECT * FROM runs ORDER BY started_at DESC LIMIT ?", (limit,))
    return {"items": [dict(r) for r in rows]}


@app.get("/api/runs/{run_id}")
def run_detail(run_id: str):
    detail = orchestrator.run_detail(run_id)
    if not detail:
        raise HTTPException(404, "run not found")
    return detail


@app.post("/api/runs/{run_id}/cancel")
def cancel_run(run_id: str):
    return orchestrator.cancel_run(run_id)


@app.post("/api/tasks/{task_id}/approve")
def approve_task(task_id: str):
    result = orchestrator.approve_task(task_id)
    if not result.get("ok"):
        raise HTTPException(400, result.get("detail", "approval failed"))
    return result


@app.get("/api/artifacts")
def artifacts(project_id: str = "", kind: str = "", limit: int = 200):
    where, params = [], []
    if project_id:
        where.append("project_id=?")
        params.append(project_id)
    if kind:
        where.append("kind=?")
        params.append(kind)
    clause = (" WHERE " + " AND ".join(where)) if where else ""
    rows = db.query(f"SELECT * FROM artifacts{clause} ORDER BY created_at DESC LIMIT ?", params + [limit])
    return {"items": [dict(r) for r in rows]}


FILE_ROOTS = [util.PROJECTS_DIR, util.EXPORT_DIR, util.DATA_DIR / "marketing"]


@app.get("/api/files")
def fetch_file(path: str):
    """Serve an artifact by absolute path, restricted to platform data roots."""
    target = Path(path).resolve()
    allowed = any(str(target).startswith(str(root.resolve())) for root in FILE_ROOTS)
    if not allowed or not target.exists() or target.is_dir():
        raise HTTPException(403, "path outside the platform data roots")
    mime = mimetypes.guess_type(str(target))[0] or "application/octet-stream"
    return FileResponse(str(target), media_type=mime, filename=target.name)


# ---------------------------------------------------------------------------
# preview of generated sites
# ---------------------------------------------------------------------------


@app.get("/preview/{project_id}/{version}/{asset_path:path}")
def preview(project_id: str, version: int, asset_path: str = ""):
    row = db.query_one("SELECT * FROM project_versions WHERE project_id=? AND version=?", (project_id, version))
    if row is None:
        raise HTTPException(404, "version not found")
    root = Path(row["root"]) / "site"
    if not asset_path or asset_path.endswith("/"):
        asset_path = (asset_path or "") + "index.html"
    try:
        target = util.safe_join(root, asset_path)
    except ValueError:
        raise HTTPException(403, "invalid path")
    if not target.exists() or target.is_dir():
        raise HTTPException(404, f"{asset_path} not found in this version")
    mime = mimetypes.guess_type(str(target))[0] or "text/plain"
    if target.suffix == ".html":
        mime = "text/html"
    return FileResponse(str(target), media_type=mime)


@app.get("/preview/{project_id}/{version}")
def preview_root(project_id: str, version: int):
    return preview(project_id, version, "index.html")


@app.get("/api/projects/{project_id}/tree")
def project_tree(project_id: str, version: int | None = None):
    root, meta = _version_root_or_404(project_id, version)
    tree = []
    for path in sorted(root.rglob("*")):
        if path.is_file():
            rel = path.relative_to(root).as_posix()
            tree.append({"path": rel, "bytes": path.stat().st_size,
                         "sha256": util.sha256_file(path)[:16] if path.stat().st_size < 2_000_000 else ""})
    return {"root": str(root), "version": meta["version"], "files": tree, "count": len(tree)}


@app.get("/api/projects/{project_id}/file")
def project_file(project_id: str, path: str, version: int | None = None, download: bool = False):
    root, _ = _version_root_or_404(project_id, version)
    try:
        target = util.safe_join(root, path)
    except ValueError:
        raise HTTPException(403, "invalid path")
    if not target.exists() or target.is_dir():
        raise HTTPException(404, "file not found")
    if download:
        return FileResponse(str(target), filename=target.name)
    if target.suffix in {".html", ".css", ".js", ".json", ".md", ".txt", ".sitemap", ".xml", ".py", ".mjs", ".mts"} or target.name in {"NOTICE.md"}:
        return PlainTextResponse(target.read_text(encoding="utf-8", errors="replace"),
                                 media_type="text/plain; charset=utf-8")
    return FileResponse(str(target))


@app.get("/", response_class=HTMLResponse)
def index():
    return HTMLResponse((util.STATIC_DIR / "index.html").read_text(encoding="utf-8"))


@app.exception_handler(ValueError)
def value_error_handler(request, exc):  # pragma: no cover - defensive
    return JSONResponse({"detail": str(exc)}, status_code=400)


DEMO_PROMPT = (
    "A dental clinic in Coimbatore called Smile Care that needs a website with services, team, "
    "patient FAQ and a booking enquiry form. Include Tamil support."
)


def ensure_demo_project() -> str:
    """First boot: seed one real project so the console shows a working pipeline."""
    if db.query_one("SELECT COUNT(*) c FROM projects")["c"] > 0:
        return ""
    if os.environ.get("SEED_DEMO", "true").lower() not in {"1", "true", "yes", "on"}:
        return ""
    archetype, label = generation.classify_archetype(DEMO_PROMPT)
    project_id = util.new_id("prj_")
    db.insert("projects", {
        "id": project_id, "name": "Smile Care Dental", "prompt": DEMO_PROMPT,
        "ptype": archetype, "industry": label, "status": "intake", "active_version": 0,
        "brief_json": "{}", "requirements_json": "{}", "plan_json": "{}", "research_json": "{}",
        "resources_json": "{}", "arch_json": "{}", "design_json": "{}", "stack_json": "{}",
        "acceptance_json": "{}", "deploy_json": "{}", "blueprint_json": "{}",
        "created_at": util.now_iso(), "updated_at": util.now_iso(),
    })
    row = db.query_one("SELECT * FROM projects WHERE id=?", (project_id,))
    orchestrator.start_run(dict(row), "full_build", {})
    db.audit("system", "demo_project_seeded", project_id, {"archetype": archetype})
    return project_id


@app.on_event("startup")
def on_startup() -> None:
    db.init_db()
    if db.query_one("SELECT COUNT(*) c FROM models")["c"] == 0:
        models.refresh_models()
    if db.query_one("SELECT COUNT(*) c FROM agents")["c"] == 0:
        registry.generate_registry()
    resumed = orchestrator.resume_interrupted_runs()
    if resumed:
        db.audit("system", "runs_resumed_at_boot", "", {"count": resumed})
    ensure_demo_project()
