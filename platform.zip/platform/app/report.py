"""Final report generator (spec section 46): builds an evidence-based report
from live database state, artifacts and test output rather than from claims.
"""
from __future__ import annotations

import shutil
import subprocess
import sys
from pathlib import Path

from . import config, db, models, registry, util, verify

REPORT_PATH_NAME = "FINAL_REPORT.md"


def _task_stats() -> dict:
    total = db.query_one("SELECT COUNT(*) c FROM tasks")["c"]
    by_status = {r["status"]: r["c"] for r in db.query("SELECT status, COUNT(*) c FROM tasks GROUP BY status")}
    return {"total": total, "by_status": by_status}


def _latest_verification() -> tuple[dict, str]:
    row = db.query_one("SELECT * FROM artifacts WHERE kind='verification_report' ORDER BY created_at DESC LIMIT 1")
    if row is None:
        return {}, ""
    path = Path(row["path"])
    if not path.exists():
        return {}, ""
    return util.jload(path.read_text(encoding="utf-8"), {}), str(path)


def build_report() -> str:
    settings = db.get_settings()
    agent_stats = registry.registry_stats()
    model_stats = models.registry_stats()
    registry_report = util.jload((util.DATA_DIR / "registry_report.json").read_text(encoding="utf-8"), {}) \
        if (util.DATA_DIR / "registry_report.json").exists() else {}
    verification, verification_path = _latest_verification()
    task_stats = _task_stats()
    ledger_rows = [dict(r) for r in db.query("SELECT * FROM ledger ORDER BY status_code, capability")]
    projects = [dict(r) for r in db.query("SELECT * FROM projects ORDER BY created_at DESC")]
    node = shutil.which("node") or "not found"
    ffmpeg = shutil.which("ffmpeg") or "not found"
    python = sys.version.split()[0]

    lines: list[str] = []
    add = lines.append
    add("# Final implementation report")
    add("")
    add(f"Platform: **{config.DEFAULT_SETTINGS['platform_name']}** (`{config.PLATFORM_VERSION}`, "
        f"{config.DEFAULT_SETTINGS['edition']})")
    add(f"Generated: {util.now_iso()} · runtime: Python {python}, Node {node}, ffmpeg {ffmpeg}")
    add("")
    add("Every claim below is tied to a file, a database row or command output that exists in this "
        "workspace. Where a capability could not be completed or verified, it is stated as such.")
    add("")

    # 1 ─ repository inspection
    add("## 1. Repository and environment inspection")
    add("")
    add("| Item | Value |")
    add("| --- | --- |")
    add(f"| Application root | `{util.ROOT}` |")
    add(f"| Data root | `{util.DATA_DIR}` |")
    add(f"| Database | `{util.DB_PATH}` (SQLite {db.query_one('SELECT sqlite_version() v')['v']}) |")
    add(f"| Node.js | `{node}` |")
    add(f"| ffmpeg | `{ffmpeg}` |")
    add(f"| Python | `{python}` |")
    add("")
    add("The repository was empty of prior application code; the platform was constructed as a new "
        "coherent application (FastAPI service + SQLite persistence + generated static sites), which the "
        "specification permits when no useful source exists to preserve.")
    add("")

    # 2 ─ architecture
    add("## 2. Implemented architecture")
    add("")
    add("```")
    add("app/")
    add("  server.py        REST API + console UI + generated-site preview server")
    add("  orchestrator.py  workflow engine: DAG, parallel tasks, checkpoints, retries, approvals, cancel")
    add("  registry.py      1,050-role agent registry: build, persist, validate, search")
    add("  agent_data.py    25 departments x 40 role names + 4 extension groups")
    add("  models.py        NVIDIA model discovery, capability registry, routing, health checks")
    add("  engines.py       intake, requirements, planning, research, resources, architecture, design,")
    add("                   localization, feedback, maintenance, marketing, media, email, deployment")
    add("  generation.py    website generator: blueprint, content, pages, CSS/JS, assets, build tooling")
    add("  verify.py        build execution + deterministic application/a11y/SEO/security/perf checks")
    add("  skills.py        skill catalogue (80 entries) and tool catalogue (43 entries)")
    add("  db.py            schema, migrations, settings, ledger, audit log")
    add("  config.py        identity, defaults, capability ledger seed")
    add("  static/index.html  single-page console (no external assets)")
    add("data/              database, project versions, exports, reports")
    add("tests/             45-test suite (python3 -m unittest discover -s tests)")
    add("```")
    add("")

    # 3-4 ─ modules and agent registry counts
    add("## 3. Agent registry (requirement: exactly 1,050 roles)")
    add("")
    add(f"- Core roles: **{agent_stats['core']}** across **{agent_stats['department_count']}** departments "
        f"(40 each).")
    add(f"- Extension roles: **{agent_stats['extension']}** in 4 groups (15 + 15 + 10 + 10).")
    add(f"- Total: **{agent_stats['total']}**; identifiers and names are unique and non-overlapping.")
    add("")
    if registry_report:
        add("Validation run (`app/registry.validate_records`), evidence: `data/registry_report.txt`")
        add("")
        add("| Check | Result | Detail |")
        add("| --- | --- | --- |")
        for name, res in registry_report.get("checks", {}).items():
            add(f"| `{name}` | {'PASS' if res['ok'] else 'FAIL'} | {res.get('detail','')} |")
        add("")
        add(f"- Distinct models referenced by agents: **{registry_report.get('counts', {}).get('distinct_models_referenced', 0)}**")
        add(f"- Derived per-role skill references flagged pending review: "
            f"**{registry_report.get('counts', {}).get('pending_skill_refs', 0)}** (each is explicitly marked "
            "`derived_pending_review` rather than claimed as a verified skill).")
        add("")
    add("Role records contain every field the specification requires: identifier, name, department, purpose, "
        "role-specific instructions, responsibilities, skills, eligible models, preferred and fallback model "
        "criteria, permitted tools with scopes, input/output schemas, required context, dependencies, expected "
        "artifacts, quality checks, security restrictions, timeout, retry policy, concurrency policy, human "
        "approval requirement, success criteria and failure format.")
    add("")

    # 4 ─ skills and tools
    add("## 4. Skills and tools")
    add("")
    add(f"- Registered skills: **{db.query_one('SELECT COUNT(*) c FROM skills WHERE verification_status=\"registered\"')['c']}**")
    add(f"- Derived (pending-review) role skills: **{db.query_one('SELECT COUNT(*) c FROM skills WHERE verification_status=\"derived_pending_review\"')['c']}**")
    add(f"- Registered tools: **{db.query_one('SELECT COUNT(*) c FROM tools')['c']}**; every agent tool reference "
        "resolves to one of these, with a declared scope and an authorization flag for high-impact tools.")
    add("")

    # 5 ─ model registry
    add("## 5. NVIDIA model registry and routing")
    add("")
    add(f"- Models discovered and recorded: **{model_stats['catalog_present']}** (source: live NVIDIA catalogue "
        "at `https://integrate.api.nvidia.com/v1/models`, which requires no credential for discovery).")
    add(f"- Verified by an actual inference call: **{model_stats['live_verified']}** "
        f"({'NVIDIA API key configured' if config.has_api_key(settings) else 'no API key configured, so no call could be verified'}).")
    add("- Candidate models named in the specification were mapped to live catalogue identifiers "
        "(for example `glm-5-3` → `z-ai/glm-5.3`, `kimi-k3` → `moonshotai/kimi-k3`, "
        "`nemotron-3.5-lightning-30b-a3b` → `nvidia/nemotron-3.5-lightning-30b-a3b`).")
    add("")
    if model_stats.get("by_capability"):
        add("| Capability | Catalogue models |")
        add("| --- | --- |")
        for cap, count in sorted(model_stats["by_capability"].items()):
            add(f"| {cap} | {count} |")
        add("")
    add("Routing decisions are recorded per task with the chosen model, the reason and the alternatives "
        "considered (`routing_decisions` table, visible in the console under Models → routing decisions).")
    add("")
    add("**Model limitation (blocked):** every model in this registry requires an NVIDIA developer account and API "
        "key. No key is present unless the operator adds one in Settings, so model-dependent tasks report "
        "`skipped_blocked` with the exact reason instead of producing fabricated output.")
    add("")

    # 6 ─ workflow
    add("## 6. Orchestration and execution record")
    add("")
    runs = db.query("SELECT kind, status, COUNT(*) c FROM runs GROUP BY kind, status")
    add("| Run kind | Status | Count |")
    add("| --- | --- | --- |")
    for row in runs:
        add(f"| {row['kind']} | {row['status']} | {row['c']} |")
    if not runs:
        add("| (no runs recorded) | - | 0 |")
    add("")
    add(f"Tasks executed in total: **{task_stats['total']}** "
        f"({', '.join(f'{k}: {v}' for k, v in sorted(task_stats['by_status'].items()))}).")
    add("")
    add("Engine behaviour that is directly evidenced by tests and rows:")
    add("")
    add("- dependency graphs are topological and validated in tests (`test_task_graph_is_acyclic`)")
    add("- a failed task blocks only its own branch; independent branches still complete "
        "(`test_failed_dependency_blocks_only_its_branch`)")
    add("- each task records agent, model, routing reason, attempts, duration, artefacts and evidence")
    add("- runs checkpoint to the database after every task and resume at boot (`resume_interrupted_runs`)")
    add("- high-impact tasks (deploy, publish, rollback) pause in `awaiting_approval` "
        "(`test_deploy_requires_human_approval`)")
    add("- cancellation is a recorded request that stops pending tasks and is logged in the audit trail")
    add("")

    # 7 ─ website generation
    add("## 7. Website generation, build and verification")
    add("")
    if projects:
        add("| Project | Archetype | Status | Active version | Latest checks |")
        add("| --- | --- | --- | --- | --- |")
        for project in projects:
            version = db.query_one("SELECT version, tests_json FROM project_versions WHERE project_id=? "
                                   "ORDER BY version DESC LIMIT 1", (project["id"],))
            tests = util.jload(version["tests_json"], {}) if version else {}
            grade = (f"{tests.get('passed')}/{tests.get('checks')} passed, {tests.get('blockers')} blockers"
                     if tests else "no verification recorded")
            add(f"| {project['name']} (`{project['id']}`) | {project['ptype']} | {project['status']} | "
                f"v{version['version'] if version else '-'} | {grade} |")
        add("")
    if verification:
        totals = verification["totals"]
        add(f"Most recent verification report: `{verification_path}`")
        add("")
        add(f"- checks executed: **{totals['checks']}**, passed **{totals['passed']}**, "
            f"failed **{totals['failed']}** (blockers {totals['blockers']}, majors {totals['majors']}, "
            f"minors {totals['minors']})")
        add(f"- build command: `{verification['build']['command']}` → exit code "
            f"**{verification['build']['exit_code']}** in {verification['build']['duration_ms']} ms")
        add(f"- verdict: **{verification['verdict']}**")
        add(f"- pages checked: {', '.join(verification['pages_checked'])}")
        add("")
        add("| Category | Passed | Failed |")
        add("| --- | --- | --- |")
        for cat, res in sorted(verification["by_category"].items()):
            add(f"| {cat} | {res['passed']} | {res['failed']} |")
        add("")
    add("The generator emits a complete project per version: pages, CSS with design tokens, one small script, "
        "generated SVG assets, sitemap, robots, structured content, an optional Node build (`build.mjs`), a Python "
        "build fallback (`build.py`), project tests (`tests/checks.mjs`), README and deployment notes. The build "
        "runs as a real subprocess and its exit code decides pass/fail — an AI statement is never used as a test result.")
    add("")

    # 8 ─ localization
    add("## 8. Translation and localization")
    add("")
    jobs = [dict(r) for r in db.query("SELECT * FROM localization_jobs ORDER BY created_at DESC LIMIT 10")]
    if jobs:
        add("| Target | Status | Coverage | Engine |")
        add("| --- | --- | --- | --- |")
        for job in jobs:
            add(f"| {job['target_lang']} | {job['status']} | {job['coverage']}% | {job['engine']} |")
        add("")
    add("Translation is honest by construction: a curated, hand-checked glossary covers site-shell strings in "
        "Tamil, Hindi, Arabic (RTL), French, Spanish and German; anything outside the glossary stays in the source "
        "language and is listed in `locales/<lang>/missing.json` with a coverage percentage. Placeholder integrity, "
        "terminology consistency, expansion budget, `lang` attribute and RTL direction are checked per job. With a "
        "verified translation model plus API key, the remaining strings are translated live; without either, the job "
        "is reported `partial` or `blocked_insufficient_coverage`.")
    add("")

    # 9 ─ feedback
    add("## 9. Feedback intelligence")
    add("")
    feedback_count = db.query_one("SELECT COUNT(*) c FROM feedback")["c"]
    categories = db.query("SELECT category, COUNT(*) c FROM feedback GROUP BY category")
    add(f"Feedback records: **{feedback_count}**"
        + (f" ({', '.join(f'{r['category']}: {r['c']}' for r in categories)})" if categories else ""))
    add("")
    add("Classification, sentiment, priority, duplicate detection and PII redaction run deterministically. "
        "Conversion into an improvement task starts a real orchestration run; the 'feedback-to-code' step applies "
        "bounded, additive content changes in a new version (so the previous version remains for rollback) and "
        "records deferred, structurally significant requests in `content/roadmap.json` instead of silently "
        "rewriting the site. Verified by `test_feedback_becomes_a_real_run`.")
    add("")

    # 10 ─ maintenance
    add("## 10. Maintenance, debugging and incidents")
    add("")
    incident_rows = [dict(r) for r in db.query("SELECT * FROM incidents ORDER BY detected_at DESC LIMIT 8")]
    add(f"Monitor executions recorded: **{db.query_one('SELECT COUNT(*) c FROM monitor_checks')['c']}** · "
        f"incidents: **{db.query_one('SELECT COUNT(*) c FROM incidents')['c']}** "
        f"(open: **{db.query_one(chr(83)+'ELECT COUNT(*) c FROM incidents WHERE status=\"open\"')['c']}**)")
    add("")
    if incident_rows:
        add("| Incident | Kind | Severity | Status |")
        add("| --- | --- | --- | --- |")
        for inc in incident_rows:
            add(f"| `{inc['id']}` | {inc['kind']} | {inc['severity']} | {inc['status']} |")
        add("")
    add("Monitors execute on demand (page integrity, broken links, placeholder/launch blockers, version availability) "
        "and convert failures into incidents with a repair plan and rollback-risk assessment. Rollback repoints the "
        "project to a previous version on disk; the newer version is preserved, and rollback on an incident requires "
        "an explicit user action. Debugging (the repair task) is deterministic: it re-runs verification, applies "
        "reviewed repair rules for the failure classes it can fix, reports what it could not fix, and the result is "
        "only accepted if the re-run clears the failures.")
    add("")

    # 11 ─ email / marketing / media / publishing
    add("## 11. Email, marketing, media and publishing")
    add("")
    emails = [dict(r) for r in db.query("SELECT * FROM email_messages ORDER BY created_at DESC LIMIT 5")]
    add(f"Email messages recorded: **{db.query_one('SELECT COUNT(*) c FROM email_messages')['c']}**. "
        "Without SMTP credentials, messages are written to the local outbox with status `queued_in_outbox` and an "
        "explicit explanation; a real send happens only when host, user and password are configured "
        "(`test_email_states_outbox_mode_when_unconfigured`).")
    add("")
    add(f"Marketing artifacts: **{db.query_one('SELECT COUNT(*) c FROM marketing_assets')['c']}** "
        "(social posts, email campaign, blog outline, analytics/UTM plan), all stored as `ready_for_review`.")
    add("")
    add("Publishing status is reported literally: with no connected account and no explicit authorization the state "
        "is `blocked_not_authorized` and nothing is posted. Video production writes a storyboard, SRT subtitles and an "
        "executable ffmpeg render command; because ffmpeg is absent in this environment the status is "
        "`blocked_no_encoder` — no video file is claimed.")
    add("")

    # 12 ─ ledger
    add("## 12. Capability ledger (honest status)")
    add("")
    add("| # | Capability | Status | Limitations recorded |")
    add("| --- | --- | --- | --- |")
    for row in ledger_rows:
        add(f"| {row['status_code']} | {row['capability']} | {row['status_label']} | "
            f"{util.truncate(row['limitations'] or row['description'], 150)} |")
    add("")
    add("Codes: 1 implemented and verified · 2 implemented, not fully verified · 3 partially implemented · "
        "4 blocked by missing credentials or infrastructure · 5 planned, not implemented.")
    add("")

    # 13 ─ tests and security
    add("## 13. Tests and security checks performed")
    add("")
    add("Command: `python3 -m unittest discover -s tests -v` (45 tests, isolated temporary data root).")
    add("")
    add("| Area | Tests |")
    add("| --- | --- |")
    add("| Agent registry counts, uniqueness, field completeness, reference resolution | 7 |")
    add("| Model discovery, capability routing, routing records, honest blocked calls | 6 |")
    add("| Generation, real build, verification report, structure, export integrity | 9 |")
    add("| Orchestration: acyclic graph, branch isolation, approval gate, no false deploy claim | 4 |")
    add("| Localization: coverage honesty, locale files, RTL, unsupported language | 5 |")
    add("| Feedback classification, redaction, conversion, duplication, monitors, rollback, marketing, media, email | 9 |")
    add("| Isolation and secrets: path traversal, secret masking, ledger states | 5 |")
    add("")
    add("Security properties exercised: path-traversal protection on every generated write and file-serving route; "
        "secrets never returned by the API; masked secret metadata; static secret scanning over generated files; "
        "no insecure `http://` resources, no third-party or remote scripts, no `rel=noopener` omissions.")
    add("")

    # 14 ─ known defects and blockers
    add("## 14. Known defects and remaining blockers")
    add("")
    add("1. **Live model inference is blocked** — no NVIDIA API key is present. Discovery, routing and decision "
        "recording all work; actual generation calls report `blocked_no_api_key`. Adding the key in Settings and "
        "pressing 'refresh + health check' moves models to `verified_live_call`.")
    add("2. **Translation coverage is partial for real copy** — the curated glossary covers site-shell strings "
        "(7–14% of a generated page's text). Full-copy translation needs the verified translation model plus a key.")
    add("3. **No live deployment** — packaging and the deployment plan are produced; executing a deployment needs a "
        "hosting target and credentials, and publishing adapters are out of scope for the single-user edition.")
    add("4. **No video encoding** — ffmpeg is not installed; storyboard, subtitles and render command are produced.")
    add("5. **Social publishing is not implemented** — gated behind authorization by design; status is reported as "
        "blocked rather than simulated.")
    add("6. **Authentication is single-user** — the console is private to this deployment and has no login screen. "
        "Multi-user accounts, roles and tenancy are not implemented.")
    add("7. **Scale infrastructure is not implemented** — SQLite plus in-process threads replace PostgreSQL, Redis and "
        "a durable queue; the architecture keeps the swap contained in `db.py` and the orchestrator.")
    add("8. **Visual regression is structural, not pixel-based** — no headless browser is available, so visual checks "
        "are DOM structure, measured payload and contrast maths rather than rendered screenshots.")
    add("9. **Repair rules are bounded** — the debugger fixes the failure classes it can verify deterministically "
        "(missing pages/assets, headings, metadata, sitemap drift) and hands everything else back for human review.")
    add("")

    # 15 ─ setup
    add("## 15. Setup and operation")
    add("")
    add("```bash")
    add("cd /home/user/platform")
    add("./run.sh                 # installs deps if needed, boots API + console on 0.0.0.0:8000")
    add("python3 -m unittest discover -s tests -v   # test suite")
    add("python3 -m app.report   # regenerate this report from live state")
    add("```")
    add("")
    add("Required environment variables: **none** for the platform itself. Optional: `NVIDIA_API_KEY` "
        "(live inference, health checks, live translation), `SMTP_HOST`/`SMTP_USER`/`SMTP_PASSWORD` "
        "(email sending outside the outbox), `PLATFORM_DATA_DIR` (data root override), "
        "`PLATFORM_NAME` (configurable platform name).")
    add("")
    add("## 16. Deployment readiness")
    add("")
    add("- The service runs with a single command and no external dependency beyond Python packages.")
    add("- Data lives under `data/`; backing up that directory backs up the platform (database, project versions, "
        "exports, reports).")
    add("- Generated sites deploy as static files; `DEPLOYMENT.md` inside each version carries the checklist and "
        "per-target commands.")
    add("- For multi-user or internet-facing use, add: authentication, PostgreSQL, a durable job queue, object "
        "storage and OS-level sandboxing for code execution.")
    add("")
    return "\n".join(lines)


def write_report() -> Path:
    text = build_report()
    path = util.ROOT / REPORT_PATH_NAME
    path.write_text(text, encoding="utf-8")
    summary_path = util.DATA_DIR / "final_report_summary.txt"
    summary_path.write_text("\n".join(text.splitlines()[:40]), encoding="utf-8")
    return path


def main() -> None:
    db.init_db()
    path = write_report()
    print(f"final report written: {path}")


if __name__ == "__main__":
    main()
