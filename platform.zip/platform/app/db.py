"""SQLite persistence layer: schema, migrations, helpers."""
from __future__ import annotations

import sqlite3
import threading
from contextlib import contextmanager
from typing import Any, Iterable

from . import config, util

SCHEMA = """
PRAGMA journal_mode=WAL;
PRAGMA foreign_keys=ON;

CREATE TABLE IF NOT EXISTS settings (
  key TEXT PRIMARY KEY, value TEXT NOT NULL, updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS projects (
  id TEXT PRIMARY KEY, name TEXT NOT NULL, prompt TEXT NOT NULL,
  ptype TEXT, industry TEXT, status TEXT NOT NULL DEFAULT 'intake',
  active_version INTEGER NOT NULL DEFAULT 0,
  brief_json TEXT, requirements_json TEXT, plan_json TEXT, research_json TEXT,
  resources_json TEXT, arch_json TEXT, design_json TEXT, stack_json TEXT,
  acceptance_json TEXT, deploy_json TEXT, blueprint_json TEXT,
  created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS project_versions (
  id INTEGER PRIMARY KEY AUTOINCREMENT, project_id TEXT NOT NULL,
  version INTEGER NOT NULL, label TEXT, notes TEXT, root TEXT, manifest_json TEXT,
  tests_json TEXT, created_at TEXT NOT NULL,
  UNIQUE(project_id, version)
);

CREATE TABLE IF NOT EXISTS runs (
  id TEXT PRIMARY KEY, project_id TEXT, kind TEXT NOT NULL, status TEXT NOT NULL,
  request_json TEXT, summary_json TEXT, error TEXT,
  started_at TEXT NOT NULL, finished_at TEXT, cancel_requested INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS tasks (
  id TEXT PRIMARY KEY, run_id TEXT NOT NULL, project_id TEXT, seq INTEGER,
  name TEXT NOT NULL, department TEXT, agent_id TEXT, status TEXT NOT NULL,
  depends_on_json TEXT, input_json TEXT, output_json TEXT, artifacts_json TEXT,
  model_id TEXT, model_reason TEXT, attempts INTEGER DEFAULT 0,
  started_at TEXT, finished_at TEXT, duration_ms INTEGER, error TEXT,
  human_approval_required INTEGER DEFAULT 0, approved_at TEXT
);

CREATE TABLE IF NOT EXISTS task_logs (
  id INTEGER PRIMARY KEY AUTOINCREMENT, task_id TEXT, run_id TEXT,
  ts TEXT NOT NULL, level TEXT, message TEXT
);

CREATE TABLE IF NOT EXISTS artifacts (
  id TEXT PRIMARY KEY, project_id TEXT, run_id TEXT, task_id TEXT,
  kind TEXT, label TEXT, path TEXT, bytes INTEGER, sha256 TEXT, created_at TEXT
);

CREATE TABLE IF NOT EXISTS agents (
  id TEXT PRIMARY KEY, gid INTEGER UNIQUE NOT NULL, name TEXT NOT NULL,
  department TEXT NOT NULL, group_type TEXT NOT NULL, purpose TEXT, instructions TEXT,
  responsibilities_json TEXT, skills_json TEXT, eligible_models_json TEXT,
  preferred_criteria TEXT, fallback_criteria TEXT, tools_json TEXT,
  input_schema_json TEXT, output_schema_json TEXT, required_context_json TEXT,
  dependencies_json TEXT, expected_artifacts_json TEXT, quality_checks_json TEXT,
  security_restrictions_json TEXT, timeout_s INTEGER, retry_policy_json TEXT,
  concurrency_policy TEXT, human_approval TEXT, success_criteria_json TEXT,
  failure_format TEXT, definition_version TEXT, created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_agents_dept ON agents(department);
CREATE INDEX IF NOT EXISTS idx_agents_group ON agents(group_type);

CREATE TABLE IF NOT EXISTS agent_runs (
  id INTEGER PRIMARY KEY AUTOINCREMENT, agent_id TEXT, run_id TEXT, task_id TEXT,
  status TEXT, model_id TEXT, started_at TEXT, finished_at TEXT,
  duration_ms INTEGER, result_summary TEXT, error TEXT
);

CREATE TABLE IF NOT EXISTS models (
  id TEXT PRIMARY KEY, provider TEXT, display_name TEXT, source_url TEXT,
  deployment_mode TEXT, capabilities_json TEXT, input_modalities_json TEXT,
  output_modalities_json TEXT, tool_calling INTEGER, structured_output INTEGER,
  context_window TEXT, auth_required INTEGER, endpoint TEXT, access_restrictions TEXT,
  usage_limits TEXT, verification_status TEXT, verified_at TEXT, health_checked_at TEXT,
  last_failure TEXT, agent_eligibility_json TEXT, fallback_candidates_json TEXT, notes TEXT,
  discovered_from TEXT, catalog_present INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS routing_decisions (
  id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT NOT NULL, capability TEXT,
  run_id TEXT, task_id TEXT, agent_id TEXT, chosen_model TEXT, reason TEXT,
  candidates_json TEXT, status TEXT, provider_called INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS skills (
  id TEXT PRIMARY KEY, name TEXT, category TEXT, description TEXT, verification_status TEXT
);

CREATE TABLE IF NOT EXISTS tools (
  id TEXT PRIMARY KEY, name TEXT, scope TEXT, description TEXT, execution TEXT
);

CREATE TABLE IF NOT EXISTS resources (
  id TEXT PRIMARY KEY, name TEXT, category TEXT, source_url TEXT, license TEXT,
  license_verified INTEGER, verification_method TEXT, version TEXT, notes TEXT,
  project_id TEXT, used INTEGER DEFAULT 0, created_at TEXT
);

CREATE TABLE IF NOT EXISTS feedback (
  id TEXT PRIMARY KEY, project_id TEXT, channel TEXT, author TEXT, text TEXT,
  category TEXT, sentiment TEXT, sentiment_score REAL, priority TEXT,
  duplicate_of TEXT, status TEXT, linked_task_id TEXT, analysis_json TEXT,
  created_at TEXT
);

CREATE TABLE IF NOT EXISTS incidents (
  id TEXT PRIMARY KEY, project_id TEXT, kind TEXT, severity TEXT, detected_at TEXT,
  source TEXT, detail TEXT, status TEXT, resolved_at TEXT, repair_task_id TEXT,
  rollback_version INTEGER, created_at TEXT
);

CREATE TABLE IF NOT EXISTS localization_jobs (
  id TEXT PRIMARY KEY, project_id TEXT, source_lang TEXT, target_lang TEXT,
  status TEXT, engine TEXT, coverage REAL, checks_json TEXT, artifacts_json TEXT,
  created_at TEXT, finished_at TEXT
);

CREATE TABLE IF NOT EXISTS marketing_assets (
  id TEXT PRIMARY KEY, project_id TEXT, kind TEXT, channel TEXT, title TEXT, body TEXT,
  status TEXT, created_at TEXT
);

CREATE TABLE IF NOT EXISTS email_messages (
  id TEXT PRIMARY KEY, project_id TEXT, direction TEXT, to_addr TEXT, from_addr TEXT,
  subject TEXT, body TEXT, status TEXT, detail TEXT, created_at TEXT
);

CREATE TABLE IF NOT EXISTS monitor_checks (
  id INTEGER PRIMARY KEY AUTOINCREMENT, project_id TEXT, ts TEXT, kind TEXT, target TEXT,
  ok INTEGER, latency_ms INTEGER, detail TEXT
);

CREATE TABLE IF NOT EXISTS ledger (
  id TEXT PRIMARY KEY, capability TEXT, description TEXT, status_code INTEGER,
  status_label TEXT, evidence TEXT, limitations TEXT, updated_at TEXT
);

CREATE TABLE IF NOT EXISTS audit_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT, actor TEXT, action TEXT, target TEXT,
  detail_json TEXT
);

CREATE TABLE IF NOT EXISTS secrets_meta (
  key TEXT PRIMARY KEY, present INTEGER, masked TEXT, updated_at TEXT
);
"""

_local = threading.local()


def connect() -> sqlite3.Connection:
    util.ensure_dirs()
    conn = sqlite3.connect(util.DB_PATH, timeout=30, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys=ON")
    return conn


@contextmanager
def cursor():
    conn = connect()
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


MIGRATIONS = {
    "projects": ["blueprint_json TEXT"],
}


def ensure_columns() -> list[str]:
    """Non-destructive schema migration: add columns that older databases lack."""
    added = []
    with cursor() as conn:
        for table, columns in MIGRATIONS.items():
            existing = {row["name"] for row in conn.execute(f"PRAGMA table_info({table})")}
            for column in columns:
                name = column.split()[0]
                if name not in existing:
                    conn.execute(f"ALTER TABLE {table} ADD COLUMN {column}")
                    added.append(f"{table}.{name}")
    return added


def init_db() -> None:
    util.ensure_dirs()
    with cursor() as conn:
        conn.executescript(SCHEMA)
    added = ensure_columns()
    seed_settings()
    seed_ledger()
    if added:
        audit("system", "schema_migration", "db", {"added": added})


def query(sql: str, params: Iterable[Any] = ()) -> list[sqlite3.Row]:
    conn = connect()
    try:
        return list(conn.execute(sql, tuple(params)))
    finally:
        conn.close()


def query_one(sql: str, params: Iterable[Any] = ()):
    rows = query(sql, params)
    return rows[0] if rows else None


def execute(sql: str, params: Iterable[Any] = ()) -> int:
    with cursor() as conn:
        cur = conn.execute(sql, tuple(params))
        return cur.rowcount


def insert(table: str, row: dict) -> None:
    cols = ", ".join(row.keys())
    marks = ", ".join("?" for _ in row)
    with cursor() as conn:
        conn.execute(f"INSERT INTO {table} ({cols}) VALUES ({marks})", tuple(row.values()))


def upsert(table: str, row: dict, key: str) -> None:
    cols = ", ".join(row.keys())
    marks = ", ".join("?" for _ in row)
    with cursor() as conn:
        conn.execute(
            f"INSERT INTO {table} ({cols}) VALUES ({marks}) "
            f"ON CONFLICT({key}) DO UPDATE SET "
            + ", ".join(f"{c}=excluded.{c}" for c in row.keys() if c != key),
            tuple(row.values()),
        )


# --------------------------------------------------------------------------
# settings
# --------------------------------------------------------------------------

SECRET_KEYS = {"nvidia_api_key", "smtp_password"}


def seed_settings() -> None:
    for key, value in config.DEFAULT_SETTINGS.items():
        row = query_one("SELECT key, value FROM settings WHERE key=?", (key,))
        env_override = None
        if key == "nvidia_api_key":
            env_override = None  # already folded into DEFAULT_SETTINGS
        if row is None:
            insert("settings", {"key": key, "value": str(value), "updated_at": util.now_iso()})
            if key in SECRET_KEYS and str(value):
                refresh_secret_meta()
        elif env_override is not None:
            execute("UPDATE settings SET value=? WHERE key=?", (str(env_override), key))


def get_settings(masked: bool = False) -> dict:
    out = {k: v for k, v in config.DEFAULT_SETTINGS.items()}
    for row in query("SELECT key, value FROM settings"):
        out[row["key"]] = row["value"]
    if masked:
        for key in SECRET_KEYS:
            value = str(out.get(key, ""))
            out[key] = ""
            out[f"{key}_present"] = bool(value.strip())
    return out


def set_setting(key: str, value: str) -> None:
    upsert("settings", {"key": key, "value": str(value), "updated_at": util.now_iso()}, "key")
    if key in SECRET_KEYS:
        refresh_secret_meta()


def refresh_secret_meta() -> None:
    settings = get_settings()
    for key in SECRET_KEYS:
        value = str(settings.get(key, "") or "")
        masked = (value[:3] + "…" + value[-4:]) if len(value) > 10 else ("set" if value else "")
        upsert(
            "secrets_meta",
            {
                "key": key,
                "present": 1 if value else 0,
                "masked": masked,
                "updated_at": util.now_iso(),
            },
            "key",
        )


# --------------------------------------------------------------------------
# ledger / audit
# --------------------------------------------------------------------------


def seed_ledger() -> None:
    for cap_id, description, code in config.LEDGER_SEED:
        row = query_one("SELECT * FROM ledger WHERE id=?", (cap_id,))
        payload = {
            "id": cap_id,
            "capability": cap_id.replace("_", " ").title(),
            "description": description,
            "status_code": code,
            "status_label": config.ledger_label(code),
            "evidence": row["evidence"] if row else "",
            "limitations": row["limitations"] if row else "",
            "updated_at": util.now_iso(),
        }
        upsert("ledger", payload, "id")


def ledger_set(cap_id: str, code: int, evidence: str = "", limitations: str = "") -> None:
    row = query_one("SELECT * FROM ledger WHERE id=?", (cap_id,))
    payload = {
        "id": cap_id,
        "capability": row["capability"] if row else cap_id.replace("_", " ").title(),
        "description": row["description"] if row else "",
        "status_code": code,
        "status_label": config.ledger_label(code),
        "evidence": evidence or (row["evidence"] if row else ""),
        "limitations": limitations or (row["limitations"] if row else ""),
        "updated_at": util.now_iso(),
    }
    upsert("ledger", payload, "id")


def audit(actor: str, action: str, target: str = "", detail: dict | None = None) -> None:
    insert(
        "audit_log",
        {
            "ts": util.now_iso(),
            "actor": actor,
            "action": action,
            "target": target,
            "detail_json": util.jdump(detail or {}),
        },
    )


def log_task(task_id: str, run_id: str, level: str, message: str) -> None:
    insert(
        "task_logs",
        {
            "task_id": task_id,
            "run_id": run_id,
            "ts": util.now_iso(),
            "level": level,
            "message": util.truncate(message, 2000),
        },
    )
