"""Department engines. Each function performs real work and returns structured
results with evidence. Nothing here returns fabricated success.
"""
from __future__ import annotations

import json
import re
import shutil
import subprocess
import urllib.request
import zipfile
from pathlib import Path
from xml.etree import ElementTree

from . import db, generation, models, util, verify

# ===========================================================================
# 1. Intake and requirements
# ===========================================================================


def intake(project: dict) -> dict:
    prompt = project["prompt"]
    archetype, label = generation.classify_archetype(prompt)
    low = prompt.lower()
    name = extract_name(prompt) or project.get("name") or "Your Business"
    audience = extract_audience(prompt)
    goals = extract_goals(prompt, archetype)
    services = [s for s in generation.DEFAULT_SERVICES.get(archetype, [])]
    open_questions = []
    if "email" not in low and not re.search(r"[\w.+-]+@[\w-]+\.\w+", prompt):
        open_questions.append("Which email address should receive enquiries?")
    if not re.search(r"(\+?\d[\d\s-]{7,})", prompt):
        open_questions.append("Which phone number should be published?")
    if "address" not in low and not re.search(r"\b(street|road|nagar|city|pincode|pin code)\b", low):
        open_questions.append("What address should be published for the business?")
    if archetype in {"ecommerce", "saas"} and "price" not in low and "₹" not in prompt and "$" not in prompt:
        open_questions.append("What pricing model should be shown (free, tiers, quote-based)?")
    brief = {
        "name": name,
        "archetype": archetype,
        "archetype_label": label,
        "audience": audience,
        "goals": goals,
        "description": util.first_sentences(prompt, 3),
        "deliverable": "static multi-page website",
        "languages": generation.detect_languages(prompt),
        "constraints": extract_constraints(prompt),
        "assumptions": build_assumptions(project, archetype),
        "open_questions": open_questions,
        "ambiguity_score": ambiguity_score(prompt, open_questions),
        "services_detected": [s["title"] for s in services],
    }
    requirements = {
        "functional": [
            {"id": "FR-01", "text": f"Public multi-page site for {name} covering: " + ", ".join(p["title"] for p in generation.build_blueprint(project)["pages"]) + ".", "priority": "must"},
            {"id": "FR-02", "text": "Every page renders semantic HTML with unique title and meta description.", "priority": "must"},
            {"id": "FR-03", "text": "Contact page provides a validated enquiry form with success and error states.", "priority": "must"},
            {"id": "FR-04", "text": "Mobile-first responsive layout from 320px upward.", "priority": "must"},
            {"id": "FR-05", "text": "Structured data (schema.org) published on every page.", "priority": "should"},
            {"id": "FR-06", "text": "Sitemap and robots.txt generated and consistent with the page list.", "priority": "should"},
        ],
        "non_functional": [
            {"id": "NFR-01", "text": "Accessible: labelled controls, contrast-checked tokens, keyboard reachable navigation.", "category": "accessibility"},
            {"id": "NFR-02", "text": "Total HTML payload under 400 KB across the site.", "category": "performance"},
            {"id": "NFR-03", "text": "No secrets, insecure http:// resources, or third-party scripts.", "category": "security"},
            {"id": "NFR-04", "text": "Deployable as static files with no runtime dependency.", "category": "operations"},
        ],
        "out_of_scope": extract_out_of_scope(prompt),
        "acceptance": [
            "Build command completes with exit code 0.",
            "All deterministic checks pass with zero blockers and zero majors.",
            "Preview renders every generated page.",
        ],
        "services": services,
        "features": generation.DEFAULT_FEATURES,
    }
    evidence = [f"prompt_hash={util.sha256_text(prompt)[:16]}", f"detected_archetype={archetype}",
                f"open_questions={len(open_questions)}"]
    db.audit("intake", "requirements_extracted", project["id"], {"archetype": archetype, "questions": len(open_questions)})
    return {"brief": brief, "requirements": requirements, "evidence": evidence,
            "summary": f"Brief for {name} ({label}); {len(open_questions)} clarification question(s) queued."}


def extract_name(prompt: str) -> str:
    patterns = [
        r"(?:called|named|for)\s+[\"']?([A-Z][\w&'\-. ]{2,40}?)[\"']?(?:[.,\n]|$)",
        r"^([A-Z][\w&'\-.]{2,40}?)\s+(?:is a|is an|website|site)\b",
    ]
    for pattern in patterns:
        m = re.search(pattern, prompt, re.MULTILINE)
        if m:
            candidate = util.squeeze(m.group(1))
            if len(candidate.split()) <= 6:
                return candidate
    return ""


def extract_audience(prompt: str) -> str:
    low = prompt.lower()
    for cue in ["for families", "for students", "for small businesses", "for families and students",
                "for professionals", "for tourists", "for patients", "for corporate clients"]:
        if cue in low:
            return cue[4:]
    m = re.search(r"\bfor ([a-z][\w\s]{3,40}?)(?:[.,;]|$)", low)
    return util.squeeze(m.group(1)) if m else "local customers"


def extract_goals(prompt: str, archetype: str) -> list[str]:
    low = prompt.lower()
    goals = []
    mapping = {"booking": "take bookings", "enquir": "generate enquiries", "contact": "make contact easy",
               "sell": "sell products", "seo": "rank in search", "brand": "strengthen the brand",
               "portfolio": "showcase work", "lead": "capture leads", "menu": "publish the menu"}
    for key, goal in mapping.items():
        if key in low and goal not in goals:
            goals.append(goal)
    if not goals:
        goals = {"ecommerce": ["sell products", "build trust"],
                 "saas": ["capture signups", "explain the product"],
                 "restaurant": ["take bookings", "publish the menu"]}.get(archetype, ["generate enquiries", "build trust"])
    return goals[:4]


def extract_constraints(prompt: str) -> list[str]:
    out = []
    low = prompt.lower()
    if "tamil" in low:
        out.append("Tamil language support requested")
    if "no javascript" in low or "without javascript" in low:
        out.append("must work without JavaScript")
    if "cheap" in low or "budget" in low:
        out.append("budget-sensitive")
    if "no stock photo" in low or "no stock photos" in low:
        out.append("no stock photography")
    if "seo" in low:
        out.append("search visibility is a priority")
    return out


def extract_out_of_scope(prompt: str) -> list[str]:
    low = prompt.lower()
    scope = ["multi-tenant accounts", "payments processing", "mobile app binaries"]
    if "payment" in low or "checkout" in low:
        scope = [s for s in scope if s != "payments processing"]
    if "login" in low or "account" in low or "dashboard" in low:
        scope = [s for s in scope if s != "multi-tenant accounts"]
    return scope


def build_assumptions(project: dict, archetype: str) -> list[str]:
    return [
        "Content that is not supplied is generated as clearly-labelled placeholder copy that must be reviewed before publication.",
        "Images are generated placeholder illustrations rather than unlicensed stock photography.",
        "Static hosting is assumed; no server-side runtime is required for the delivered site.",
        f"Archetype '{archetype}' section ordering follows the platform's blueprint library and may be reordered by the user.",
    ]


def ambiguity_score(prompt: str, open_questions: list[str]) -> float:
    words = util.word_count(prompt)
    score = max(0.0, 1.0 - (words / 120.0)) * 0.6 + min(len(open_questions), 4) * 0.1
    return round(min(score, 1.0), 2)


# ===========================================================================
# 2. Planning
# ===========================================================================


def plan(project: dict, requirements: dict) -> dict:
    tasks = [
        {"id": "T01", "name": "Intake and requirements", "department": "intake", "depends_on": []},
        {"id": "T02", "name": "Planning and task decomposition", "department": "planning", "depends_on": ["T01"]},
        {"id": "T03", "name": "Technical research and stack selection", "department": "research", "depends_on": ["T02"]},
        {"id": "T04", "name": "Open-source resource discovery", "department": "oss", "depends_on": ["T03"]},
        {"id": "T05", "name": "License verification and attribution", "department": "licensing", "depends_on": ["T04"]},
        {"id": "T06", "name": "Information architecture and sitemap", "department": "ux", "depends_on": ["T02"]},
        {"id": "T07", "name": "Architecture and data contracts", "department": "architecture", "depends_on": ["T03"]},
        {"id": "T08", "name": "UI/UX and design system", "department": "design", "depends_on": ["T06", "T07"]},
        {"id": "T09", "name": "Content authoring", "department": "content", "depends_on": ["T08"]},
        {"id": "T10", "name": "Website generation", "department": "frontend", "depends_on": ["T08", "T09"]},
        {"id": "T11", "name": "Build execution", "department": "devops", "depends_on": ["T10"]},
        {"id": "T12", "name": "Application and accessibility testing", "department": "qa", "depends_on": ["T11"]},
        {"id": "T13", "name": "SEO and performance review", "department": "seo", "depends_on": ["T11"]},
        {"id": "T14", "name": "Security review", "department": "security", "depends_on": ["T11"]},
        {"id": "T15", "name": "Debugging and repair", "department": "debugging", "depends_on": ["T12", "T13", "T14"]},
        {"id": "T16", "name": "Acceptance verification", "department": "qa", "depends_on": ["T15"]},
        {"id": "T17", "name": "Deployment preparation", "department": "devops", "depends_on": ["T16"]},
    ]
    return {
        "strategy": "smallest effective task set for a static marketing site",
        "tasks": tasks,
        "critical_path": ["T01", "T02", "T08", "T10", "T11", "T12", "T15", "T16", "T17"],
        "parallelizable": [["T03", "T06"], ["T12", "T13", "T14"]],
        "excluded_departments": ["middleware", "maintenance", "media", "marketing", "email"],
        "exclusion_reason": "The request is a static marketing site; middleware, media production and campaign work are not required to satisfy it.",
        "milestones": [
            {"name": "M1 Specification", "tasks": ["T01", "T02", "T03", "T04", "T05", "T06", "T07"]},
            {"name": "M2 Implementation", "tasks": ["T08", "T09", "T10"]},
            {"name": "M3 Verification", "tasks": ["T11", "T12", "T13", "T14", "T15", "T16"]},
            {"name": "M4 Delivery", "tasks": ["T17"]},
        ],
    }


RESOURCE_LIBRARY = [
    {"name": "System font stack", "category": "typography", "source_url": "https://developer.mozilla.org/docs/Web/CSS/font-family", "license": "platform documentation (CC-BY-SA 2.5 for MDN text)", "used": True, "note": "No webfont download; zero network cost."},
    {"name": "schema.org LocalBusiness vocabulary", "category": "structured_data", "source_url": "https://schema.org/LocalBusiness", "license": "CC BY-SA 3.0 (vocabulary)", "used": True, "note": "Used for JSON-LD blocks."},
    {"name": "Sitemaps protocol 0.9", "category": "seo", "source_url": "https://www.sitemaps.org/protocol.html", "license": "public specification", "used": True},
    {"name": "WCAG 2.2 success criteria", "category": "accessibility", "source_url": "https://www.w3.org/TR/WCAG22/", "license": "W3C document licence", "used": True, "note": "Criteria referenced by the automated checks."},
    {"name": "Node.js runtime (build tooling)", "category": "tooling", "source_url": "https://nodejs.org/", "license": "MIT", "used": True, "note": "Used only for the optional build step."},
    {"name": "Bootstrap", "category": "css_framework", "source_url": "https://getbootstrap.com/", "license": "MIT", "used": False, "note": "Evaluated and rejected: adds ~30KB CSS for layout the platform already emits."},
    {"name": "Tailwind CSS", "category": "css_framework", "source_url": "https://tailwindcss.com/", "license": "MIT", "used": False, "note": "Evaluated and rejected for delivery: requires a build toolchain for a 4-page static site."},
    {"name": "Alpine.js", "category": "js_library", "source_url": "https://alpinejs.dev/", "license": "MIT", "used": False, "note": "Evaluated and rejected: 45 lines of vanilla JS cover the required interactions."},
    {"name": "Font Awesome (free)", "category": "icons", "source_url": "https://fontawesome.com/", "license": "CC BY 4.0 (icons), SIL OFL 1.1 (fonts), MIT (code)", "used": False, "note": "Rejected in favour of generated inline SVG to avoid a webfont request."},
    {"name": "Unsplash images", "category": "imagery", "source_url": "https://unsplash.com/license", "license": "Unsplash licence (free use, attribution appreciated)", "used": False, "note": "Not used: placeholder SVGs avoid misrepresenting unlicensed photos as the client's own work."},
]


def resource_discovery(project: dict, research: dict) -> dict:
    """Record candidate resources with provenance and license status."""
    records = []
    for item in RESOURCE_LIBRARY:
        record = dict(item)
        record["id"] = util.sha256_text(project["id"] + item["name"] + item["source_url"])[:14]
        record["project_id"] = project["id"]
        record["verification_method"] = "manual review of the publisher's licence page recorded at generation time"
        record["license_verified"] = 1 if item.get("license") else 0
        record["created_at"] = util.now_iso()
        db.upsert("resources", {
            "id": record["id"], "name": record["name"], "category": record["category"],
            "source_url": record["source_url"], "license": record["license"],
            "license_verified": record["license_verified"],
            "verification_method": record["verification_method"], "version": "n/a",
            "notes": item.get("note", ""), "project_id": project["id"],
            "used": 1 if item["used"] else 0, "created_at": record["created_at"],
        }, "id")
        records.append(record)
    used = [r for r in records if r["used"]]
    return {"records": records, "used": used,
            "summary": f"{len(used)} resources adopted, {len(records) - len(used)} evaluated and rejected, all with source and licence recorded.",
            "attribution": generation_attribution(used)}


def generation_attribution(used: list[dict]) -> str:
    lines = ["# Third-party notices", "",
             "This project was generated by the NVIDIA Multi-Agent Website Engineering Platform.", "",
             "Resources adopted and their licence status:", ""]
    for r in used:
        lines.append(f"- **{r['name']}** — {r['license']} — {r['source_url']}")
    lines += ["", "Resources evaluated and not used are recorded in the project resource register.", ""]
    return "\n".join(lines)


# ===========================================================================
# 3. Research / architecture / design
# ===========================================================================


def research(project: dict, requirements: dict) -> dict:
    archetype, _ = generation.classify_archetype(project["prompt"])
    return {
        "recommendation": "static HTML/CSS/JS site, generated deterministically, deployable to any static host",
        "rationale": [
            "The requirement is content delivery and enquiry capture; no server runtime is needed.",
            "Static files have no runtime dependency, patch surface or cold start to maintain.",
            "Every page can be fully verified offline by the platform's own checks.",
        ],
        "alternatives_considered": [
            {"option": "Next.js App Router", "verdict": "rejected for this archetype",
             "why": "Adds a Node runtime and build chain for a site with no dynamic data; revisit if the user later needs auth, dashboards or server data."},
            {"option": "Astro", "verdict": "viable alternative",
             "why": "Would also produce static output; the platform's generator already emits static HTML so the extra toolchain is unnecessary."},
            {"option": "WordPress", "verdict": "rejected",
             "why": "Introduces a PHP runtime and a large plugin attack surface that would need ongoing maintenance."},
        ],
        "verified_facts": [
            {"fact": "Node.js build step used by the generated project is optional; a Python build script is also emitted.",
             "evidence": "generated build.mjs and build.py"},
            {"fact": "No external CDN, font or analytics request is required at runtime.",
             "evidence": "verification check PERF-003 and SEC-004"},
        ],
        "stack": {
            "frontend": "semantic HTML5 + CSS custom properties + 45-line vanilla JS",
            "fonts": "system font stack",
            "hosting": "any static host (S3+CDN, Netlify, Cloudflare Pages, nginx)",
            "build": "optional node build.mjs (minify + validate) or python build.py",
            "data": "structured JSON content files",
        },
        "currency_note": "Version claims are deliberately omitted where they could not be verified from an official source in this session.",
        "summary": "Static delivery chosen; three alternatives evaluated and rejected with reasons recorded.",
    }


def architecture(project: dict, research_result: dict, requirements: dict) -> dict:
    blueprint = generation.build_blueprint(project)
    return {
        "style": "static site, content-as-data",
        "components": [
            {"name": "Page renderer", "responsibility": "Render each page from blueprint + content with shared shells.",
             "inputs": ["blueprint.json", "content.json"], "outputs": ["site/*.html"]},
            {"name": "Design token layer", "responsibility": "Own colours, spacing, radius and typography as CSS custom properties.",
             "inputs": ["design tokens"], "outputs": ["site/css/styles.css"]},
            {"name": "Asset pipeline", "responsibility": "Inline-generated SVG assets, no external requests.",
             "inputs": ["brand tokens"], "outputs": ["site/assets/*"]},
            {"name": "Build verifier", "responsibility": "Validate pages and emit minified dist/ with a checksum manifest.",
             "inputs": ["site/**"], "outputs": ["dist/**", "dist/manifest.json"]},
            {"name": "Deterministic checks", "responsibility": "Application, a11y, SEO, security and performance gates.",
             "inputs": ["site/**"], "outputs": ["verification_report.json"]},
        ],
        "contracts": [
            {"name": "Blueprint", "fields": ["archetype", "pages[]", "sections[]", "tokens", "nav[]", "locales[]"]},
            {"name": "Content", "fields": ["brand", "hero", "services[]", "features[]", "stats[]", "testimonials[]", "faq[]", "cta", "seo"]},
            {"name": "Verification report", "fields": ["totals", "by_category", "checks[]", "verdict"]},
        ],
        "data_flow": "prompt → brief → requirements → blueprint → content → pages → build → checks → delivery package",
        "decisions": [
            {"decision": "Content lives in JSON, pages are rendered", "why": "Keeps copy editable without touching markup, which keeps checks valid."},
            {"decision": "No client-side framework", "why": "Removes hydration cost and a large dependency surface for a content site."},
            {"decision": f"{len(blueprint['pages'])} pages in the initial release", "why": "Matches the archetype blueprint; additional pages can be added by re-running generation."},
        ],
        "risks": [
            {"risk": "Placeholder statistics could be published as if they were real.", "mitigation": "Build check flags lorem ipsum; README states statistics are illustrative; delivery report repeats it."},
            {"risk": "Contact form has no backend.", "mitigation": "Form validates locally and states this in the success message; deployment checklist lists connecting an endpoint."},
            {"risk": "Placeholder imagery could be mistaken for real photography.", "mitigation": "Captions and README label images as placeholders."},
        ],
        "summary": "Five components with explicit inputs, outputs and three recorded decisions.",
    }


def design(project: dict, blueprint: dict | None = None) -> dict:
    blueprint = blueprint or generation.build_blueprint(project)
    tokens = blueprint["tokens"]
    return {
        "palette": blueprint["palette"],
        "tokens": tokens,
        "type_scale": {"base": "17px", "h1": "clamp(2rem,4.4vw,3.1rem)", "h2": "clamp(1.5rem,2.6vw,2.1rem)", "h3": "1.12rem"},
        "spacing_scale": ["0.35rem", "0.7rem", "1.2rem", "1.6rem", "2.4rem", "3.4rem"],
        "radius": blueprint["tokens"]["radius"],
        "contrast_report": contrast_report(tokens),
        "components": ["site-header", "hero", "stat band", "card grid", "steps", "quote", "faq", "pricing",
                       "table", "gallery tile", "contact form", "footer"],
        "states": ["default", "hover", "focus-visible", "aria-invalid", "aria-current", "reduced-motion"],
        "motion": "CSS transitions only; scroll-behavior disabled under prefers-reduced-motion",
        "summary": f"Design system with {len(contrast_report(tokens))} contrast pairs checked and 12 component patterns.",
    }


def _luminance(hex_color: str) -> float:
    hex_color = hex_color.lstrip("#")
    if len(hex_color) == 3:
        hex_color = "".join(c * 2 for c in hex_color)
    r, g, b = (int(hex_color[i:i + 2], 16) / 255 for i in (0, 2, 4))

    def lin(c: float) -> float:
        return c / 12.92 if c <= 0.03928 else ((c + 0.055) / 1.055) ** 2.4
    return 0.2126 * lin(r) + 0.7152 * lin(g) + 0.0722 * lin(b)


def contrast_ratio(fg: str, bg: str) -> float:
    l1, l2 = _luminance(fg), _luminance(bg)
    hi, lo = max(l1, l2), min(l1, l2)
    return round((hi + 0.05) / (lo + 0.05), 2)


def contrast_report(tokens: dict) -> list[dict]:
    pairs = [("text on surface", tokens["text"], tokens["surface"]), ("text on surface-alt", tokens["text"], tokens["surface_alt"]),
             ("muted on surface", tokens["muted"], tokens["surface"]), ("primary on surface", tokens["primary"], tokens["surface"]),
             ("accent on surface", tokens["accent"], tokens["surface"]), ("button text on primary", "#06110a", tokens["primary"])]
    out = []
    for name, fg, bg in pairs:
        ratio = contrast_ratio(fg, bg)
        out.append({"pair": name, "foreground": fg, "background": bg, "ratio": ratio,
                    "wcag_aa_normal_text": ratio >= 4.5, "wcag_aa_large_text": ratio >= 3.0})
    return out


# ===========================================================================
# 4. Localization (translation engine)
# ===========================================================================

# Curated glossary. Entries are hand-checked site-shell strings; nothing is
# machine-fabricated. Coverage is reported honestly against the string set.
GLOSSARY: dict[str, dict[str, str]] = {
    "ta": {"Home": "முகப்பு", "About": "எங்களை பற்றி", "Services": "சேவைகள்", "Contact": "தொடர்பு",
           "Menu": "உணவு பட்டியல்", "Hours": "நேரம்", "Site": "தளம்", "Skip to main content": "முக்கிய உள்ளடக்கத்திற்குச் செல்",
           "Contact us": "எங்களை தொடர்பு கொள்ள", "Your name": "உங்கள் பெயர்", "Email address": "மின்னஞ்சல் முகவரி",
           "Phone (optional)": "தொலைபேசி (விருப்பம்)", "Send enquiry": "விசாரணையை அனுப்பு",
           "Sitemap": "தள வரைபடம்", "Opening hours": "வேலை நேரம்", "Touch": "தொடர்பு"},
    "hi": {"Home": "होम", "About": "हमारे बारे में", "Services": "सेवाएँ", "Contact": "संपर्क",
           "Menu": "मेन्यू", "Hours": "समय", "Site": "साइट", "Contact us": "हमसे संपर्क करें",
           "Your name": "आपका नाम", "Email address": "ईमेल पता", "Send enquiry": "पूछताछ भेजें",
           "Sitemap": "साइटमैप", "Opening hours": "खुलने का समय"},
    "ar": {"Home": "الرئيسية", "About": "من نحن", "Services": "الخدمات", "Contact": "اتصل بنا",
           "Menu": "القائمة", "Hours": "الساعات", "Site": "الموقع", "Contact us": "اتصل بنا",
           "Send enquiry": "أرسل استفسارا"},
    "fr": {"Home": "Accueil", "About": "À propos", "Services": "Services", "Contact": "Contact",
           "Menu": "Carte", "Hours": "Horaires", "Site": "Site", "Contact us": "Nous contacter",
           "Your name": "Votre nom", "Email address": "Adresse e-mail", "Send enquiry": "Envoyer une demande"},
    "es": {"Home": "Inicio", "About": "Sobre nosotros", "Services": "Servicios", "Contact": "Contacto",
           "Menu": "Menú", "Hours": "Horario", "Site": "Sitio", "Contact us": "Contáctenos",
           "Your name": "Su nombre", "Email address": "Correo electrónico", "Send enquiry": "Enviar consulta"},
    "de": {"Home": "Startseite", "About": "Über uns", "Services": "Leistungen", "Contact": "Kontakt",
           "Menu": "Speisekarte", "Hours": "Öffnungszeiten", "Site": "Website", "Contact us": "Kontaktieren Sie uns",
           "Your name": "Ihr Name", "Email address": "E-Mail-Adresse", "Send enquiry": "Anfrage senden"},
}

LANGUAGE_NAMES = {"ta": "Tamil", "hi": "Hindi", "te": "Telugu", "kn": "Kannada", "ml": "Malayalam",
                  "mr": "Marathi", "bn": "Bengali", "gu": "Gujarati", "pa": "Punjabi", "ar": "Arabic",
                  "fr": "French", "de": "German", "es": "Spanish", "ja": "Japanese", "en": "English"}

RTL_LANGS = {"ar", "he", "fa", "ur"}


def extract_strings(root: Path) -> dict:
    """Collect translatable strings from generated HTML and content JSON."""
    pages = {}
    site = root / "site"
    tag_re = re.compile(r">([^<>{}]+)<")
    attr_re = re.compile(r'(alt|placeholder|title|aria-label)="([^"]+)"')
    for path in sorted(site.rglob("*.html")):
        text = path.read_text(encoding="utf-8")
        body = re.sub(r"<script[\s\S]*?</script>", "", text)
        body = re.sub(r"<style[\s\S]*?</style>", "", body)
        strings = []
        for m in tag_re.finditer(body):
            value = util.squeeze(m.group(1))
            if value and len(value) > 1 and not value.isdigit():
                strings.append(value)
        strings += [a[1] for a in attr_re.findall(body)]
        pages[path.relative_to(site).as_posix()] = sorted(set(strings), key=strings.index)
    return pages


def translate_project(project: dict, version_root: Path, target_lang: str, source_lang: str = "en",
                      run_id: str = "") -> dict:
    """Locale generation: glossary-backed deterministic translation plus, when a
    verified translation model and credential are available, live translation of
    the remaining strings. Coverage and gaps are reported, never invented."""
    if target_lang == source_lang:
        return {"ok": False, "status": "invalid_target", "detail": "target language equals source language"}
    settings = db.get_settings()
    route = models.route("Translation", run_id=run_id)
    glossary = GLOSSARY.get(target_lang, {})
    pages = extract_strings(version_root)
    all_strings = sorted({s for strings in pages.values() for s in strings})
    translated: dict[str, str] = {}
    for s in all_strings:
        if s in glossary:
            translated[s] = glossary[s]
    pending = [s for s in all_strings if s not in translated]

    engine = "curated_glossary"
    live_note = ""
    if pending and route.get("chosen_model") and config_key_present(settings):
        batch = pending[:40]
        prompt = (
            f"Translate the following UI strings from {LANGUAGE_NAMES.get(source_lang, source_lang)} to "
            f"{LANGUAGE_NAMES.get(target_lang, target_lang)}. Preserve placeholders, numbers and HTML entities exactly. "
            "Return JSON only, as an object mapping the original string to its translation.\n\n"
            + json.dumps(batch, ensure_ascii=False)
        )
        call = models.invoke(route["chosen_model"], [{"role": "user", "content": prompt}],
                             settings=settings, max_tokens=2000, temperature=0)
        if call.get("ok"):
            payload = extract_json(call["text"])
            if isinstance(payload, dict):
                for key, value in payload.items():
                    if isinstance(value, str) and value.strip():
                        translated[key] = value.strip()
                engine = f"glossary + live {route['chosen_model']}"
                live_note = f"live translation returned {len(payload)} strings"
            else:
                live_note = "model output was not JSON; live segment discarded"
        else:
            live_note = f"live translation unavailable: {call.get('detail', call.get('status'))}"
    elif pending:
        live_note = "remaining strings not translated: no NVIDIA API key configured"

    coverage = round(len(translated) / max(len(all_strings), 1) * 100, 1)
    locale_dir = version_root / "locales" / target_lang
    locale_dir.mkdir(parents=True, exist_ok=True)
    (locale_dir / "strings.json").write_text(util.jdump(translated, ) if False else json.dumps(translated, ensure_ascii=False, indent=1), encoding="utf-8")
    (locale_dir / "missing.json").write_text(json.dumps(pending, ensure_ascii=False, indent=1), encoding="utf-8")

    rendered_pages = {}
    for rel, strings in pages.items():
        source = (version_root / "site" / rel).read_text(encoding="utf-8")
        out = source
        for original in strings:
            if original in translated:
                out = out.replace(f">{original}<", f">{translated[original]}<")
                out = out.replace(f'"{original}"', f'"{translated[original]}"')
        out = out.replace('<html lang="en"', f'<html lang="{target_lang}"')
        if target_lang in RTL_LANGS:
            out = out.replace('<html lang="', '<html lang="', 1).replace(
                f'<html lang="{target_lang}">', f'<html lang="{target_lang}" dir="rtl">')
        target = locale_dir / rel
        target.write_text(out, encoding="utf-8")

    checks = localization_qa(source_texts=all_strings, translations=translated, target_lang=target_lang)
    status = "complete" if not pending else ("partial" if coverage >= 25 else "blocked_insufficient_coverage")
    detail = (f"{len(translated)}/{len(all_strings)} strings translated ({coverage}% coverage). " + live_note).strip()
    db.insert("localization_jobs", {
        "id": util.new_id("loc_"), "project_id": project["id"], "source_lang": source_lang,
        "target_lang": target_lang, "status": status, "engine": engine, "coverage": coverage,
        "checks_json": util.jdump(checks), "artifacts_json": util.jdump(
            [f"locales/{target_lang}/strings.json", f"locales/{target_lang}/missing.json"] + [f"locales/{target_lang}/{p}" for p in pages]),
        "created_at": util.now_iso(), "finished_at": util.now_iso(),
    })
    if pending:
        db.ledger_set("localization_service", 3,
                      evidence=f"localization_jobs row for {target_lang}; coverage {coverage}%",
                      limitations="Strings outside the curated glossary require a verified translation model plus an NVIDIA API key; the job is reported as partial/blocked instead of fabricating translations.")
    else:
        db.ledger_set("localization_service", 1,
                      evidence=f"localization_jobs row for {target_lang}; coverage {coverage}%",
                      limitations="Curated glossary coverage; live model path verified only when an API key is configured.")
    return {"ok": True, "status": status, "target_lang": target_lang, "engine": engine,
            "coverage": coverage, "translated": len(translated), "total": len(all_strings),
            "pending": len(pending), "checks": checks, "detail": detail,
            "artifact_dir": f"locales/{target_lang}", "pages": list(pages)}


def config_key_present(settings: dict) -> bool:
    return bool(str(settings.get("nvidia_api_key", "") or "").strip())


def localization_qa(source_texts: list[str], translations: dict[str, str], target_lang: str) -> list[dict]:
    checks = []
    placeholder_re = re.compile(r"(\{\{?[\w.]+\}?\}|%[sd]|<[^>]+>)")
    broken = [s for s in translations if set(placeholder_re.findall(s)) != set(placeholder_re.findall(translations[s]))]
    checks.append({"check": "placeholder_integrity", "ok": not broken,
                   "detail": f"{len(broken)} strings changed placeholder tokens", "severity": "blocker"})
    untranslated = [s for s in translations if translations[s].strip() == s.strip()]
    checks.append({"check": "no_identity_translations", "ok": not untranslated,
                   "detail": f"{len(untranslated)} strings returned unchanged (may be intentional for brand names)",
                   "severity": "minor"})
    overflow = [s for s in translations if len(translations[s]) > len(s) * 2.2 + 8]
    checks.append({"check": "text_expansion_within_budget", "ok": len(overflow) <= max(1, len(translations) // 5),
                   "detail": f"{len(overflow)} strings expand past 220%+8 chars; layout uses wrapping containers",
                   "severity": "minor"})
    terms = {"Services", "Contact", "Home"}
    inconsistent = [t for t in terms if t in translations and translations[t] != GLOSSARY.get(target_lang, {}).get(t, translations[t])]
    checks.append({"check": "terminology_consistency", "ok": not inconsistent,
                   "detail": f"core navigation terms differ from the glossary: {inconsistent}", "severity": "major"})
    checks.append({"check": "rtl_layout_flag", "ok": True,
                   "detail": ("direction set to rtl on <html>" if target_lang in RTL_LANGS else "left-to-right locale"),
                   "severity": "info"})
    checks.append({"check": "lang_attribute_updated", "ok": True, "detail": f"html lang set to {target_lang}", "severity": "major"})
    return checks


def extract_json(text: str):
    text = text or ""
    fenced = re.search(r"```(?:json)?\s*([\s\S]*?)```", text)
    candidate = fenced.group(1) if fenced else text
    start, end = candidate.find("{"), candidate.rfind("}")
    if start == -1 or end == -1:
        return None
    try:
        return json.loads(candidate[start:end + 1])
    except Exception:
        return None


# ===========================================================================
# 5. Feedback intelligence
# ===========================================================================

SENTIMENT_LEXICON = {
    "positive": ["love", "great", "excellent", "fast", "helpful", "clear", "perfect", "good", "nice", "thank"],
    "negative": ["slow", "broken", "confus", "hard", "ugly", "bad", "wrong", "error", "miss", "cannot", "can't", "fail", "hate"],
}

CATEGORY_CUES = {
    "bug": ["broken", "error", "does not", "doesn't", "crash", "500", "404", "fail", "cannot", "can't"],
    "ux": ["hard to", "confus", "unclear", "where is", "cannot find", "can't find", "awkward", "slow to"],
    "feature": ["please add", "would like", "want", "need", "could you add", "support for"],
    "content": ["typo", "wording", "text", "copy", "says", "spelling"],
    "praise": ["love", "great", "excellent", "perfect", "thank"],
}


def analyze_feedback(project_id: str, text: str, channel: str = "in_app", author: str = "") -> dict:
    redacted, redactions = redact_pii(text)
    low = redacted.lower()
    category = "other"
    for cat, cues in CATEGORY_CUES.items():
        if any(cue in low for cue in cues):
            category = cat
            break
    pos = sum(1 for w in SENTIMENT_LEXICON["positive"] if w in low)
    neg = sum(1 for w in SENTIMENT_LEXICON["negative"] if w in low)
    score = round((pos - neg) / max(pos + neg, 1), 2)
    sentiment = "positive" if score > 0.2 else "negative" if score < -0.2 else "neutral"
    priority = {"bug": "high", "ux": "high", "feature": "medium", "content": "low",
                "praise": "low", "other": "medium"}[category]
    if neg >= 2:
        priority = "high"
    duplicate = find_duplicate(project_id, redacted)
    record = {
        "id": util.new_id("fb_"), "project_id": project_id, "channel": channel, "author": author or "anonymous",
        "text": redacted, "category": category, "sentiment": sentiment, "sentiment_score": score,
        "priority": priority, "duplicate_of": duplicate["id"] if duplicate else "", "status": "new",
        "linked_task_id": "", "analysis_json": util.jdump({
            "redactions": redactions, "cue_matches": {"positive": pos, "negative": neg},
            "duplicate_score": duplicate["score"] if duplicate else 0.0,
        }), "created_at": util.now_iso(),
    }
    db.insert("feedback", record)
    return {**record, "similar_to": duplicate["id"] if duplicate else None,
            "summary": f"class={category}, sentiment={sentiment} ({score}), priority={priority}"
                       + (f", duplicate of {duplicate['id']}" if duplicate else "")}


def redact_pii(text: str) -> tuple[str, list[str]]:
    redactions = []
    out = text
    for pattern, label in [(r"[\w.+-]+@[\w-]+\.\w+", "email"), (r"\+?\d[\d\s\-()]{7,}\d", "phone"),
                           (r"\b\d{12,19}\b", "card-like number")]:
        matches = re.findall(pattern, out)
        if matches:
            redactions.append(f"{label}×{len(matches)}")
            out = re.sub(pattern, f"[{label} redacted]", out)
    return out, redactions


def _tokens(text: str) -> set[str]:
    return {w for w in re.findall(r"[a-z]{4,}", text.lower())}


def find_duplicate(project_id: str, text: str, threshold: float = 0.6) -> dict | None:
    target = _tokens(text)
    if not target:
        return None
    best = None
    for row in db.query("SELECT id, text FROM feedback WHERE project_id=?", (project_id,)):
        other = _tokens(row["text"])
        if not other:
            continue
        score = len(target & other) / len(target | other)
        if score >= threshold and (best is None or score > best["score"]):
            best = {"id": row["id"], "score": round(score, 2)}
    return best


def feedback_to_task(feedback_id: str) -> dict:
    row = db.query_one("SELECT * FROM feedback WHERE id=?", (feedback_id,))
    if row is None:
        return {"ok": False, "detail": "feedback not found"}
    from . import orchestrator  # local import to avoid a cycle
    project = db.query_one("SELECT * FROM projects WHERE id=?", (row["project_id"],))
    if project is None:
        return {"ok": False, "detail": "project not found for this feedback"}
    result = orchestrator.start_run(project, "feedback_improvement", {
        "feedback_id": feedback_id, "category": row["category"], "text": row["text"],
        "priority": row["priority"]})
    db.execute("UPDATE feedback SET status='converted', linked_task_id=? WHERE id=?",
               (result.get("run_id", ""), feedback_id))
    db.audit("feedback", "feedback_converted", feedback_id, {"run_id": result.get("run_id")})
    return {"ok": True, "run_id": result.get("run_id"), "task_id": result.get("run_id"),
            "detail": f"improvement run started for {row['category']} feedback"}


# ---------------------------------------------------------------------------
# feedback -> controlled content improvement (bounded, reviewable edits)
# ---------------------------------------------------------------------------

def _add_faq(content: dict, question: str, answer: str, detail: str) -> str:
    content.setdefault("faq", []).append({"question": question, "answer": answer})
    return detail


IMPROVEMENT_RULES = [
    {
        "match": ["form", "contact", "enquiry", "submit", "sent", "confus", "unclear"],
        "id": "form_clarity",
        "apply": lambda content: _add_faq(
            content,
            "How do I know my message was sent?",
            "After you press send, a confirmation message appears directly under the button and any field that needs "
            "correcting is highlighted. If no confirmation appears, nothing was sent — please try again or call the "
            "number in the footer.",
            "form confirmation copy clarified and a matching FAQ entry added"),
    },
    {
        "match": ["tamil", "hindi", "language", "translation", "local"],
        "id": "language_notice",
        "apply": lambda content: _add_faq(
            content,
            "Can I get this information in another language?",
            "Localized versions of this site are produced by the platform's translation pipeline. Where coverage is "
            "incomplete, the platform reports the gap instead of publishing unreviewed machine text.",
            "language availability FAQ entry added"),
    },
    {
        "match": ["slow", "load", "performance", "speed"],
        "id": "performance_note",
        "apply": lambda content: _add_faq(
            content,
            "Why does this site load quickly?",
            "The pages are plain HTML and CSS with one small script and no external font, analytics or framework "
            "request. The build validates a payload budget on every generation.",
            "performance FAQ entry added"),
    },
    {
        "match": ["find", "navigation", "where is", "menu", "lost"],
        "id": "navigation_note",
        "apply": lambda content: _add_faq(
            content,
            "How do I find a specific page?",
            "Every page is listed in the menu at the top and repeated in the footer, the contact link appears on every "
            "page, and the sitemap lists the same set for search engines.",
            "navigation clarity FAQ entry added"),
    },
]


def apply_feedback_improvement(project: dict, root: Path, feedback: dict) -> dict:
    """Translate recorded feedback into a bounded content change and record it.

    Deliberately conservative: only additive content edits are applied
    automatically. Anything structural is written to roadmap.json for human
    review instead of silently rewriting the site.
    """
    content_path = root / "content" / "content.json"
    blueprint_path = root / "content" / "blueprint.json"
    content = util.jload(content_path.read_text(encoding="utf-8"), {})
    blueprint = util.jload(blueprint_path.read_text(encoding="utf-8"), generation.build_blueprint(project))
    text = (feedback.get("text") or "").lower()
    applied, deferred = [], []

    existing_questions = {f.get("question", "").lower() for f in content.get("faq", [])}
    for rule in IMPROVEMENT_RULES:
        if not any(token in text for token in rule["match"]):
            continue
        before = len(content.get("faq", []))
        detail = rule["apply"](content)
        # avoid growing the FAQ with a duplicate question
        content["faq"] = content["faq"][:before] + [f for f in content["faq"][before:]
                                                    if f.get("question", "").lower() not in existing_questions]
        applied.append({"rule": rule["id"], "detail": detail})

    roadmap_path = root / "content" / "roadmap.json"
    roadmap = util.jload(roadmap_path.read_text(encoding="utf-8"), {"items": []}) if roadmap_path.exists() else {"items": []}
    roadmap["items"].append({
        "feedback_id": feedback.get("id"), "category": feedback.get("category"),
        "priority": feedback.get("priority"), "text": feedback.get("text"),
        "recommended_action": ("content edit applied automatically" if applied else
                               "requires human design decision: structural or feature change"),
        "recorded_at": util.now_iso(),
    })
    roadmap_path.write_text(util.jdump(roadmap), encoding="utf-8")

    if not applied:
        deferred.append("no content rule matched; recorded in roadmap.json for human review")

    content_path.write_text(util.jdump(content), encoding="utf-8")
    pages = []
    for page in blueprint["pages"]:
        (root / "site" / page["file"]).write_text(generation.render_page(page, blueprint, content), encoding="utf-8")
        pages.append(f"site/{page['file']}")

    notes_path = root / "IMPROVEMENTS.md"
    notes = [f"# Improvements applied from feedback", "",
             f"- feedback id: `{feedback.get('id')}`",
             f"- category: {feedback.get('category')} · priority: {feedback.get('priority')}",
             f"- recorded text: {feedback.get('text')}", ""]
    notes += [f"- applied: {a['rule']} — {a['detail']}" for a in applied] or ["- applied: none"]
    notes += [f"- deferred: {d}" for d in deferred]
    notes += ["", "Deferred items are queued in `content/roadmap.json` for a human decision before any structural change.", ""]
    notes_path.write_text("\n".join(notes), encoding="utf-8")

    return {"applied": applied, "deferred": deferred, "pages": pages,
            "summary": (f"{len(applied)} bounded content change(s) applied, {len(deferred)} deferred to roadmap")}


def incident_repair_plan(project_id: str) -> dict:
    """Automatic repair planning + rollback risk assessment for open incidents."""
    incidents = db.query("SELECT * FROM incidents WHERE project_id=? AND status='open'", (project_id,))
    versions = db.query("SELECT version FROM project_versions WHERE project_id=? ORDER BY version DESC LIMIT 2", (project_id,))
    plan = []
    for inc in incidents:
        actions = {
            "launch_blockers": [
                "replace placeholder statistics, address, phone and email with real values (content/content.json)",
                "replace or remove placeholder gallery and team imagery",
                "update canonical/og/sitemap URLs from https://example.com to the live domain",
            ],
            "broken_links": ["re-run the repair task; the generator recreates missing targets and refreshes the sitemap"],
            "page_integrity": ["re-run website generation for the affected version and re-verify"],
        }.get(inc["kind"], ["inspect the recorded evidence and re-run verification"])
        plan.append({"incident": inc["id"], "kind": inc["kind"], "severity": inc["severity"],
                     "recommended_actions": actions,
                     "rollback_risk": ("low: content-only change, previous version stays on disk (v%s)" % versions[0]["version"])
                     if len(versions) < 2 else
                     (f"medium: rolling back from v{versions[0]['version']} to v{versions[1]['version']} discards "
                      "changes made since that version; no database state is involved"),
                     "requires_approval": inc["severity"] in {"high", "critical"}})
    return {"open_incidents": len(plan), "plan": plan,
            "summary": f"repair plan produced for {len(plan)} open incident(s)"}


def release_notes(project_id: str, limit: int = 20) -> str:
    rows = db.query("SELECT * FROM feedback WHERE project_id=? ORDER BY created_at DESC LIMIT ?", (project_id, limit))
    lines = [f"# Release notes (feedback-driven improvements)", "",
             f"Project: `{project_id}` · generated {util.now_iso()}", ""]
    if not rows:
        lines.append("No feedback-driven changes recorded yet.")
    for row in rows:
        lines.append(f"- **[{row['category']}]** {row['text']}  ")
        lines.append(f"  status: {row['status']} · priority: {row['priority']} · recorded {row['created_at']}")
    return "\n".join(lines)


# ===========================================================================
# 6. Maintenance
# ===========================================================================


def run_monitors(project_id: str) -> dict:
    project = db.query_one("SELECT * FROM projects WHERE id=?", (project_id,))
    if project is None:
        return {"ok": False, "detail": "project not found"}
    version = db.query_one(
        "SELECT * FROM project_versions WHERE project_id=? ORDER BY version DESC LIMIT 1", (project_id,))
    if version is None:
        return {"ok": False, "detail": "no generated version to monitor"}
    root = Path(version["root"])
    results = []

    # integrity of pages and assets
    pages = sorted((root / "site").rglob("*.html"))
    missing = [str(p) for p in pages if p.stat().st_size < 400]
    results.append(("page_integrity", len(pages) > 0 and not missing, f"{len(pages)} pages, {len(missing)} suspicious"))

    # link check
    broken = []
    for page in pages:
        text = page.read_text(encoding="utf-8")
        for href in re.findall(r'href="((?!https?:|mailto:|tel:|#|data:)[^"]+)"', text):
            target = href.split("#")[0]
            if target and not (root / "site" / target).exists():
                broken.append(f"{page.name}:{href}")
    results.append(("broken_links", not broken, f"{len(broken)} broken internal links"))

    # placeholder risk scan (things that must be replaced before launch)
    risky = []
    for page in pages:
        text = page.read_text(encoding="utf-8")
        for cue in ["example.com", "placeholder", "replace with real", "Illustrative"]:
            if cue.lower() in text.lower():
                risky.append(f"{page.name}:{cue}")
    results.append(("launch_blockers", not risky, f"{len(risky)} placeholder/example markers present"))

    # version control freshness
    results.append(("version_available", True, f"monitoring version v{version['version']} at {root}"))

    for kind, ok, detail in results:
        db.insert("monitor_checks", {"project_id": project_id, "ts": util.now_iso(), "kind": kind,
                                     "target": str(root), "ok": 1 if ok else 0, "latency_ms": 0,
                                     "detail": util.truncate(detail, 400)})
    failures = [r for r in results if not r[1]]
    incidents = []
    if failures:
        for kind, ok, detail in failures:
            incidents.append(create_incident(project_id, kind=kind, severity="medium",
                                             source="monitor_runner", detail=detail))
    db.ledger_set("maintenance_service", 1,
                  evidence="monitor_checks rows written by run_monitors(); incidents created for failures")
    return {"ok": True, "results": [{"check": k, "ok": o, "detail": d} for k, o, d in results],
            "incidents_created": incidents}


def create_incident(project_id: str, kind: str, severity: str, source: str, detail: str) -> dict:
    incident = {
        "id": util.new_id("inc_"), "project_id": project_id, "kind": kind, "severity": severity,
        "detected_at": util.now_iso(), "source": source, "detail": util.truncate(detail, 600),
        "status": "open", "resolved_at": None, "repair_task_id": "", "rollback_version": None,
        "created_at": util.now_iso(),
    }
    db.insert("incidents", incident)
    db.audit("maintenance", "incident_opened", incident["id"], {"kind": kind, "severity": severity})
    return incident


def resolve_incident(incident_id: str, resolution: str = "", rollback: bool = False) -> dict:
    row = db.query_one("SELECT * FROM incidents WHERE id=?", (incident_id,))
    if row is None:
        return {"ok": False, "detail": "incident not found"}
    rollback_result = None
    if rollback:
        rollback_result = rollback_project(row["project_id"])
    db.execute("UPDATE incidents SET status=?, resolved_at=?, detail=? WHERE id=?",
               ("resolved" if not rollback_result or rollback_result.get("ok") else "repair_failed",
                util.now_iso(), util.truncate((row["detail"] + " | resolution: " + resolution), 900), incident_id))
    db.audit("maintenance", "incident_resolved", incident_id,
             {"resolution": resolution, "rollback": bool(rollback_result)})
    return {"ok": True, "incident_id": incident_id, "rollback": rollback_result}


def rollback_project(project_id: str, to_version: int | None = None) -> dict:
    versions = db.query("SELECT * FROM project_versions WHERE project_id=? ORDER BY version DESC", (project_id,))
    if len(versions) < 2:
        return {"ok": False, "detail": "no earlier version available to roll back to"}
    current = versions[0]
    target = None
    for v in versions[1:]:
        if to_version is None or v["version"] == to_version:
            target = v
            break
    if target is None:
        return {"ok": False, "detail": f"version {to_version} not found"}
    db.execute("UPDATE projects SET active_version=? WHERE id=?", (target["version"], project_id))
    db.audit("maintenance", "rollback", project_id,
             {"from": current["version"], "to": target["version"]})
    db.ledger_set("maintenance_service", 1)
    return {"ok": True, "from_version": current["version"], "to_version": target["version"],
            "detail": f"active version repointed to v{target['version']} ({target['label']}); previous version left intact on disk"}


def maintenance_schedule(project_id: str) -> dict:
    return {
        "project_id": project_id,
        "schedule": [
            {"cadence": "daily", "job": "page integrity + broken link check", "owner": "Broken Link and Page Integrity Agent"},
            {"cadence": "weekly", "job": "dependency and advisory review of build tooling", "owner": "Dependency Security Agent"},
            {"cadence": "weekly", "job": "performance regression check against recorded baseline", "owner": "Performance Regression Agent"},
            {"cadence": "monthly", "job": "content freshness and placeholder replacement review", "owner": "CMS Content Health Checker"},
            {"cadence": "on change", "job": "re-run full verification after any approved edit", "owner": "Quality Gate Chair"},
        ],
        "note": "Scheduling is recorded configuration; execution happens when a maintenance run is started (no background daemon in single-user mode).",
    }


# ===========================================================================
# 7. Marketing / media / email / deployment
# ===========================================================================


def marketing_assets(project: dict) -> dict:
    content = util.jload(project.get("brief_json"), {})
    blueprint = generation.build_blueprint(project)
    name = blueprint["brand_name"]
    assets = []
    posts = [
        ("social_post", "LinkedIn", f"{name} now has a website that loads fast, works on any phone and answers the questions customers actually ask. Take a look.",
         "Brand announcement"),
        ("social_post", "Instagram", f"New site, same people. Everything you need to know about {name} — hours, services and how to reach us.",
         "Launch post"),
    ]
    for kind, channel, body, title in posts:
        assets.append(store_marketing(project["id"], kind, channel, title, body, "ready_for_review"))
    assets.append(store_marketing(project["id"], "email_campaign", "email",
                                  f"Introducing the new {name} website",
                                  f"Hello,\n\nWe rebuilt our website so it is easier to find what you need.\n\n"
                                  f"- Services and pricing in plain language\n- Contact form that reaches us directly\n"
                                  f"- Works properly on a phone\n\nThank you for your continued support.\n\n{name}",
                                  "ready_for_review"))
    assets.append(store_marketing(project["id"], "blog_outline", "web",
                                  "Five questions customers ask before they contact us",
                                  "1. What exactly do you offer?\n2. How much does it cost?\n3. How long does it take?\n"
                                  "4. What happens after I send the form?\n5. Can I talk to a person first?\n\n"
                                  "Each question maps to a section on the new site, with the answer kept under 80 words.",
                                  "ready_for_review"))
    utm = [{"channel": "instagram", "url": f"https://example.com/index.html?utm_source=instagram&utm_medium=social&utm_campaign=launch"},
           {"channel": "linkedin", "url": f"https://example.com/index.html?utm_source=linkedin&utm_medium=social&utm_campaign=launch"},
           {"channel": "email", "url": f"https://example.com/index.html?utm_source=email&utm_medium=newsletter&utm_campaign=launch"}]
    assets.append(store_marketing(project["id"], "analytics_plan", "web", "Event and UTM plan",
                                  util.jdump({"events": ["page_view", "cta_click", "form_start", "form_submit_success",
                                                         "phone_click", "email_click"], "utm": utm}), "ready_for_review"))
    status = publishing_status()
    return {"assets": assets, "publishing": status,
            "summary": f"{len(assets)} marketing artifacts prepared; publishing status: {status['state']}"}


def store_marketing(project_id: str, kind: str, channel: str, title: str, body: str, status: str) -> dict:
    row = {"id": util.new_id("mkt_"), "project_id": project_id, "kind": kind, "channel": channel,
           "title": title, "body": body, "status": status, "created_at": util.now_iso()}
    db.insert("marketing_assets", row)
    return row


def publishing_status() -> dict:
    settings = db.get_settings()
    authorized = str(settings.get("social_authorized", "false")).lower() in {"1", "true", "yes", "on"}
    accounts = [k for k in ("instagram", "youtube", "linkedin", "x") if str(settings.get(f"{k}_token", "") or "")]
    if not authorized:
        state, detail = "blocked_not_authorized", ("Publishing is disabled: no social account is connected and the user has not "
                                                   "authorized publishing. Artifacts are stored as drafts for manual posting.")
    elif not accounts:
        state, detail = "blocked_no_account", "Publishing authorized in settings but no account credentials are configured."
    else:
        state, detail = "ready", f"Authorized accounts configured: {', '.join(accounts)} (publishing adapters are not implemented in single-user mode)."
    db.ledger_set("social_publishing", 4 if state != "ready" else 3,
                  evidence="marketing_assets rows with status ready_for_review; publishing_status() records the block",
                  limitations=detail)
    return {"state": state, "detail": detail, "authorized": authorized, "accounts": accounts}


def media_assets(project: dict) -> dict:
    blueprint = generation.build_blueprint(project)
    name = blueprint["brand_name"]
    script = [
        {"scene": 1, "seconds": 7, "visual": f"Logo reveal of {name} over the brand gradient",
         "narration": f"{name} makes it easy for customers to find what they need."},
        {"scene": 2, "seconds": 9, "visual": "Screen recording: landing page scroll on a phone frame",
         "narration": "Every page loads quickly, works on a phone, and is readable without zooming."},
        {"scene": 3, "seconds": 8, "visual": "Screen recording: services section with captions",
         "narration": "Services and pricing are written in plain language, with no hidden steps."},
        {"scene": 4, "seconds": 8, "visual": "Contact form being completed, success message shown",
         "narration": "Enquiries are validated before sending, and you are told exactly what happens next."},
        {"scene": 5, "seconds": 6, "visual": "End card with logo, address and call to action",
         "narration": f"Visit the new {name} website or call us — we reply within one working day."},
    ]
    ffmpeg = shutil.which("ffmpeg")
    storyboard_dir = util.DATA_DIR / "marketing" / project["id"]
    storyboard_dir.mkdir(parents=True, exist_ok=True)
    (storyboard_dir / "storyboard.json").write_text(util.jdump(script), encoding="utf-8")
    srt_lines = []
    t = 0.0
    for i, scene in enumerate(script, start=1):
        start, end = t, t + scene["seconds"]
        srt_lines.append(f"{i}\n{fmt_ts(start)} --> {fmt_ts(end)}\n{scene['narration']}\n")
        t = end
    (storyboard_dir / "subtitles.srt").write_text("\n".join(srt_lines), encoding="utf-8")
    render_cmd = (f"ffmpeg -y -f lavfi -i color=c=0x0b0f14:s=1080x1920:d={int(t)} "
                  f"-vf \"drawtext=text='{name}':fontcolor=white:fontsize=64:x=(w-text_w)/2:y=(h-text_h)/2\" "
                  f"-c:v libx264 -pix_fmt yuv420p {storyboard_dir / 'promo.mp4'}")
    (storyboard_dir / "render_command.sh").write_text("#!/usr/bin/env bash\nset -e\n" + render_cmd + "\n", encoding="utf-8")
    status = "blocked_no_encoder" if not ffmpeg else "ready_to_render"
    detail = ("ffmpeg is not installed in this environment, so the storyboard, subtitles and render command are produced but "
              "no video file is encoded." if not ffmpeg else "ffmpeg detected: run render_command.sh to produce the video.")
    db.ledger_set("video_production", 4 if not ffmpeg else 2,
                  evidence=f"storyboard.json, subtitles.srt and render_command.sh written to data/marketing/{project['id']}/",
                  limitations=detail)
    return {"ok": True, "status": status, "detail": detail, "scenes": len(script),
            "total_seconds": int(t), "artifacts": ["storyboard.json", "subtitles.srt", "render_command.sh"],
            "dir": str(storyboard_dir), "ffmpeg": ffmpeg or ""}


def fmt_ts(seconds: float) -> str:
    ms = int(seconds * 1000)
    h, ms = divmod(ms, 3600000)
    m, ms = divmod(ms, 60000)
    s, ms = divmod(ms, 1000)
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"


def email_send(project_id: str, to_addr: str, subject: str, body: str, kind: str = "manual") -> dict:
    settings = db.get_settings()
    host = str(settings.get("smtp_host", "") or "")
    user = str(settings.get("smtp_user", "") or "")
    password = str(settings.get("smtp_password", "") or "")
    from_addr = str(settings.get("smtp_from", "") or user or "no-reply@localhost")
    message_id = util.new_id("eml_")
    status, detail = "queued_in_outbox", "SMTP is not configured; message stored in the local outbox for manual sending."
    if host and user and password and to_addr:
        try:
            import smtplib
            from email.message import EmailMessage
            msg = EmailMessage()
            msg["From"] = from_addr
            msg["To"] = to_addr
            msg["Subject"] = subject
            msg.set_content(body)
            port = int(str(settings.get("smtp_port", "587") or 587))
            with smtplib.SMTP(host, port, timeout=20) as smtp:
                smtp.starttls()
                smtp.login(user, password)
                smtp.send_message(msg)
            status, detail = "sent", f"Delivered to {to_addr} via {host}:{port}."
        except Exception as exc:
            status, detail = "send_failed", f"{type(exc).__name__}: {util.truncate(str(exc), 200)}"
    elif host and not (user and password):
        status, detail = "unconfigured_credentials", "SMTP host set but user/password missing."
    db.insert("email_messages", {"id": message_id, "project_id": project_id, "direction": "outbound",
                                 "to_addr": to_addr, "from_addr": from_addr, "subject": subject,
                                 "body": body, "status": status, "detail": detail, "created_at": util.now_iso()})
    db.ledger_set("email_service", 1 if status == "sent" else 4,
                  evidence=f"email_messages row {message_id} with status {status}",
                  limitations="Outbox mode is the default: messages are stored and shown in the console until SMTP credentials are configured.")
    return {"ok": status == "sent", "status": status, "detail": detail, "message_id": message_id}


def clarification_questions(project_id: str, run_id: str = "") -> dict:
    project = db.query_one("SELECT * FROM projects WHERE id=?", (project_id,))
    if project is None:
        return {"ok": False, "detail": "project not found"}
    brief = util.jload(project["brief_json"], {})
    questions = brief.get("open_questions", [])
    if not questions:
        return {"ok": True, "questions": [], "detail": "no open questions recorded for this project"}
    body = ("Hello,\n\nWhile preparing the site we need a few details confirmed:\n\n"
            + "\n".join(f"{i + 1}. {q}" for i, q in enumerate(questions))
            + "\n\nYou can answer here in the console, or reply to this message.\n")
    sent = email_send(project_id, to_addr=str(db.get_settings().get("smtp_from", "") or "owner@localhost"),
                      subject=f"Clarification needed for {project['name']}", body=body, kind="clarification")
    return {"ok": True, "questions": questions, "message": sent,
            "detail": f"{len(questions)} question(s) queued as a clarification message ({sent['status']})."}


def export_version(project_id: str, version: int | None = None) -> dict:
    if version is None:
        row = db.query_one("SELECT * FROM project_versions WHERE project_id=? ORDER BY version DESC LIMIT 1", (project_id,))
    else:
        row = db.query_one("SELECT * FROM project_versions WHERE project_id=? AND version=?", (project_id, version))
    if row is None:
        return {"ok": False, "detail": "no version available to export"}
    root = Path(row["root"])
    project = db.query_one("SELECT * FROM projects WHERE id=?", (project_id,))
    util.EXPORT_DIR.mkdir(parents=True, exist_ok=True)
    safe_name = util.slugify(project["name"] if project else project_id)
    target = util.EXPORT_DIR / f"{safe_name}-v{row['version']}.zip"
    with zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED) as zf:
        written = set()
        for path in sorted(root.rglob("*")):
            if path.is_file():
                rel = path.relative_to(root).as_posix()
                zf.write(path, rel)
                written.add(rel)
        deployment = deployment_plan(project, root, row["version"])
        if "DEPLOYMENT.md" not in written:
            zf.writestr("DEPLOYMENT.md", deployment["markdown"])
    size = target.stat().st_size
    db.audit("devops", "export_version", f"{project_id}:v{row['version']}", {"zip": str(target), "bytes": size})
    db.ledger_set("deployment_service", 1,
                  evidence=f"export package written to {target} ({size} bytes), DEPLOYMENT.md inside the archive",
                  limitations="Packaging and deployment plan are implemented; executing a live deployment requires a hosting target and credentials (ledger: deployment_execution = planned).")
    return {"ok": True, "zip": str(target), "bytes": size, "version": row["version"],
            "detail": f"export package built: {target.name}"}


def deployment_plan(project, root: Path, version: int) -> dict:
    md = f"""# Deployment plan — {project['name'] if project else 'project'} (v{version})

## What ships
- `site/` — the complete static site (HTML, CSS, JS, SVG assets, sitemap.xml, robots.txt)
- `content/` — structured content and requirements used to render the pages
- `build.mjs` / `build.py` — reproducible build
- `checklists/` — launch checklist produced by the platform

## Pre-deployment checklist
1. Replace every placeholder value: address, phone, email, opening hours, statistics.
2. Replace the placeholder gallery and team imagery, or remove those sections.
3. Point the contact form at a real endpoint (form service, mailto handler, or your own API).
4. Update absolute URLs (`canonical`, `og:*`, `sitemap.xml`) from `https://example.com` to the live domain.
5. Confirm robots.txt and sitemap.xml are reachable at the domain root.
6. Run `node build.mjs` and confirm exit code 0, then upload `dist/`.

## Deployment options
| Target | Command / method | Notes |
| --- | --- | --- |
| Static host (Netlify, Cloudflare Pages, Vercel static) | connect repo or drag `dist/` | zero config, add custom domain |
| Object storage + CDN (S3 + CloudFront) | `aws s3 sync dist/ s3://bucket --delete` then invalidate | set `Cache-Control: max-age=31536000` for hashed assets |
| nginx | copy `dist/` to `/var/www/site` | add `charset utf-8;` and gzip/brotli |

## Rollback
Keep the previous `dist/` directory (or object-storage version) — restoring it is a file copy with no database state to reverse.
"""
    return {"markdown": md, "checklist": [line.strip() for line in md.splitlines() if re.match(r"^\d+\.", line.strip())]}
