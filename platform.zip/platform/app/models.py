"""NVIDIA model discovery, registry, capability classification and routing.

Discovery sources (no credentials required for catalogue discovery):
  - https://integrate.api.nvidia.com/v1/models   (OpenAI-compatible catalogue)
  - https://build.nvidia.com/models              (human-facing catalogue)
Verification of inference requires NVIDIA_API_KEY (single-user, stored locally).

Nothing here fabricates capability: unknown models are recorded as
'catalog_present_unclassified' and are never auto-routed until classified.
"""
from __future__ import annotations

import json
import time
import urllib.error
import urllib.request
from typing import Any

from . import config, db, util

BUILD_URL = "https://build.nvidia.com/models"

# ---------------------------------------------------------------------------
# Capability taxonomy (spec 9.3)
# ---------------------------------------------------------------------------
CAPABILITIES = [
    "Complex planning", "Requirements engineering", "Technical research",
    "Code generation", "Code review", "Architecture analysis", "UI/UX reasoning",
    "Image understanding", "Translation", "Semantic search", "Summarization",
    "Classification", "Testing assistance", "Debugging", "Security analysis",
    "Documentation", "Marketing text", "Media processing assistance",
    "Image generation", "Safety filtering", "Structured extraction",
]

# ---------------------------------------------------------------------------
# Curated capability knowledge for catalogue entries (verified against the
# live catalogue by identifier; capabilities come from the model's published
# card, not from name similarity alone).
# ---------------------------------------------------------------------------
MODEL_KNOWLEDGE: dict[str, dict] = {
    "z-ai/glm-5.3": dict(caps=["Complex planning", "Requirements engineering", "Architecture analysis", "Code generation", "Testing assistance", "Debugging", "Summarization"], vision=False, tools=True, json_mode=True, note="Frontier reasoning/coding family; primary planner."),
    "z-ai/glm-5.3-flash": dict(caps=["Complex planning", "Summarization", "Classification", "Marketing text", "Technical research"], vision=False, tools=True, json_mode=True, note="Lower-latency variant for routine agent work."),
    "nvidia/nemotron-3.5-lightning-30b-a3b": dict(caps=["Code generation", "Classification", "Summarization", "Documentation", "Testing assistance"], vision=False, tools=True, json_mode=True, note="Efficient MoE specialist executor."),
    "nvidia/nemotron-3-ultra-550b-a55b": dict(caps=["Complex planning", "Architecture analysis", "Technical research", "Code review", "Security analysis"], vision=False, tools=True, json_mode=True, note="Largest Nemotron 3 tier for deep analysis."),
    "nvidia/nemotron-3-super-120b-a12b": dict(caps=["Complex planning", "Code generation", "Code review", "Debugging"], vision=False, tools=True, json_mode=True),
    "nvidia/nemotron-3-nano-omni-30b-a3b-reasoning": dict(caps=["Complex planning", "Image understanding", "Summarization", "Classification"], vision=True, tools=True, json_mode=True, note="Omni-modal reasoning tier."),
    "nvidia/nemotron-nano-3-30b-a3b": dict(caps=["Classification", "Summarization", "Documentation"], vision=False, tools=False, json_mode=True),
    "nvidia/llama-3.1-nemotron-ultra-253b-v1": dict(caps=["Complex planning", "Technical research", "Code review"], vision=False, tools=True, json_mode=True),
    "nvidia/llama-3.1-nemotron-70b-instruct": dict(caps=["Complex planning", "Summarization", "Marketing text"], vision=False, tools=True, json_mode=False),
    "nvidia/llama-3.1-nemotron-51b-instruct": dict(caps=["Summarization", "Classification", "Documentation"], vision=False, tools=True, json_mode=False),
    "nvidia/llama3-chatqa-1.5-70b": dict(caps=["Documentation", "Summarization"], vision=False, tools=False, json_mode=False),
    "nvidia/nemotron-4-340b-instruct": dict(caps=["Complex planning", "Summarization", "Marketing text"], vision=False, tools=False, json_mode=False),
    "nvidia/nemotron-4-340b-reward": dict(caps=["Classification"], vision=False, tools=False, json_mode=False, note="Reward/scoring model, not a chat model."),
    "nvidia/ising-calibration-1.5-31b": dict(caps=["Classification", "Summarization"], vision=False, tools=False, json_mode=False),
    "nvidia/mistral-nemo-minitron-8b-8k-instruct": dict(caps=["Classification", "Summarization"], vision=False, tools=False, json_mode=False),
    "moonshotai/kimi-k3": dict(caps=["Code generation", "Code review", "Complex planning", "Image understanding", "Debugging"], vision=True, tools=True, json_mode=True, note="Long-horizon coding and multimodal analysis."),
    "moonshotai/kimi-k2.6": dict(caps=["Code generation", "Code review", "Debugging"], vision=False, tools=True, json_mode=True),
    "deepseek-ai/deepseek-v4.1-flash": dict(caps=["Code generation", "Debugging", "Testing assistance"], vision=False, tools=True, json_mode=True, note="Fast coding workload tier."),
    "deepseek-ai/deepseek-coder-6.7b-instruct": dict(caps=["Code generation"], vision=False, tools=False, json_mode=False),
    "google/gemma-4-31b-it": dict(caps=["Code generation", "Complex planning", "Technical research", "UI/UX reasoning"], vision=False, tools=True, json_mode=True, note="Reasoning, coding and agentic workflows."),
    "google/gemma-3-12b-it": dict(caps=["Summarization", "Classification", "Documentation"], vision=False, tools=False, json_mode=False),
    "google/gemma-3-4b-it": dict(caps=["Classification", "Summarization"], vision=False, tools=False, json_mode=False),
    "google/codegemma-1.1-7b": dict(caps=["Code generation", "Documentation"], vision=False, tools=False, json_mode=False),
    "google/codegemma-7b": dict(caps=["Code generation"], vision=False, tools=False, json_mode=False),
    "google/diffusiongemma-26b-a4b-it": dict(caps=["Image generation", "Media processing assistance"], vision=False, tools=False, json_mode=False, note="Diffusion tier; image synthesis style workloads."),
    "google/gemma-2b": dict(caps=["Classification"], vision=False, tools=False, json_mode=False),
    "google/recurrentgemma-2b": dict(caps=["Classification"], vision=False, tools=False, json_mode=False),
    "google/deplot": dict(caps=["Image understanding", "Structured extraction"], vision=True, tools=False, json_mode=False, note="Chart/plot understanding specialist."),
    "meta/muse-glimmer-30b": dict(caps=["Image understanding", "UI/UX reasoning", "Summarization"], vision=True, tools=False, json_mode=True, note="Image-aware analysis tier."),
    "meta/llama-3.2-11b-vision-instruct": dict(caps=["Image understanding", "Summarization"], vision=True, tools=False, json_mode=False),
    "meta/llama-3.2-90b-vision-instruct": dict(caps=["Image understanding", "UI/UX reasoning", "Structured extraction"], vision=True, tools=False, json_mode=False, note="Heavier image understanding tier."),
    "meta/llama-guard-4-12b": dict(caps=["Safety filtering"], vision=True, tools=False, json_mode=False, note="Safety classifier for input/output screening."),
    "meta/codellama-70b": dict(caps=["Code generation"], vision=False, tools=False, json_mode=False),
    "meta/llama2-70b": dict(caps=["Summarization"], vision=False, tools=False, json_mode=False),
    "microsoft/phi-3-vision-128k-instruct": dict(caps=["Image understanding"], vision=True, tools=False, json_mode=False),
    "microsoft/phi-3.5-moe-instruct": dict(caps=["Summarization", "Code generation"], vision=False, tools=False, json_mode=False),
    "microsoft/kosmos-2": dict(caps=["Image understanding"], vision=True, tools=False, json_mode=False, note="Grounded multimodal specialist."),
    "mistralai/mistral-large-2-instruct": dict(caps=["Complex planning", "Technical research", "Code review", "Documentation"], vision=False, tools=True, json_mode=True),
    "mistralai/mistral-large": dict(caps=["Complex planning", "Summarization"], vision=False, tools=True, json_mode=False),
    "mistralai/codestral-22b-instruct-v0.1": dict(caps=["Code generation", "Code review", "Debugging"], vision=False, tools=True, json_mode=True),
    "mistralai/mixtral-8x22b-v0.1": dict(caps=["Summarization", "Classification"], vision=False, tools=False, json_mode=False),
    "mistralai/mistral-7b-instruct-v0.3": dict(caps=["Classification", "Summarization"], vision=False, tools=False, json_mode=False),
    "nv-mistralai/mistral-nemo-12b-instruct": dict(caps=["Summarization", "Classification", "Marketing text"], vision=False, tools=False, json_mode=False),
    "ibm/granite-34b-code-instruct": dict(caps=["Code generation", "Documentation"], vision=False, tools=False, json_mode=False),
    "ibm/granite-8b-code-instruct": dict(caps=["Code generation"], vision=False, tools=False, json_mode=False),
    "ibm/granite-3.0-8b-instruct": dict(caps=["Summarization", "Classification"], vision=False, tools=False, json_mode=False),
    "ibm/granite-3.0-3b-a800m-instruct": dict(caps=["Classification"], vision=False, tools=False, json_mode=False),
    "openai/gpt-oss-20b": dict(caps=["Code generation", "Classification", "Structured extraction", "Documentation"], vision=False, tools=True, json_mode=True, note="Lightweight reasoning and structured tasks."),
    "01-ai/yi-large": dict(caps=["Summarization", "Classification"], vision=False, tools=False, json_mode=False),
    "ai21labs/jamba-1.5-large-instruct": dict(caps=["Summarization", "Classification"], vision=False, tools=False, json_mode=False),
    "aisingapore/sea-lion-7b-instruct": dict(caps=["Translation", "Classification"], vision=False, tools=False, json_mode=False, note="Southeast-Asian language coverage."),
    "bigcode/starcoder2-15b": dict(caps=["Code generation"], vision=False, tools=False, json_mode=False),
    "databricks/dbrx-instruct": dict(caps=["Summarization", "Classification"], vision=False, tools=False, json_mode=False),
    "writer/palmyra-creative-122b": dict(caps=["Marketing text", "Documentation"], vision=False, tools=False, json_mode=False),
    "writer/palmyra-med-70b": dict(caps=["Summarization"], vision=False, tools=False, json_mode=False),
    "writer/palmyra-med-70b-32k": dict(caps=["Summarization", "Documentation"], vision=False, tools=False, json_mode=False),
    "writer/palmyra-fin-70b-32k": dict(caps=["Summarization", "Classification"], vision=False, tools=False, json_mode=False),
    "poolside/laguna-xs-2.1": dict(caps=["Code generation", "Code review"], vision=False, tools=True, json_mode=False, note="Code-specialist tier."),
    "zyphra/zamba2-7b-instruct": dict(caps=["Classification", "Summarization"], vision=False, tools=False, json_mode=False),
    "nvidia/riva-translate-4b-instruct": dict(caps=["Translation"], vision=False, tools=False, json_mode=False, note="Riva translation tier."),
    "nvidia/riva-translate-4b-instruct-v2": dict(caps=["Translation"], vision=False, tools=False, json_mode=False, note="Riva translation v2; preferred translation tier."),
    "nvidia/nemotron-3-embed-1b": dict(caps=["Semantic search"], vision=False, tools=False, json_mode=False, note="Text embedding model."),
    "nvidia/nv-embedqa-mistral-7b-v2": dict(caps=["Semantic search"], vision=False, tools=False, json_mode=False, note="QA-retrieval embedding model."),
    "nvidia/embed-qa-4": dict(caps=["Semantic search"], vision=False, tools=False, json_mode=False),
    "nvidia/llama-3.2-nv-embedqa-1b-v1": dict(caps=["Semantic search"], vision=False, tools=False, json_mode=False),
    "nvidia/llama-3.2-nemoretriever-1b-vlm-embed-v1": dict(caps=["Semantic search", "Image understanding"], vision=True, tools=False, json_mode=False, note="Multimodal retrieval embedding."),
    "nvidia/llama-nemotron-embed-vl-1b-v2": dict(caps=["Semantic search", "Image understanding"], vision=True, tools=False, json_mode=False),
    "snowflake/arctic-embed-l": dict(caps=["Semantic search"], vision=False, tools=False, json_mode=False),
    "nvidia/nemotron-parse": dict(caps=["Structured extraction", "Image understanding"], vision=True, tools=False, json_mode=False, note="Document parsing/OCR tier."),
    "nvidia/nemotron-parse-2.0": dict(caps=["Structured extraction", "Image understanding"], vision=True, tools=False, json_mode=False),
    "nvidia/neva-22b": dict(caps=["Image understanding"], vision=True, tools=False, json_mode=False),
    "nvidia/vila": dict(caps=["Image understanding"], vision=True, tools=False, json_mode=False),
    "nvidia/nvclip": dict(caps=["Image understanding", "Semantic search"], vision=True, tools=False, json_mode=False, note="CLIP-style image/text embedding."),
    "nvidia/cosmos-reason2-8b": dict(caps=["Image understanding", "Media processing assistance"], vision=True, tools=False, json_mode=False),
    "nvidia/ai-synthetic-video-detector": dict(caps=["Media processing assistance", "Classification"], vision=False, tools=False, json_mode=False),
    "nvidia/llama-3.1-nemoguard-8b-content-safety": dict(caps=["Safety filtering"], vision=False, tools=False, json_mode=False),
    "nvidia/llama-3.1-nemoguard-8b-topic-control": dict(caps=["Safety filtering"], vision=False, tools=False, json_mode=False),
    "nvidia/llama-3.1-nemotron-safety-guard-8b-v3": dict(caps=["Safety filtering"], vision=False, tools=False, json_mode=False),
    "nvidia/nemotron-3.5-content-safety": dict(caps=["Safety filtering"], vision=False, tools=False, json_mode=False),
    "adept/fuyu-8b": dict(caps=["Image understanding"], vision=True, tools=False, json_mode=False),
}

# Models the specification named as candidates (section 9.2) mapped to live ids.
SPEC_CANDIDATES = {
    "glm-5-3": "z-ai/glm-5.3",
    "glm-5-3-flash": "z-ai/glm-5.3-flash",
    "nemotron-3.5-lightning-30b-a3b": "nvidia/nemotron-3.5-lightning-30b-a3b",
    "muse-glimmer-30b": "meta/muse-glimmer-30b",
    "gemma-4-31b-it": "google/gemma-4-31b-it",
    "gpt-oss-20b": "openai/gpt-oss-20b",
    "kimi-k3": "moonshotai/kimi-k3",
    "deepseek-v4.1-flash": "deepseek-ai/deepseek-v4.1-flash",
    "llama-3.2-11b-vision-instruct": "meta/llama-3.2-11b-vision-instruct",
    "llama-3.2-90b-vision-instruct": "meta/llama-3.2-90b-vision-instruct",
}

# Routing preference order per capability (verified catalogue ids only).
ROUTING_TABLE: dict[str, list[str]] = {
    "Complex planning": ["z-ai/glm-5.3", "nvidia/nemotron-3-ultra-550b-a55b", "nvidia/nemotron-3-super-120b-a12b", "moonshotai/kimi-k3", "nvidia/llama-3.1-nemotron-ultra-253b-v1"],
    "Requirements engineering": ["z-ai/glm-5.3", "nvidia/nemotron-3-ultra-550b-a55b", "google/gemma-4-31b-it"],
    "Technical research": ["nvidia/nemotron-3-ultra-550b-a55b", "z-ai/glm-5.3", "mistralai/mistral-large-2-instruct"],
    "Architecture analysis": ["z-ai/glm-5.3", "nvidia/nemotron-3-ultra-550b-a55b", "google/gemma-4-31b-it"],
    "Code generation": ["moonshotai/kimi-k3", "deepseek-ai/deepseek-v4.1-flash", "mistralai/codestral-22b-instruct-v0.1", "nvidia/nemotron-3.5-lightning-30b-a3b", "google/gemma-4-31b-it", "poolside/laguna-xs-2.1", "ibm/granite-34b-code-instruct"],
    "Code review": ["moonshotai/kimi-k3", "mistralai/codestral-22b-instruct-v0.1", "nvidia/nemotron-3-super-120b-a12b"],
    "Debugging": ["deepseek-ai/deepseek-v4.1-flash", "moonshotai/kimi-k3", "nvidia/nemotron-3-super-120b-a12b", "mistralai/codestral-22b-instruct-v0.1"],
    "Testing assistance": ["deepseek-ai/deepseek-v4.1-flash", "nvidia/nemotron-3.5-lightning-30b-a3b", "z-ai/glm-5.3"],
    "Security analysis": ["nvidia/nemotron-3-ultra-550b-a55b", "z-ai/glm-5.3", "mistralai/mistral-large-2-instruct"],
    "UI/UX reasoning": ["google/gemma-4-31b-it", "meta/llama-3.2-90b-vision-instruct", "meta/muse-glimmer-30b"],
    "Image understanding": ["meta/llama-3.2-90b-vision-instruct", "meta/muse-glimmer-30b", "meta/llama-3.2-11b-vision-instruct", "nvidia/nemotron-3-nano-omni-30b-a3b-reasoning", "microsoft/phi-3-vision-128k-instruct"],
    "Structured extraction": ["nvidia/nemotron-parse-2.0", "nvidia/nemotron-parse", "openai/gpt-oss-20b", "meta/llama-3.2-90b-vision-instruct"],
    "Translation": ["nvidia/riva-translate-4b-instruct-v2", "nvidia/riva-translate-4b-instruct"],
    "Semantic search": ["nvidia/nemotron-3-embed-1b", "nvidia/llama-3.2-nv-embedqa-1b-v1", "nvidia/nv-embedqa-mistral-7b-v2", "nvidia/llama-3.2-nemoretriever-1b-vlm-embed-v1"],
    "Summarization": ["nvidia/nemotron-3.5-lightning-30b-a3b", "z-ai/glm-5.3-flash", "openai/gpt-oss-20b", "nv-mistralai/mistral-nemo-12b-instruct"],
    "Classification": ["nvidia/nemotron-3.5-lightning-30b-a3b", "z-ai/glm-5.3-flash", "openai/gpt-oss-20b", "ibm/granite-3.0-8b-instruct"],
    "Documentation": ["z-ai/glm-5.3-flash", "nvidia/nemotron-3.5-lightning-30b-a3b", "mistralai/mistral-large-2-instruct"],
    "Marketing text": ["writer/palmyra-creative-122b", "z-ai/glm-5.3-flash", "meta/llama-3.1-nemotron-70b-instruct"],
    "Media processing assistance": ["nvidia/cosmos-reason2-8b", "nvidia/ai-synthetic-video-detector", "google/diffusiongemma-26b-a4b-it"],
    "Image generation": ["google/diffusiongemma-26b-a4b-it"],
    "Safety filtering": ["nvidia/nemotron-3.5-content-safety", "meta/llama-guard-4-12b", "nvidia/llama-3.1-nemoguard-8b-content-safety"],
}


def _http_json(url: str, key: str = "", timeout: int = 20, method: str = "GET", payload: dict | None = None):
    headers = {"Accept": "application/json", "User-Agent": "nvidia-wep-platform/1.0 (single-user)"}
    if key:
        headers["Authorization"] = f"Bearer {key}"
    data = None
    if payload is not None:
        headers["Content-Type"] = "application/json"
        data = json.dumps(payload).encode()
    req = urllib.request.Request(url, headers=headers, method=method, data=data)
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return json.loads(resp.read().decode("utf-8", "replace"))


# ---------------------------------------------------------------------------
# Discovery / refresh
# ---------------------------------------------------------------------------


def classify(model_id: str) -> dict:
    meta = MODEL_KNOWLEDGE.get(model_id)
    if meta:
        return {
            "capabilities": meta["caps"],
            "vision": bool(meta.get("vision")),
            "tools": bool(meta.get("tools")),
            "json_mode": bool(meta.get("json_mode")),
            "note": meta.get("note", ""),
            "classified": True,
        }
    lowered = model_id.lower()
    guess_caps: list[str] = []
    if "code" in lowered or "coder" in lowered:
        guess_caps.append("Code generation")
    if "embed" in lowered or "retriever" in lowered or "clip" in lowered or "arctic" in lowered:
        guess_caps.append("Semantic search")
    if "guard" in lowered or "safety" in lowered:
        guess_caps.append("Safety filtering")
    if "translate" in lowered:
        guess_caps.append("Translation")
    if "vision" in lowered or "-vl" in lowered or "omni" in lowered or "parse" in lowered:
        guess_caps.append("Image understanding")
    if not guess_caps:
        guess_caps.append("Summarization")
    return {
        "capabilities": guess_caps,
        "vision": "Image understanding" in guess_caps,
        "tools": False,
        "json_mode": False,
        "note": "Heuristic classification from identifier; not yet human-verified.",
        "classified": False,
    }


def refresh_models(settings: dict | None = None, verify_health: bool = False) -> dict:
    """Refresh the registry from the live NVIDIA catalogue, falling back to the
    bundled snapshot. Records verification status honestly."""
    settings = settings or db.get_settings()
    key = str(settings.get("nvidia_api_key", "") or "")
    base = str(settings.get("nvidia_base_url", config.DEFAULT_SETTINGS["nvidia_base_url"]))
    source = "live_catalogue"
    ids: list[str] = []
    error = ""
    try:
        payload = _http_json(base.rstrip("/") + "/models", key=key, timeout=20)
        ids = [m["id"] for m in payload.get("data", []) if m.get("id")]
    except Exception as exc:  # network / TLS / auth failure
        error = f"{type(exc).__name__}: {exc}"
        source = "bundled_snapshot"
        snapshot_path = util.ROOT / "assets" / "nvidia_catalog_snapshot.json"
        if not snapshot_path.exists():
            snapshot_path = util.DATA_DIR / "nvidia_catalog_snapshot.json"
        if snapshot_path.exists():
            payload = util.jload(snapshot_path.read_text(), {})
            ids = [m["id"] for m in payload.get("data", []) if m.get("id")]
        else:
            ids = list(MODEL_KNOWLEDGE.keys())

    if not ids:
        return {"ok": False, "source": source, "error": error or "catalogue empty", "count": 0}

    seen_present = set(ids)
    for model_id in ids:
        info = classify(model_id)
        caps = list(info["capabilities"])
        modalities_in = ["text"] + (["image"] if info["vision"] else [])
        out_modalities = ["text"]
        if "Image generation" in caps:
            out_modalities = ["image"]
        if "Semantic search" in caps and not caps:
            out_modalities = ["embedding"]
        if "Semantic search" in caps:
            out_modalities = ["embedding"] + (["text"] if "Summarization" in caps else [])
        if model_id.endswith("-reward") or "embed" in model_id.lower() or "retriever" in model_id.lower() or "arctic" in model_id.lower():
            out_modalities = ["embedding"] if "reward" not in model_id else ["score"]
        row = {
            "id": model_id,
            "provider": "NVIDIA NIM (build.nvidia.com)",
            "display_name": model_id.split("/", 1)[-1],
            "source_url": f"https://build.nvidia.com/{model_id.replace('/', '/')}",
            "deployment_mode": "hosted_api",
            "capabilities_json": util.jdump(caps),
            "input_modalities_json": util.jdump(modalities_in),
            "output_modalities_json": util.jdump(out_modalities),
            "tool_calling": 1 if (info["tools"] and "chat" not in model_id) else 0,
            "structured_output": 1 if info["json_mode"] else 0,
            "context_window": "documented per model card" if info["classified"] else "unknown",
            "auth_required": 1,
            "endpoint": base.rstrip("/") + "/chat/completions" if "Semantic search" not in caps else base.rstrip("/") + "/embeddings",
            "access_restrictions": "NVIDIA developer account and API key required; usage limits apply per account tier.",
            "usage_limits": "per NVIDIA account tier (not inspectable without account console)",
            "verification_status": "catalogue_listed" if source == "live_catalogue" else "snapshot_listed",
            "verified_at": util.now_iso(),
            "health_checked_at": "",
            "last_failure": "",
            "agent_eligibility_json": util.jdump(sorted({c for c in caps})),
            "fallback_candidates_json": util.jdump(ROUTING_TABLE.get(caps[0], [])[:4]),
            "notes": info["note"],
            "discovered_from": BUILD_URL if source == "live_catalogue" else "bundled snapshot of " + BUILD_URL,
            "catalog_present": 1,
        }
        db.upsert("models", row, "id")

    # mark previously known models that vanished from the catalogue
    known = db.query("SELECT id FROM models")
    for row in known:
        if row["id"] not in seen_present:
            db.execute(
                "UPDATE models SET catalog_present=0, verification_status='not_in_catalogue', "
                "last_failure=? WHERE id=?",
                ("Absent from current catalogue refresh; not routable.", row["id"]),
            )

    if verify_health and key:
        for row in db.query("SELECT id FROM models WHERE catalog_present=1 LIMIT 3"):
            health_check(row["id"], settings, deep=False, sample=False)

    stats = {
        "ok": True,
        "source": source if not error else f"{source} (live refresh failed: {util.truncate(error, 160)})",
        "error": error,
        "count": len(ids),
        "classified": sum(1 for m in ids if classify(m)["classified"]),
        "unclassified": [m for m in ids if not classify(m)["classified"]],
        "refreshed_at": util.now_iso(),
    }
    clear_candidate_cache()
    db.audit("system", "model_registry_refresh", "models", stats)
    return stats


def health_check(model_id: str, settings: dict | None = None, deep: bool = True, sample: bool = True) -> dict:
    """Probe a model. Without an API key this is an honest 'blocked' result."""
    settings = settings or db.get_settings()
    key = str(settings.get("nvidia_api_key", "") or "")
    base = str(settings.get("nvidia_base_url", config.DEFAULT_SETTINGS["nvidia_base_url"])).rstrip("/")
    row = db.query_one("SELECT * FROM models WHERE id=?", (model_id,))
    if row is None:
        return {"ok": False, "status": "unknown_model", "detail": "model not in registry"}
    caps = util.jload(row["capabilities_json"], [])
    if not key:
        db.execute(
            "UPDATE models SET health_checked_at=?, verification_status=CASE WHEN catalog_present=1 THEN 'catalogue_listed_no_key' ELSE verification_status END, "
            "last_failure=? WHERE id=?",
            (util.now_iso(), "No NVIDIA API key configured: inference not verifiable.", model_id),
        )
        db.audit("system", "model_health_check", model_id, {"result": "blocked_no_key"})
        return {"ok": False, "status": "blocked_no_api_key",
                "detail": "Registry lists the model from the official catalogue; calling it requires an NVIDIA API key."}

    started = util.now_ms()
    try:
        if "Semantic search" in caps:
            payload = {"input": ["health probe"], "model": model_id}
            url = base + "/embeddings"
        else:
            payload = {"model": model_id, "messages": [{"role": "user", "content": "Reply with the single word: ready"}],
                       "max_tokens": 8, "temperature": 0}
            url = base + "/chat/completions"
        data = _http_json(url, key=key, timeout=int(settings.get("provider_timeout_s", 60) or 60),
                          method="POST", payload=payload)
        latency = util.now_ms() - started
        db.execute(
            "UPDATE models SET health_checked_at=?, verification_status='verified_live_call', last_failure='' WHERE id=?",
            (util.now_iso(), model_id),
        )
        db.audit("system", "model_health_check", model_id,
                 {"result": "ok", "latency_ms": latency, "deep": deep})
        return {"ok": True, "status": "verified_live_call", "latency_ms": latency,
                "sample": sample, "response_keys": list(data.keys())}
    except Exception as exc:
        detail = f"{type(exc).__name__}: {exc}"
        db.execute("UPDATE models SET health_checked_at=?, last_failure=? WHERE id=?",
                   (util.now_iso(), util.truncate(detail, 300), model_id))
        db.audit("system", "model_health_check", model_id, {"result": "failed", "detail": detail})
        return {"ok": False, "status": "call_failed", "detail": detail}


# ---------------------------------------------------------------------------
# Routing
# ---------------------------------------------------------------------------


_CANDIDATE_CACHE: dict[tuple, tuple[float, list[dict]]] = {}
_CANDIDATE_TTL = 120.0


def clear_candidate_cache() -> None:
    _CANDIDATE_CACHE.clear()


def candidates_for(capability: str, require_vision: bool = False, limit: int = 5) -> list[dict]:
    """Return verified, catalogue-present candidates for a capability (cached)."""
    cache_key = (capability, require_vision, limit)
    hit = _CANDIDATE_CACHE.get(cache_key)
    if hit and (time.time() - hit[0]) < _CANDIDATE_TTL:
        return hit[1]
    preferred = ROUTING_TABLE.get(capability, [])
    out: list[dict] = []

    def add(model_id: str, reason: str):
        row = db.query_one("SELECT * FROM models WHERE id=? AND catalog_present=1", (model_id,))
        if row is None:
            return
        caps = util.jload(row["capabilities_json"], [])
        if capability not in caps:
            return
        if require_vision and "image" not in util.jload(row["input_modalities_json"], []):
            return
        if any(o["model_id"] == model_id for o in out):
            return
        out.append({
            "model_id": model_id,
            "reason": reason,
            "verification_status": row["verification_status"],
            "deployment_mode": row["deployment_mode"],
        })

    for i, model_id in enumerate(preferred):
        add(model_id, f"ranked site {i + 1} for capability '{capability}'")
    if len(out) < limit:
        for row in db.query("SELECT id FROM models WHERE catalog_present=1 ORDER BY id"):
            add(row["id"], f"catalogue-present fallback supporting '{capability}'")
    result = out[:limit]
    _CANDIDATE_CACHE[cache_key] = (time.time(), result)
    return result


def route(capability: str, run_id: str = "", task_id: str = "", agent_id: str = "",
          require_vision: bool = False, prefer: list[str] | None = None, settings: dict | None = None) -> dict:
    """Deterministic capability routing. Records the decision with its reason."""
    settings = settings or db.get_settings()
    ranked = candidates_for(capability, require_vision=require_vision)
    if prefer:
        ranked.sort(key=lambda c: 0 if c["model_id"] in prefer else 1)
    chosen = ranked[0] if ranked else None
    live = config.has_api_key(settings) and config.model_live_enabled(settings)
    decision = {
        "capability": capability,
        "chosen_model": chosen["model_id"] if chosen else None,
        "reason": (chosen["reason"] if chosen else
                   f"No catalogue-present model supports '{capability}' in the current registry."),
        "candidates": ranked,
        "status": "routable" if chosen else "no_candidate",
        "provider_called": 0,
        "live_inference_available": bool(live and chosen),
    }
    db.insert("routing_decisions", {
        "ts": util.now_iso(), "capability": capability, "run_id": run_id, "task_id": task_id,
        "agent_id": agent_id, "chosen_model": decision["chosen_model"], "reason": decision["reason"],
        "candidates_json": util.jdump(ranked), "status": decision["status"],
        "provider_called": 0,
    })
    return decision


def registry_stats() -> dict:
    total = db.query_one("SELECT COUNT(*) c FROM models")["c"]
    present = db.query_one("SELECT COUNT(*) c FROM models WHERE catalog_present=1")["c"]
    verified = db.query_one("SELECT COUNT(*) c FROM models WHERE verification_status='verified_live_call'")["c"]
    by_cap = {}
    for row in db.query("SELECT capabilities_json FROM models WHERE catalog_present=1"):
        for cap in util.jload(row["capabilities_json"], []):
            by_cap[cap] = by_cap.get(cap, 0) + 1
    return {"total": total, "catalog_present": present, "live_verified": verified,
            "by_capability": dict(sorted(by_cap.items()))}


def invoke(model_id: str, messages: list[dict], settings: dict | None = None,
           max_tokens: int = 512, temperature: float = 0.2, timeout: int | None = None) -> dict:
    """Real inference call. Returns ok=False with an explicit reason when blocked."""
    settings = settings or db.get_settings()
    key = str(settings.get("nvidia_api_key", "") or "")
    base = str(settings.get("nvidia_base_url", config.DEFAULT_SETTINGS["nvidia_base_url"])).rstrip("/")
    if not key:
        return {"ok": False, "status": "blocked_no_api_key",
                "detail": "NVIDIA_API_KEY is not configured. Add it in Settings to enable live inference."}
    if not config.model_live_enabled(settings):
        return {"ok": False, "status": "disabled", "detail": "Live model calls are disabled in settings."}
    started = util.now_ms()
    attempts, retries = 0, int(settings.get("provider_max_retries", 2) or 2)
    last_error = ""
    while attempts <= retries:
        attempts += 1
        try:
            data = _http_json(
                base + "/chat/completions", key=key,
                timeout=timeout or int(settings.get("provider_timeout_s", 60) or 60),
                method="POST",
                payload={"model": model_id, "messages": messages, "max_tokens": max_tokens,
                         "temperature": temperature},
            )
            text = ""
            choices = data.get("choices") or []
            if choices:
                text = (choices[0].get("message") or {}).get("content", "") or ""
            usage = data.get("usage", {})
            db.audit("system", "model_invoke", model_id,
                     {"ok": True, "attempts": attempts, "latency_ms": util.now_ms() - started,
                      "prompt_tokens": usage.get("prompt_tokens"), "completion_tokens": usage.get("completion_tokens")})
            return {"ok": True, "status": "ok", "text": text, "usage": usage,
                    "latency_ms": util.now_ms() - started, "attempts": attempts, "model": model_id}
        except urllib.error.HTTPError as exc:
            body = exc.read().decode("utf-8", "replace")[:300] if hasattr(exc, "read") else ""
            last_error = f"HTTP {exc.code}: {body}"
            if exc.code in (401, 403):
                break
            time.sleep(min(2 ** attempts, 8) * 0.1)
        except Exception as exc:
            last_error = f"{type(exc).__name__}: {exc}"
            time.sleep(min(2 ** attempts, 8) * 0.1)
    db.execute("UPDATE models SET last_failure=? WHERE id=?", (util.truncate(last_error, 300), model_id))
    db.audit("system", "model_invoke", model_id, {"ok": False, "attempts": attempts, "error": last_error})
    return {"ok": False, "status": "call_failed", "detail": util.truncate(last_error, 400),
            "attempts": attempts, "model": model_id}
