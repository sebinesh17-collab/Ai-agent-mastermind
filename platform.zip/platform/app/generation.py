"""Website generation engine: deterministic, real multi-page static sites.

Output is a complete project version on disk:
  site/ (pages, css, js, assets, sitemap, robots)
  build.mjs (runnable Node build), tests/checks.mjs, README.md, content docs
Every file is written to disk and hashed; nothing is simulated.
"""
from __future__ import annotations

import html
import json
import re
from pathlib import Path

from . import util

# ---------------------------------------------------------------------------
# palette / design tokens
# ---------------------------------------------------------------------------

# Palettes carry three separate colour roles so contrast is a design decision, not
# an accident: `primary` fills surfaces, `link` is the text-safe variant used for
# links, and `on_primary` is the foreground drawn on top of a primary fill.
# Ratios are asserted by verify.check_design (WCAG AA, 4.5:1 for normal text).
PALETTES = {
    "green-tech": {"primary": "#76b900", "primary_dark": "#4f7d00", "accent": "#00e0b0",
                   "surface": "#0b0f14", "surface_alt": "#121821", "text": "#e8eef6", "muted": "#9fb0c4",
                   "link": "#76b900", "on_primary": "#06110a"},
    "indigo-pro": {"primary": "#4f46e5", "primary_dark": "#3730a3", "accent": "#06b6d4",
                   "surface": "#0b1020", "surface_alt": "#141a2e", "text": "#eef1ff", "muted": "#a5b0d0",
                   "link": "#766feb", "on_primary": "#ffffff"},
    "warm-craft": {"primary": "#b45309", "primary_dark": "#7c2d12", "accent": "#f59e0b",
                   "surface": "#141110", "surface_alt": "#1f1a17", "text": "#f7efe7", "muted": "#c3b1a3",
                   "link": "#bd6827", "on_primary": "#ffffff"},
    "clinic-blue": {"primary": "#0284c7", "primary_dark": "#075985", "accent": "#22d3ee",
                    "surface": "#0a1520", "surface_alt": "#10202f", "text": "#e6f2fb", "muted": "#9db8cc",
                    "link": "#0786c8", "on_primary": "#06110a"},
    "editorial-light": {"primary": "#111827", "primary_dark": "#000000", "accent": "#e11d48",
                        "surface": "#ffffff", "surface_alt": "#f4f5f7", "text": "#111827", "muted": "#5b6472",
                        "link": "#111827", "on_primary": "#ffffff"},
}

SECTION_LIBRARY = {
    "hero", "stats", "services", "features", "gallery", "menu", "pricing", "testimonials",
    "faq", "cta", "contact", "team", "process", "about", "hours",
}


# Pages a user can ask for explicitly; detected from the prompt so a requested
# page is never silently dropped from the sitemap.
REQUESTABLE_PAGES = ["pricing", "gallery", "menu", "shop", "work", "courses", "features",
                     "team", "services", "about", "contact"]


def requested_pages(prompt: str) -> list[str]:
    low = (prompt or "").lower()
    found = []
    for slug in REQUESTABLE_PAGES:
        if slug in low or f"{slug} page" in low:
            found.append(slug)
    return found


def pick_palette(key: str) -> dict:
    return PALETTES.get(key, PALETTES["green-tech"])


def _e(text) -> str:
    return html.escape(str(text), quote=True)


# ---------------------------------------------------------------------------
# blueprint
# ---------------------------------------------------------------------------

ARCHETYPES = {
    "restaurant": {"pages": ["index", "menu", "about", "contact"],
                   "sections": ["hero", "features", "menu", "testimonials", "hours", "cta", "contact"],
                   "palette": "warm-craft"},
    "clinic": {"pages": ["index", "services", "team", "contact"],
               "sections": ["hero", "services", "stats", "team", "faq", "cta", "contact"],
               "palette": "clinic-blue"},
    "portfolio": {"pages": ["index", "work", "about", "contact"],
                  "sections": ["hero", "stats", "gallery", "process", "testimonials", "cta", "contact"],
                  "palette": "editorial-light"},
    "saas": {"pages": ["index", "features", "pricing", "contact"],
             "sections": ["hero", "features", "stats", "pricing", "testimonials", "faq", "cta", "contact"],
             "palette": "indigo-pro"},
    "ecommerce": {"pages": ["index", "shop", "about", "contact"],
                  "sections": ["hero", "features", "gallery", "testimonials", "faq", "cta", "contact"],
                  "palette": "warm-craft"},
    "agency": {"pages": ["index", "services", "work", "contact"],
               "sections": ["hero", "services", "stats", "process", "gallery", "testimonials", "cta", "contact"],
               "palette": "indigo-pro"},
    "education": {"pages": ["index", "courses", "about", "contact"],
                  "sections": ["hero", "features", "stats", "gallery", "testimonials", "faq", "cta", "contact"],
                  "palette": "clinic-blue"},
    "services": {"pages": ["index", "services", "about", "contact"],
                 "sections": ["hero", "services", "features", "stats", "process", "testimonials", "faq", "cta", "contact"],
                 "palette": "green-tech"},
}

KEYWORD_ARCHETYPE = [
    ("restaurant", ["restaurant", "cafe", "café", "bakery", "food", "dining", "menu", "catering", "cloud kitchen", "biryani", "hotel"]),
    ("clinic", ["clinic", "hospital", "dental", "dentist", "doctor", "health", "medical", "physiotherapy", "wellness", "diagnostic"]),
    ("portfolio", ["portfolio", "freelancer", "resume", "photographer", "designer", "artist", "personal site", "illustrator"]),
    ("saas", ["saas", "app", "platform", "dashboard", "software", "tool", "api", "crm", "analytics", "startup"]),
    ("ecommerce", ["shop", "store", "ecommerce", "e-commerce", "products", "boutique", "sell", "retail", "cart", "jewel"]),
    ("education", ["school", "college", "institute", "academy", "course", "coaching", "tuition", "training", "tutorial"]),
    ("agency", ["agency", "marketing", "studio", "consultancy", "consulting", "design firm", "advertising", "bpo"]),
]


def classify_archetype(prompt: str) -> tuple[str, str]:
    low = prompt.lower()
    for key, words in KEYWORD_ARCHETYPE:
        if any(w in low for w in words):
            return key, key.capitalize()
    return "services", "Business"


def detect_languages(prompt: str) -> list[str]:
    langs = ["en"]
    mapping = {"tamil": "ta", "hindi": "hi", "telugu": "te", "kannada": "kn", "malayalam": "ml",
               "marathi": "mr", "bengali": "bn", "gujarati": "gu", "punjabi": "pa",
               "arabic": "ar", "french": "fr", "german": "de", "spanish": "es", "japanese": "ja"}
    low = prompt.lower()
    for word, code in mapping.items():
        if word in low and code not in langs:
            langs.append(code)
    return langs


def build_blueprint(project: dict) -> dict:
    """Sitemap, sections, palette and content model derived from the brief."""
    prompt = project.get("prompt", "")
    brief = util.jload(project.get("brief_json"), {})
    archetype, label = classify_archetype(prompt)
    if brief.get("archetype"):
        archetype = brief["archetype"]
    config = ARCHETYPES.get(archetype, ARCHETYPES["services"])
    name = project.get("name") or brief.get("name") or "Your Business"
    palette_name = config["palette"]
    tokens = pick_palette(palette_name)
    tokens = dict(tokens)
    tokens["radius"] = "14px"
    tokens["maxw"] = "1120px"
    pages = list(config["pages"])
    requested = requested_pages(prompt)
    for slug in requested:
        if slug not in pages and len(pages) < 6:
            pages.append(slug)
    nav = [(p, PAGE_TITLES.get(p, p.replace("-", " ").title())) for p in pages]
    return {
        "archetype": archetype,
        "archetype_label": label,
        "brand_name": name,
        "tagline": brief.get("tagline") or f"{label} built for {brief.get('audience', 'your customers')}",
        "pages": [{"slug": p, "title": PAGE_TITLES.get(p, p.title()), "file": f"{p}.html"} for p in pages],
        "sections": config["sections"],
        "palette": palette_name,
        "tokens": tokens,
        "nav": nav,
        "fonts": "system-ui, -apple-system, 'Segoe UI', Roboto, sans-serif",
        "locales": detect_languages(prompt),
        "content_model": {
            "collections": [{"name": "services" if archetype != "ecommerce" else "products",
                             "fields": ["title", "summary", "detail", "order"]},
                            {"name": "testimonials", "fields": ["quote", "author", "role"]},
                            {"name": "faq", "fields": ["question", "answer"]}],
            "global": ["brand", "tagline", "contact", "hours", "social"],
        },
    }


PAGE_TITLES = {"index": "Home", "about": "About", "services": "Services", "contact": "Contact",
               "pricing": "Pricing", "menu": "Menu", "shop": "Shop", "work": "Work",
               "features": "Features", "team": "Team", "gallery": "Gallery", "courses": "Courses"}


# ---------------------------------------------------------------------------
# content authoring (deterministic baseline; optionally model-enriched later)
# ---------------------------------------------------------------------------


def author_content(project: dict, blueprint: dict, requirements: dict) -> dict:
    name = blueprint["brand_name"]
    archetype = blueprint["archetype"]
    brief = util.jload(project.get("brief_json"), {})
    audience = brief.get("audience") or "local customers"
    industry = project.get("industry") or blueprint["archetype_label"]
    goals = brief.get("goals") or ["generate enquiries", "build trust", "explain the offer clearly"]
    services = requirements.get("services") or []
    if not services:
        services = DEFAULT_SERVICES.get(archetype, DEFAULT_SERVICES["services"])
    features = requirements.get("features") or DEFAULT_FEATURES
    return {
        "brand": {
            "name": name,
            "tagline": blueprint["tagline"],
            "industry": industry,
            "audience": audience,
            "description": brief.get("description") or
            f"{name} is a {industry.lower()} serving {audience}. The site is designed to {', '.join(goals[:2])}.",
            "email": brief.get("email") or "hello@example.com",
            "phone": brief.get("phone") or "+00 00000 00000",
            "address": brief.get("address") or "Address configured during project setup",
            "hours": brief.get("hours") or "Mon–Sat, 9:00–18:00",
        },
        "hero": {
            "eyebrow": f"{industry} · {audience}",
            "headline": brief.get("headline") or PRIMARY_HEADLINES.get(archetype, f"{name}: {blueprint['tagline']}"),
            "sub": brief.get("subheadline") or
            f"A clear, fast, accessible website that explains what {name} offers and makes it easy for {audience} to take the next step.",
            "primary_cta": brief.get("primary_cta") or ("Book a table" if archetype == "restaurant" else "Get started"),
            "secondary_cta": "See what we offer",
        },
        "services": services,
        "features": features,
        "stats": build_stats(archetype),
        "process": PROCESS_STEPS.get(archetype, PROCESS_STEPS["services"]),
        "testimonials": [
            {"quote": f"The {blueprint['archetype_label'].lower()} experience was clear, quick and exactly what we were promised.",
             "author": "Verified customer", "role": f"{industry} client"},
            {"quote": "Everything was explained up front — no surprises, no hidden steps.",
             "author": "Returning customer", "role": "Repeat client"},
            {"quote": "Easy to reach, easy to work with, and the results speak for themselves.",
             "author": "New customer", "role": "First-time client"},
        ],
        "faq": [
            {"question": f"How do I contact {name}?", "answer": "Use the contact form on this site or call the number in the footer — both reach the same team."},
            {"question": "What are your working hours?", "answer": "Current hours are shown in the footer and on the home page; we reply to messages within one working day."},
            {"question": "Do you serve customers outside the local area?", "answer": "Yes — remote enquiries are handled the same way as local ones, with the same response times."},
            {"question": "How is my information handled?", "answer": "Form submissions are used only to respond to your enquiry. See the privacy notice for details."},
        ],
        "cta": {"title": f"Ready to talk to {name}?",
                "body": "Send a short message with what you need. We reply with clear next steps and honest timelines.",
                "button": "Send an enquiry"},
        "seo": {
            "title_template": "{page} | {brand}",
            "description_template": "{brand} — {tagline}. {page} information, contact details and enquiry form.",
            "keywords": [industry.lower(), audience.lower(), name.lower()],
        },
        "generated": True,
    }


PRIMARY_HEADLINES = {
    "restaurant": "Freshly made, honestly priced — served the way you remember it",
    "clinic": "Careful, evidence-based care for you and your family",
    "portfolio": "Selected work, explained clearly",
    "saas": "Software that removes the busywork from your week",
    "ecommerce": "Quality products, straightforward pricing, fast delivery",
    "agency": "Growth work that is measured, not guessed",
    "education": "Structured learning with visible progress",
    "services": "Reliable service, clear pricing, real people",
}

DEFAULT_SERVICES = {
    "restaurant": [
        {"title": "Signature dishes", "summary": "A concise menu of long-standing favourites, prepared fresh each day."},
        {"title": "Family platters", "summary": "Sharing portions for groups, with vegetarian options clearly marked."},
        {"title": "Takeaway and delivery", "summary": "Order ahead by phone for pickup, or delivery within the local area."},
        {"title": "Private events", "summary": "Small celebrations and office lunches hosted with set menus."},
    ],
    "clinic": [
        {"title": "Consultations", "summary": "Unhurried appointments with a written plan you can take home."},
        {"title": "Diagnostics", "summary": "On-site testing with results explained in plain language."},
        {"title": "Follow-up care", "summary": "Scheduled reviews so treatment is adjusted, not guessed."},
        {"title": "Preventive check-ups", "summary": "Annual reviews focused on early, low-cost intervention."},
    ],
    "portfolio": [
        {"title": "Product design", "summary": "Interface work from discovery to a tested, shipped release."},
        {"title": "Brand systems", "summary": "Identity, typography and tokens that hold up across surfaces."},
        {"title": "Prototyping", "summary": "Fast, testable builds that answer the risky questions first."},
        {"title": "Consulting", "summary": "Short engagements to unblock an existing team."},
    ],
    "saas": [
        {"title": "Unified workspace", "summary": "One place for the records, files and conversations your team already uses."},
        {"title": "Automations", "summary": "Rule-based triggers that remove repetitive admin work."},
        {"title": "Reporting", "summary": "Dashboards built from real activity, exportable on demand."},
        {"title": "Integrations", "summary": "Connect the tools you already pay for instead of replacing them."},
    ],
    "ecommerce": [
        {"title": "Curated catalogue", "summary": "A focused range with accurate descriptions and honest stock status."},
        {"title": "Fast dispatch", "summary": "Orders packed and shipped within one working day."},
        {"title": "Easy returns", "summary": "A simple returns window with clear instructions."},
        {"title": "Support", "summary": "Real replies from real people, by email or phone."},
    ],
    "agency": [
        {"title": "Strategy", "summary": "Positioning and channel choices backed by demand evidence."},
        {"title": "Content and SEO", "summary": "Pages that answer the questions customers actually search."},
        {"title": "Paid acquisition", "summary": "Measured campaigns with defined stop-loss thresholds."},
        {"title": "Analytics", "summary": "Tracking that answers business questions, not vanity metrics."},
    ],
    "education": [
        {"title": "Foundational courses", "summary": "Structured syllabi with weekly checkpoints."},
        {"title": "Small-group coaching", "summary": "Capped batch sizes so every learner gets attention."},
        {"title": "Practice material", "summary": "Graded exercises with worked solutions."},
        {"title": "Progress reporting", "summary": "Written feedback for learners and parents."},
    ],
    "services": [
        {"title": "Consultation", "summary": "We start by understanding the problem before quoting a solution."},
        {"title": "Delivery", "summary": "Work delivered to an agreed scope with named milestones."},
        {"title": "Support", "summary": "Post-delivery support windows stated up front."},
        {"title": "Maintenance", "summary": "Ongoing care plans so nothing quietly degrades."},
    ],
}

DEFAULT_FEATURES = [
    {"title": "Mobile-first", "body": "Layouts designed for the phone in your customer's hand, then scaled up."},
    {"title": "Fast by default", "body": "No bloated page builder. Pages ship as plain, cacheable files."},
    {"title": "Accessible markup", "body": "Semantic HTML, labelled controls and contrast-checked colour."},
    {"title": "Search-ready", "body": "Titles, descriptions, structured data and a generated sitemap."},
    {"title": "Enquiry capture", "body": "A validated contact form with a clear success state."},
    {"title": "Easy to maintain", "body": "Content lives in structured data files, so edits stay low-risk."},
]

PROCESS_STEPS = {
    "restaurant": [("Reserve or call", "Tell us the date, time and party size."),
                   ("We confirm", "You get a confirmation with any dietary notes recorded."),
                   ("Visit", "Arrive to a table that is ready, with your order noted.")],
    "clinic": [("Book", "Choose an appointment slot online or by phone."),
               ("Consult", "Discuss symptoms and history at an unhurried pace."),
               ("Plan", "Leave with a written plan, including follow-up timing.")],
    "portfolio": [("Brief", "Share the problem, constraints and timeline."),
                  ("Proposal", "A scoped plan with milestones and a fixed price."),
                  ("Delivery", "Reviewed work, handed over with documentation.")],
    "saas": [("Start free", "Create an account, no card required."),
             ("Import", "Bring in existing records with guided mapping."),
             ("Work", "Invite the team and automate the repetitive steps.")],
    "services": [("Enquiry", "Send a short message describing what you need."),
                 ("Assessment", "We confirm scope, timeline and price in writing."),
                 ("Delivery", "Work happens to agreed milestones, then support begins.")],
}


def build_stats(archetype: str) -> list[dict]:
    base = {
        "restaurant": [("18", "years serving"), ("40+", "dishes on the menu"), ("4.8★", "average rating")],
        "clinic": [("12k+", "consultations"), ("9", "specialities"), ("24h", "report turnaround")],
        "portfolio": [("60+", "shipped projects"), ("11", "industries"), ("100%", "client references")],
        "saas": [("1,400+", "teams onboarded"), ("99.9%", "target uptime"), ("7 min", "median setup")],
        "ecommerce": [("25k+", "orders shipped"), ("1 day", "dispatch time"), ("30 days", "return window")],
        "agency": [("3.4x", "median ROAS"), ("120+", "campaigns run"), ("14", "markets served")],
        "education": [("2,000+", "learners taught"), ("92%", "completion rate"), ("1:12", "coach to learner")],
        "services": [("10+", "years in operation"), ("500+", "projects delivered"), ("48h", "quote turnaround")],
    }
    return [{"value": v, "label": l} for v, l in base.get(archetype, base["services"])]


# ---------------------------------------------------------------------------
# HTML rendering
# ---------------------------------------------------------------------------


def _head(page: dict, blueprint: dict, content: dict, meta: dict, base_prefix: str = "") -> str:
    brand = content["brand"]
    title_tpl = meta.get("title_template") or meta.get("title") or "{page} | {brand}"
    desc_tpl = meta.get("description_template") or meta.get("description") or "{brand} — {tagline}. {page} information and contact details."
    keywords = meta.get("keywords") or [brand["name"].lower()]
    title = title_tpl.replace("{page}", page["title"]).replace("{brand}", brand["name"])
    desc = desc_tpl.replace("{page}", page["title"]).replace("{brand}", brand["name"]).replace("{tagline}", brand["tagline"])
    t = blueprint["tokens"]
    ld = {
        "@context": "https://schema.org",
        "@type": SCHEMA_TYPE.get(blueprint["archetype"], "LocalBusiness"),
        "name": brand["name"],
        "description": brand["description"],
        "email": brand["email"],
        "telephone": brand["phone"],
        "address": {"@type": "PostalAddress", "streetAddress": brand["address"]},
        "url": "https://example.com/",
    }
    return f"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{_e(title)}</title>
<meta name="description" content="{_e(desc)}">
<meta name="keywords" content="{_e(', '.join(keywords))}">
<meta name="theme-color" content="{t['primary']}">
<meta property="og:type" content="website">
<meta property="og:title" content="{_e(title)}">
<meta property="og:description" content="{_e(desc)}">
<meta property="og:locale" content="en">
<meta name="twitter:card" content="summary_large_image">
<link rel="canonical" href="https://example.com/{'index.html' if page['slug'] == 'index' else page['slug'] + '.html'}">
<link rel="stylesheet" href="{base_prefix}css/styles.css">
<link rel="icon" href="{base_prefix}assets/logo.svg" type="image/svg+xml">
<script type="application/ld+json">{json.dumps(ld, ensure_ascii=False)}</script>
</head>
<body>
<a class="skip" href="#main">Skip to main content</a>
"""


SCHEMA_TYPE = {"restaurant": "Restaurant", "clinic": "MedicalClinic", "portfolio": "Person",
               "saas": "SoftwareApplication", "ecommerce": "Store", "agency": "ProfessionalService",
               "education": "EducationalOrganization", "services": "LocalBusiness"}


def _nav(blueprint: dict, current: str, prefix: str = "") -> str:
    brand = blueprint["brand_name"]
    items = []
    for slug, title in blueprint["nav"]:
        href = f"{prefix}{'index.html' if slug == 'index' else slug + '.html'}"
        active = ' aria-current="page"' if slug == current else ""
        items.append(f'<li><a href="{href}"{active}>{_e(title)}</a></li>')
    return f"""<header class="site-header">
  <div class="wrap header-inner">
    <a class="brand" href="{prefix}index.html">
      <img src="{prefix}assets/logo.svg" alt="" width="30" height="30">
      <span>{_e(brand)}</span>
    </a>
    <button class="nav-toggle" aria-expanded="false" aria-controls="site-nav">Menu</button>
    <nav id="site-nav" aria-label="Primary">
      <ul>{''.join(items)}</ul>
    </nav>
  </div>
</header>
"""


def _footer(content: dict, blueprint: dict, prefix: str = "") -> str:
    b = content["brand"]
    return f"""<footer class="site-footer">
  <div class="wrap footer-grid">
    <div>
      <h2 class="footer-heading">{_e(b['name'])}</h2>
      <p>{_e(b['description'])}</p>
    </div>
    <div>
      <h2 class="footer-heading">Contact</h2>
      <ul class="plain">
        <li><a href="mailto:{_e(b['email'])}">{_e(b['email'])}</a></li>
        <li><a href="tel:{_e(re.sub(r'[^+0-9]', '', b['phone']))}">{_e(b['phone'])}</a></li>
        <li>{_e(b['address'])}</li>
      </ul>
    </div>
    <div>
      <h2 class="footer-heading">Hours</h2>
      <p>{_e(b['hours'])}</p>
    </div>
    <div>
      <h2 class="footer-heading">Site</h2>
      <ul class="plain">
        {''.join(f'<li><a href="{prefix}{"index.html" if s == "index" else s + ".html"}">{_e(t)}</a></li>' for s, t in blueprint["nav"])}
        <li><a href="{prefix}sitemap.xml">Sitemap</a></li>
      </ul>
    </div>
  </div>
  <div class="wrap footer-base">
    <p>&copy; <span data-year="1">2026</span> {_e(b["name"])}. All rights reserved.</p>
    <p class="muted">Generated by the {_e(SITE_GENERATOR_LABEL)} — static HTML/CSS/JS, no build step required.</p>
  </div>
</footer>
"""


SITE_GENERATOR_LABEL = "NVIDIA Multi-Agent Website Engineering Platform"


def render_hero(content: dict, blueprint: dict) -> str:
    h = content["hero"]
    return f"""<section class="hero">
  <div class="wrap hero-grid">
    <div>
      <p class="eyebrow">{_e(h['eyebrow'])}</p>
      <h1>{_e(h['headline'])}</h1>
      <p class="lede">{_e(h['sub'])}</p>
      <p class="cta-row">
        <a class="btn primary" href="#contact">{_e(h['primary_cta'])}</a>
        <a class="btn ghost" href="#offerings">{_e(h['secondary_cta'])}</a>
      </p>
    </div>
    <div class="hero-card" role="presentation">
      <img src="assets/og-cover.svg" alt="Abstract illustration representing {_e(content['brand']['name'])}" width="640" height="420">
    </div>
  </div>
</section>"""


def render_stats(content: dict) -> str:
    items = "".join(
        f'<div class="stat"><span class="stat-value">{_e(s["value"])}</span><span class="stat-label">{_e(s["label"])}</span></div>'
        for s in content["stats"])
    return f'<section class="band" aria-label="Key figures"><div class="wrap stat-row">{items}</div></section>'


def render_services(content: dict, heading="What we offer", anchor="offerings") -> str:
    cards = "".join(f"""<article class="card">
      <h3>{_e(s['title'])}</h3>
      <p>{_e(s['summary'])}</p>
    </article>""" for s in content["services"])
    return f"""<section id="{anchor}" class="section">
  <div class="wrap">
    <h2>{_e(heading)}</h2>
    <div class="grid cols-2">{cards}</div>
  </div>
</section>"""


def render_features(content: dict) -> str:
    cards = "".join(f"""<article class="card subtle">
      <h3>{_e(f['title'])}</h3>
      <p>{_e(f['body'])}</p>
    </article>""" for f in content["features"])
    return f"""<section class="section alt">
  <div class="wrap">
    <h2>Why people choose us</h2>
    <div class="grid cols-3">{cards}</div>
  </div>
</section>"""


def render_process(content: dict) -> str:
    steps = "".join(f"""<li class="step">
      <span class="step-no">{i+1}</span>
      <h3>{_e(t)}</h3><p>{_e(b)}</p>
    </li>""" for i, (t, b) in enumerate(content["process"]))
    return f"""<section class="section">
  <div class="wrap"><h2>How it works</h2><ol class="steps">{steps}</ol></div>
</section>"""


def render_testimonials(content: dict) -> str:
    items = "".join(f"""<figure class="quote">
      <blockquote><p>{_e(t['quote'])}</p></blockquote>
      <figcaption>{_e(t['author'])} &middot; <span class="muted">{_e(t['role'])}</span></figcaption>
    </figure>""" for t in content["testimonials"])
    return f"""<section class="section alt">
  <div class="wrap"><h2>What customers say</h2><div class="grid cols-3">{items}</div></div>
</section>"""


def render_faq(content: dict) -> str:
    items = "".join(f"""<details class="faq-item">
      <summary>{_e(f['question'])}</summary>
      <div><p>{_e(f['answer'])}</p></div>
    </details>""" for f in content["faq"])
    return f"""<section class="section">
  <div class="wrap narrow"><h2>Frequently asked questions</h2>{items}</div>
</section>"""


def render_gallery(content: dict, blueprint: dict) -> str:
    tiles = []
    for i in range(1, 7):
        tiles.append(f"""<figure class="tile">
      <img src="assets/tile-{i}.svg" alt="Illustrative tile {i} representing work by {_e(content['brand']['name'])}" width="400" height="260">
      <figcaption>Sample {i} — replace with real photography</figcaption>
    </figure>""")
    return f"""<section class="section alt">
  <div class="wrap"><h2>Recent work</h2>
  <p class="muted">Placeholder tiles are shipped instead of stock photos so nothing is misrepresented; swap in real images before launch.</p>
  <div class="grid cols-3">{''.join(tiles)}</div></div>
</section>"""


def render_menu(content: dict) -> str:
    rows = "".join(f"""<tr><th scope="row">{_e(s['title'])}</th><td>{_e(s['summary'])}</td></tr>"""
                   for s in content["services"])
    return f"""<section class="section">
  <div class="wrap"><h2>Menu highlights</h2>
  <table class="table"><caption class="muted">A short selection — full menu available in store.</caption>
  <tbody>{rows}</tbody></table></div>
</section>"""


def render_pricing(content: dict) -> str:
    tiers = [("Starter", "₹0", ["1 workspace", "Core pages", "Community support"]),
             ("Standard", "₹1,999/mo", ["Unlimited pages", "Priority support", "Analytics"]),
             ("Custom", "Talk to us", ["Dedicated engineer", "SLA", "Onboarding"])]
    cards = "".join(f"""<article class="card price">
      <h3>{_e(name)}</h3>
      <p class="price-value">{_e(price)}</p>
      <ul class="plain">{''.join(f'<li>{_e(f)}</li>' for f in feats)}</ul>
      <a class="btn primary" href="#contact">Choose {_e(name)}</a>
    </article>""" for name, price, feats in tiers)
    return f"""<section id="pricing" class="section alt">
  <div class="wrap"><h2>Simple pricing</h2>
  <p class="muted">Indicative plans — final pricing is confirmed in writing before any commitment.</p>
  <div class="grid cols-3">{cards}</div></div>
</section>"""


def render_hours(content: dict) -> str:
    return f"""<section class="section">
  <div class="wrap narrow"><h2>Opening hours</h2>
  <p class="hours">{_e(content['brand']['hours'])}</p>
  <p class="muted">Hours are also published in the site footer and structured data.</p></div>
</section>"""


def render_team(content: dict, blueprint: dict) -> str:
    roles = ["Founder", "Senior specialist", "Operations lead", "Customer care"]
    cards = "".join(f"""<article class="card team">
      <img src="assets/avatar-{(i % 3) + 1}.svg" alt="" width="72" height="72">
      <h3>{_e(r)}</h3><p class="muted">Biography to be supplied by {_e(blueprint['brand_name'])}.</p>
    </article>""" for i, r in enumerate(roles))
    return f"""<section class="section"><div class="wrap"><h2>Who you will work with</h2>
  <div class="grid cols-4">{cards}</div>
  <p class="muted">Names and photographs are intentionally left as placeholders — no invented people are published.</p>
  </div></section>"""


def render_about(content: dict) -> str:
    b = content["brand"]
    return f"""<section class="section"><div class="wrap narrow">
  <h2>About {_e(b['name'])}</h2>
  <p>{_e(b['description'])}</p>
  <p>We serve {_e(b['audience'])} in {_e(b['industry'].lower())} with a simple promise: say what we will do, do it, and tell you honestly when something changes.</p>
  <h3>What we focus on</h3>
  <ul>{''.join(f'<li>{_e(s["title"])} — {_e(s["summary"])}</li>' for s in content['services'])}</ul>
</div></section>"""


def render_cta(content: dict) -> str:
    c = content["cta"]
    return f"""<section class="section cta-band">
  <div class="wrap cta-inner">
    <h2>{_e(c['title'])}</h2>
    <p>{_e(c['body'])}</p>
    <a class="btn primary" href="#contact">{_e(c['button'])}</a>
  </div>
</section>"""


def render_contact(content: dict) -> str:
    b = content["brand"]
    return f"""<section id="contact" class="section alt">
  <div class="wrap contact-grid">
    <div>
      <h2>Contact us</h2>
      <p>Send a message and we will reply with next steps. Fields marked required must be filled in.</p>
      <form class="contact-form" action="#" method="post" novalidate>
        <div class="field">
          <label for="name">Your name <span aria-hidden="true">*</span></label>
          <input id="name" name="name" type="text" autocomplete="name" required>
        </div>
        <div class="field">
          <label for="email">Email address <span aria-hidden="true">*</span></label>
          <input id="email" name="email" type="email" autocomplete="email" required>
        </div>
        <div class="field">
          <label for="phone">Phone (optional)</label>
          <input id="phone" name="phone" type="tel" autocomplete="tel">
        </div>
        <div class="field">
          <label for="message">How can we help? <span aria-hidden="true">*</span></label>
          <textarea id="message" name="message" rows="5" required></textarea>
        </div>
        <p class="hint">We use your details only to answer this enquiry.</p>
        <button class="btn primary" type="submit">Send enquiry</button>
        <p class="form-status" role="status" aria-live="polite"></p>
      </form>
    </div>
    <aside class="contact-aside">
      <h3>Direct contact</h3>
      <ul class="plain">
        <li>Email: <a href="mailto:{_e(b['email'])}">{_e(b['email'])}</a></li>
        <li>Phone: <a href="tel:{_e(re.sub(r'[^+0-9]', '', b['phone']))}">{_e(b['phone'])}</a></li>
        <li>Address: {_e(b['address'])}</li>
        <li>Hours: {_e(b['hours'])}</li>
      </ul>
    </aside>
  </div>
</section>"""


RENDERERS = {
    "hero": lambda c, b: render_hero(c, b),
    "stats": lambda c, b: render_stats(c),
    "services": lambda c, b: render_services(c, heading=f"Our {'menu of' if b['archetype']=='restaurant' else ''} services".replace('  ', ' ').strip()),
    "features": lambda c, b: render_features(c),
    "process": lambda c, b: render_process(c),
    "testimonials": lambda c, b: render_testimonials(c),
    "faq": lambda c, b: render_faq(c),
    "gallery": lambda c, b: render_gallery(c, b),
    "menu": lambda c, b: render_menu(c),
    "pricing": lambda c, b: render_pricing(c),
    "hours": lambda c, b: render_hours(c),
    "team": lambda c, b: render_team(c, b),
    "about": lambda c, b: render_about(c),
    "cta": lambda c, b: render_cta(c),
    "contact": lambda c, b: render_contact(c),
}


def render_page_header(page: dict, blueprint: dict, content: dict) -> str:
    """Every non-home page opens with its own single h1 so the document outline is valid."""
    brand = content["brand"]
    subtitles = {
        "about": f"Who we are, what we do and how {brand['name']} works with {brand['audience']}.",
        "services": f"Everything {brand['name']} offers, described in plain language.",
        "contact": f"How to reach {brand['name']} and what happens after you send a message.",
        "team": f"The people you will actually deal with at {brand['name']}.",
        "pricing": f"Indicative plans from {brand['name']}, confirmed in writing before commitment.",
        "menu": f"What is on offer at {brand['name']} right now.",
        "shop": f"The current range from {brand['name']}.",
        "work": f"Selected work delivered by {brand['name']}.",
        "features": f"What the {brand['name']} platform does.",
        "gallery": f"A look at {brand['name']} in practice.",
        "courses": f"Programmes offered by {brand['name']}.",
    }
    sub = subtitles.get(page["slug"], f"{page['title']} — {brand['name']}.")
    return (f'<section class="section page-head"><div class="wrap narrow">'
            f'<p class="eyebrow">{_e(brand["name"])}</p><h1>{_e(page["title"])}</h1>'
            f'<p class="lede">{_e(sub)}</p></div></section>')


def render_page(page: dict, blueprint: dict, content: dict) -> str:
    slug = page["slug"]
    if slug == "index":
        order = [s for s in blueprint["sections"] if s in RENDERERS]
    else:
        preferred = {
            "about": ["about", "stats", "team", "testimonials", "cta"],
            "services": ["services", "process", "features", "faq", "cta"],
            "features": ["features", "stats", "faq", "cta"],
            "pricing": ["pricing", "faq", "cta"],
            "menu": ["menu", "hours", "testimonials", "cta"],
            "shop": ["gallery", "features", "testimonials", "cta"],
            "work": ["gallery", "process", "testimonials", "cta"],
            "courses": ["services", "features", "stats", "cta"],
            "team": ["team", "stats", "cta"],
            "gallery": ["gallery", "cta"],
            "contact": ["contact", "hours", "faq"],
        }.get(slug, ["services", "features", "cta", "contact"])
        order = [s for s in preferred if s in RENDERERS]
    body = "\n".join(RENDERERS[s](content, blueprint) for s in order)
    if slug != "index":
        body = render_page_header(page, blueprint, content) + "\n" + body
    return (_head(page, blueprint, content, content["seo"]) + _nav(blueprint, slug) +
            f'<main id="main">\n{body}\n</main>\n' + _footer(content, blueprint) +
            '<script src="js/main.js" defer></script>\n</body>\n</html>\n')


# ---------------------------------------------------------------------------
# CSS / JS / assets
# ---------------------------------------------------------------------------


def render_css(tokens: dict) -> str:
    t = tokens
    return f""":root {{
  --primary: {t['primary']};
  --primary-dark: {t['primary_dark']};
  --accent: {t['accent']};
  --link: {t.get('link', t['primary'])};
  --on-primary: {t.get('on_primary', '#06110a')};
  --surface: {t['surface']};
  --surface-alt: {t['surface_alt']};
  --text: {t['text']};
  --muted: {t['muted']};
  --radius: {t['radius']};
  --maxw: {t['maxw']};
  --border: color-mix(in srgb, {t['muted']} 28%, transparent);
}}
* {{ box-sizing: border-box; }}
html {{ scroll-behavior: smooth; }}
body {{
  margin: 0; background: var(--surface); color: var(--text);
  font-family: {t.get('fonts', "system-ui, -apple-system, 'Segoe UI', Roboto, sans-serif")};
  line-height: 1.6; font-size: 17px;
}}
img {{ max-width: 100%; height: auto; display: block; }}
a {{ color: var(--link); }}
a:hover {{ color: var(--accent); }}
:focus-visible {{ outline: 3px solid var(--accent); outline-offset: 2px; }}
.skip {{ position: absolute; left: -9999px; }}
.skip:focus {{ left: 1rem; top: 1rem; background: var(--primary); color: var(--on-primary); padding: .6rem 1rem; border-radius: var(--radius); z-index: 50; }}
.wrap {{ width: min(100% - 2.5rem, var(--maxw)); margin-inline: auto; }}
.narrow {{ max-width: 72ch; }}
.muted {{ color: var(--muted); }}
.plain {{ list-style: none; padding: 0; margin: 0; display: grid; gap: .35rem; }}
.site-header {{ position: sticky; top: 0; z-index: 20; background: color-mix(in srgb, var(--surface) 92%, transparent); border-bottom: 1px solid var(--border); backdrop-filter: blur(8px); }}
.header-inner {{ display: flex; align-items: center; justify-content: space-between; gap: 1rem; padding: .7rem 0; }}
.brand {{ display: inline-flex; align-items: center; gap: .55rem; font-weight: 700; text-decoration: none; color: var(--text); }}
.site-header nav ul {{ display: flex; gap: 1.1rem; list-style: none; margin: 0; padding: 0; }}
.site-header nav a {{ text-decoration: none; color: var(--text); padding: .3rem .1rem; }}
.site-header nav a[aria-current="page"] {{ color: var(--primary); border-bottom: 2px solid var(--primary); }}
.nav-toggle {{ display: none; background: transparent; color: var(--text); border: 1px solid var(--border); border-radius: var(--radius); padding: .4rem .7rem; }}
.hero {{ padding: 4rem 0 3rem; background: radial-gradient(1200px 400px at 15% -10%, color-mix(in srgb, var(--primary) 22%, transparent), transparent); }}
.hero-grid {{ display: grid; gap: 2.5rem; grid-template-columns: 1.2fr .8fr; align-items: center; }}
.eyebrow {{ text-transform: uppercase; letter-spacing: .12em; font-size: .78rem; color: var(--accent); margin: 0 0 .6rem; }}
h1 {{ font-size: clamp(2rem, 4.4vw, 3.1rem); line-height: 1.15; margin: 0 0 1rem; }}
h2 {{ font-size: clamp(1.5rem, 2.6vw, 2.1rem); margin: 0 0 1rem; }}
h3 {{ font-size: 1.12rem; margin: 0 0 .5rem; }}
.lede {{ font-size: 1.1rem; color: var(--muted); max-width: 60ch; }}
.cta-row {{ display: flex; gap: .8rem; flex-wrap: wrap; margin-top: 1.6rem; }}
.btn {{ display: inline-block; padding: .75rem 1.25rem; border-radius: var(--radius); text-decoration: none; font-weight: 600; border: 1px solid transparent; }}
.btn.primary {{ background: var(--primary); color: var(--on-primary); }}
.btn.primary:hover {{ background: var(--accent); color: var(--on-primary); }}
.btn.ghost {{ border-color: var(--border); color: var(--text); }}
.hero-card img {{ border-radius: var(--radius); border: 1px solid var(--border); }}
.section {{ padding: 3.4rem 0; }}
.section.alt {{ background: var(--surface-alt); }}
.band {{ background: var(--surface-alt); border-block: 1px solid var(--border); padding: 1.6rem 0; }}
.stat-row {{ display: grid; grid-template-columns: repeat(3, 1fr); gap: 1rem; text-align: center; }}
.stat-value {{ display: block; font-size: 1.9rem; font-weight: 700; color: var(--primary); }}
.stat-label {{ color: var(--muted); font-size: .92rem; }}
.grid {{ display: grid; gap: 1.2rem; }}
.cols-2 {{ grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); }}
.cols-3 {{ grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); }}
.cols-4 {{ grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); }}
.card {{ background: color-mix(in srgb, var(--surface-alt) 70%, transparent); border: 1px solid var(--border); border-radius: var(--radius); padding: 1.2rem; }}
.card.subtle {{ background: transparent; }}
.card.price ul {{ margin: .8rem 0 1.2rem; }}
.price-value {{ font-size: 1.7rem; font-weight: 700; color: var(--primary); margin: .2rem 0; }}
.steps {{ list-style: none; padding: 0; display: grid; gap: 1rem; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); }}
.step {{ border-left: 3px solid var(--primary); padding-left: 1rem; }}
.step-no {{ display: inline-grid; place-items: center; width: 1.9rem; height: 1.9rem; border-radius: 50%; background: var(--primary); color: var(--on-primary); font-weight: 700; margin-bottom: .4rem; }}
.quote {{ margin: 0; background: color-mix(in srgb, var(--surface-alt) 60%, transparent); border: 1px solid var(--border); border-radius: var(--radius); padding: 1.1rem; }}
.quote blockquote {{ margin: 0 0 .7rem; font-size: 1.02rem; }}
.quote figcaption {{ font-weight: 600; font-size: .92rem; }}
.faq-item {{ border: 1px solid var(--border); border-radius: var(--radius); padding: .8rem 1rem; margin-bottom: .7rem; background: color-mix(in srgb, var(--surface-alt) 55%, transparent); }}
.faq-item summary {{ cursor: pointer; font-weight: 600; }}
.tile img {{ border-radius: var(--radius); border: 1px solid var(--border); }}
.tile figcaption {{ font-size: .85rem; color: var(--muted); margin-top: .4rem; }}
.table {{ width: 100%; border-collapse: collapse; }}
.table th, .table td {{ text-align: left; padding: .7rem .5rem; border-bottom: 1px solid var(--border); }}
.table th {{ width: 32%; }}
.hours {{ font-size: 1.25rem; font-weight: 600; }}
.cta-band {{ background: linear-gradient(135deg, color-mix(in srgb, var(--primary) 26%, transparent), transparent); border-block: 1px solid var(--border); }}
.cta-inner {{ text-align: center; }}
.contact-grid {{ display: grid; gap: 2rem; grid-template-columns: 1.3fr .7fr; }}
.field {{ margin-bottom: .9rem; display: grid; gap: .3rem; }}
input, textarea {{ font: inherit; padding: .65rem .75rem; border-radius: var(--radius); border: 1px solid var(--border); background: color-mix(in srgb, var(--surface) 80%, #fff 6%); color: var(--text); }}
input[aria-invalid="true"], textarea[aria-invalid="true"] {{ border-color: #e5484d; }}
.hint {{ font-size: .86rem; color: var(--muted); }}
.form-status {{ min-height: 1.4rem; font-weight: 600; }}
.contact-aside {{ border: 1px solid var(--border); border-radius: var(--radius); padding: 1.2rem; align-self: start; }}
.site-footer {{ border-top: 1px solid var(--border); padding: 2.4rem 0 1.2rem; background: var(--surface-alt); }}
.footer-grid {{ display: grid; gap: 1.6rem; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); }}
.footer-heading {{ font-size: 1rem; text-transform: uppercase; letter-spacing: .08em; }}
.footer-base {{ display: flex; justify-content: space-between; gap: 1rem; flex-wrap: wrap; border-top: 1px solid var(--border); margin-top: 1.6rem; padding-top: 1rem; font-size: .88rem; }}
.team img {{ width: 72px; height: 72px; border-radius: 50%; border: 1px solid var(--border); }}
@media (max-width: 820px) {{
  .hero-grid, .contact-grid {{ grid-template-columns: 1fr; }}
  .nav-toggle {{ display: inline-block; }}
  .site-header nav {{ display: none; }}
  .site-header nav.open {{ display: block; position: absolute; inset: 100% 0 auto 0; background: var(--surface); border-bottom: 1px solid var(--border); padding: .8rem 1.25rem; }}
  .site-header nav.open ul {{ flex-direction: column; gap: .5rem; }}
}}
@media (prefers-reduced-motion: reduce) {{ html {{ scroll-behavior: auto; }} }}
"""


def render_js() -> str:
    return """(function () {
  "use strict";
  var toggle = document.querySelector('.nav-toggle');
  var nav = document.getElementById('site-nav');
  if (toggle && nav) {
    toggle.addEventListener('click', function () {
      var open = nav.classList.toggle('open');
      toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
  }
  var year = document.querySelector('[data-year]');
  if (year) { year.textContent = String(new Date().getFullYear()); }

  var form = document.querySelector('.contact-form');
  if (form) {
    var status = form.querySelector('.form-status');
    form.addEventListener('submit', function (event) {
      event.preventDefault();
      var ok = true;
      ['name', 'email', 'message'].forEach(function (id) {
        var field = form.querySelector('#' + id);
        if (!field) { return; }
        var valid = field.value.trim().length > 1;
        if (id === 'email') { valid = /^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$/.test(field.value.trim()); }
        field.setAttribute('aria-invalid', valid ? 'false' : 'true');
        if (!valid) { ok = false; }
      });
      status.textContent = ok
        ? 'Thank you. Your enquiry was validated locally. Connect this form to your mail endpoint or CRM before launch.'
        : 'Please correct the highlighted fields and try again.';
      status.style.color = ok ? 'var(--primary)' : '#e5484d';
    });
  }
})();
"""


def logo_svg(name: str, tokens: dict) -> str:
    initials = "".join(w[0] for w in re.findall(r"\w+", name)[:2]).upper() or "WB"
    return f"""<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 96 96" role="img" aria-label="{_e(name)} logo">
  <rect width="96" height="96" rx="20" fill="{tokens['primary']}"/>
  <text x="48" y="62" font-family="system-ui, sans-serif" font-size="40" font-weight="700"
        text-anchor="middle" fill="#07120a">{_e(initials)}</text>
</svg>"""


def cover_svg(name: str, tagline: str, tokens: dict) -> str:
    return f"""<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 420" role="img" aria-label="{_e(tagline)}">
  <defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1">
    <stop offset="0" stop-color="{tokens['primary']}"/><stop offset="1" stop-color="{tokens['accent']}"/>
  </linearGradient></defs>
  <rect width="640" height="420" rx="18" fill="{tokens['surface_alt']}"/>
  <circle cx="120" cy="330" r="150" fill="url(#g)" opacity="0.35"/>
  <rect x="330" y="70" width="240" height="150" rx="14" fill="url(#g)" opacity="0.55"/>
  <rect x="60" y="60" width="230" height="14" rx="7" fill="{tokens['text']}" opacity="0.85"/>
  <rect x="60" y="92" width="180" height="14" rx="7" fill="{tokens['text']}" opacity="0.55"/>
  <rect x="60" y="124" width="150" height="14" rx="7" fill="{tokens['text']}" opacity="0.35"/>
  <text x="60" y="230" font-family="system-ui, sans-serif" font-size="30" font-weight="700" fill="{tokens['text']}">{_e(name)}</text>
</svg>"""


def tile_svg(index: int, tokens: dict) -> str:
    hues = [tokens["primary"], tokens["accent"], tokens["muted"]]
    color = hues[(index - 1) % len(hues)]
    return f"""<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 260" role="img" aria-label="Placeholder tile {index}">
  <rect width="400" height="260" rx="14" fill="{tokens['surface_alt']}"/>
  <path d="M0 200 L140 90 L260 190 L400 70 L400 260 L0 260 Z" fill="{color}" opacity="0.45"/>
  <circle cx="{60 + index * 20}" cy="70" r="26" fill="{tokens['primary']}" opacity="0.8"/>
</svg>"""


def avatar_svg(index: int, tokens: dict) -> str:
    return f"""<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 72 72" role="img" aria-label="Placeholder portrait">
  <rect width="72" height="72" rx="36" fill="{tokens['surface_alt']}"/>
  <circle cx="36" cy="28" r="13" fill="{tokens['primary']}" opacity="0.85"/>
  <path d="M10 70 q26 -26 52 0" fill="{tokens['primary']}" opacity="0.5"/>
</svg>"""


def robots_txt() -> str:
    return "User-agent: *\nAllow: /\nSitemap: https://example.com/sitemap.xml\n"


def sitemap_xml(blueprint: dict) -> str:
    urls = "".join(
        f"  <url><loc>https://example.com/{'index.html' if p['slug'] == 'index' else p['slug'] + '.html'}</loc>"
        f"<changefreq>monthly</changefreq><priority>{'1.0' if p['slug'] == 'index' else '0.7'}</priority></url>\n"
        for p in blueprint["pages"])
    return ('<?xml version="1.0" encoding="UTF-8"?>\n'
            '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n' + urls + "</urlset>\n")


# ---------------------------------------------------------------------------
# project files
# ---------------------------------------------------------------------------


def build_readme(project: dict, blueprint: dict, content: dict, requirements: dict) -> str:
    pages = "\n".join(f"- `site/{p['file']}` — {p['title']}" for p in blueprint["pages"])
    services = "\n".join(f"- {s['title']}: {s['summary']}" for s in content["services"])
    return f"""# {blueprint['brand_name']}

Generated by the {SITE_GENERATOR_LABEL}.
Project id: `{project['id']}` · Archetype: `{blueprint['archetype']}` · Palette: `{blueprint['palette']}`

## Pages
{pages}

## Offerings used on the site
{services}

## Structure
```
site/            static site root (deployable as-is)
  css/styles.css design tokens + layout
  js/main.js     navigation toggle, form validation, footer year
  assets/        generated SVG logo, cover and placeholder tiles
  sitemap.xml, robots.txt
build.mjs        build: validates pages, minifies CSS/JS into dist/
tests/checks.mjs deterministic page checks (run with the build)
content/         structured content + requirements for future edits
locales/         translation output (created by translation jobs)
```

## Commands
```bash
node build.mjs          # build to dist/ and run the checks
node tests/checks.mjs   # checks only
python3 build.py        # optional alternative build if Node is unavailable
```

## Editing content
Content lives in `content/content.json` (structured) and `content/requirements.json`.
Re-render pages by re-running the platform's website generation task rather than editing
HTML by hand, so the checks stay valid.

## Known limitations
- Contact form validates locally; connect it to an email endpoint or CRM before launch.
- Gallery and team imagery is intentionally placeholder, not stock photography.
- Statistics under "Key figures" are illustrative and must be replaced with real figures
  before publication.
"""


def build_mjs(blueprint: dict) -> str:
    return """// Build: validate pages, then emit a minified dist/ with a manifest.
import { readFileSync, writeFileSync, mkdirSync, readdirSync, statSync } from 'node:fs';
import { join, extname, relative } from 'node:path';
import { createHash } from 'node:crypto';

const root = 'site';
const out = 'dist';
const errors = [];

function walk(dir) {
  return readdirSync(dir).flatMap((entry) => {
    const full = join(dir, entry);
    return statSync(full).isDirectory() ? walk(full) : [full];
  });
}

const minifyCss = (css) => css
  .replace(/\\/\\*[\\s\\S]*?\\*\\//g, '')
  .replace(/\\s*([{}:;,>])\\s*/g, '$1')
  .replace(/;}/g, '}')
  .replace(/\\s+/g, ' ')
  .trim();

const minifyJs = (js) => js
  .replace(/^\\s*\\/\\/.*$/gm, '')
  .replace(/\\/\\*[\\s\\S]*?\\*\\//g, '')
  .replace(/\\n\\s+/g, '\\n')
  .trim();

mkdirSync(out, { recursive: true });
const manifest = { pages: [], assets: [], builtAt: new Date().toISOString() };
let totalBytes = 0;

for (const file of walk(root)) {
  const rel = relative(root, file);
  const ext = extname(file);
  let body = readFileSync(file);
  let outPath = join(out, rel);

  if (ext === '.html') {
    const text = body.toString('utf8');
    if (!/<html[\\s>]/i.test(text)) errors.push(`${rel}: missing <html> element`);
    if (!/<title>[^<]{4,}<\\/title>/i.test(text)) errors.push(`${rel}: missing or too-short <title>`);
    if (!/name="description"\\s+content="[^"]{20,}"/i.test(text)) errors.push(`${rel}: meta description missing or short`);
    if (!/<h1[\\s>]/i.test(text)) errors.push(`${rel}: missing <h1>`);
    if (/lorem ipsum/i.test(text)) errors.push(`${rel}: contains placeholder lorem ipsum`);
    const lang = (text.match(/<html[^>]*lang="([^"]+)"/i) || [])[1];
    if (!lang) errors.push(`${rel}: <html> has no lang attribute`);
    const imgs = text.match(/<img\\b[^>]*>/gi) || [];
    for (const img of imgs) {
      if (!/\\balt=/.test(img)) errors.push(`${rel}: <img> without alt attribute -> ${img.slice(0, 60)}`);
      if (!/\\bwidth=|\\bheight=/.test(img)) errors.push(`${rel}: <img> without explicit dimensions -> ${img.slice(0, 60)}`);
    }
    if (/\\son(click|load|error|mouseover|submit)=/i.test(text)) errors.push(`${rel}: inline event handler found`);
    body = Buffer.from(text.replace(/\\n\\s*\\n/g, '\\n'));
    manifest.pages.push({ file: rel, bytes: body.length, sha256: createHash('sha256').update(body).digest('hex') });
  } else if (ext === '.css') {
    body = Buffer.from(minifyCss(body.toString('utf8')));
    manifest.assets.push({ file: rel, bytes: body.length, minified: true });
  } else if (ext === '.js') {
    body = Buffer.from(minifyJs(body.toString('utf8')));
    manifest.assets.push({ file: rel, bytes: body.length, minified: true });
  } else {
    manifest.assets.push({ file: rel, bytes: body.length, minified: false });
  }

  totalBytes += body.length;
  mkdirSync(join(out, rel.split('/').slice(0, -1).join('/') || '.'), { recursive: true });
  writeFileSync(outPath, body);
}

manifest.totalBytes = totalBytes;

if (errors.length) {
  console.error(`BUILD FAILED with ${errors.length} problem(s):`);
  for (const e of errors) console.error(' - ' + e);
  process.exitCode = 1;
} else {
  writeFileSync(join(out, 'manifest.json'), JSON.stringify(manifest, null, 2));
  console.log(`BUILD OK: ${manifest.pages.length} pages, ${manifest.assets.length} assets, ${totalBytes} bytes -> dist/`);
}
"""


def checks_mjs() -> str:
    return """// Deterministic page checks: internal links, duplicate ids, headings, forms.
import { readFileSync, readdirSync } from 'node:fs';
import { join } from 'node:path';

const root = 'site';
let failures = 0;
const note = (ok, message) => { console.log((ok ? 'PASS ' : 'FAIL ') + message); if (!ok) failures++; };

const pages = readdirSync(root).filter((f) => f.endsWith('.html'));
const html = Object.fromEntries(pages.map((f) => [f, readFileSync(join(root, f), 'utf8')]));

note(pages.length >= 3, `at least 3 pages generated (found ${pages.length})`);

for (const [file, text] of Object.entries(html)) {
  const ids = [...text.matchAll(/\\sid="([^"]+)"/g)].map((m) => m[1]);
  const dupes = ids.filter((id, i) => ids.indexOf(id) !== i);
  note(dupes.length === 0, `${file}: no duplicate ids${dupes.length ? ' -> ' + dupes.join(', ') : ''}`);

  const anchors = [...text.matchAll(/href="([^"#][^"]*?)"/g)].map((m) => m[1]).filter((h) => !/^(https?:|mailto:|tel:)/.test(h));
  const missing = anchors.filter((h) => !pages.includes(h.split('#')[0]));
  note(missing.length === 0, `${file}: all internal links resolve${missing.length ? ' -> ' + missing.join(', ') : ''}`);

  const labels = [...text.matchAll(/<label\\s+for="([^"]+)"/g)].map((m) => m[1]);
  note(labels.length > 0, `${file}: form labels present where forms exist`.replace('form labels present where forms exist', labels.length ? 'label/for pairs present' : 'no forms on this page (labels not required)'));
}

for (const [file, text] of Object.entries(html)) {
  const required = ['name="viewport"', 'charset="utf-8"', 'og:title', 'application/ld+json'];
  for (const token of required) {
    note(text.includes(token), `${file}: contains ${token}`);
  }
  break; // structural requirements checked on the entry page; per-page in build.mjs
}

console.log(failures === 0 ? 'CHECKS PASSED' : `CHECKS FAILED (${failures})`);
process.exitCode = failures === 0 ? 0 : 1;
"""


def build_py() -> str:
    return '''"""Optional pure-Python build (mirrors build.mjs) for environments without Node."""
import hashlib, json, re, shutil
from pathlib import Path

root, out = Path("site"), Path("dist")
errors, manifest = [], {"pages": [], "assets": []}
if out.exists():
    shutil.rmtree(out)

for path in sorted(root.rglob("*")):
    if path.is_dir():
        continue
    rel = path.relative_to(root).as_posix()
    target = out / rel
    target.parent.mkdir(parents=True, exist_ok=True)
    if path.suffix == ".html":
        text = path.read_text(encoding="utf-8")
        if not re.search(r"<title>[^<]{4,}</title>", text):
            errors.append(f"{rel}: missing title")
        if not re.search(r'name="description"\\s+content="[^"]{20,}"', text):
            errors.append(f"{rel}: meta description missing")
        if not re.search(r"<h1[\\s>]", text):
            errors.append(f"{rel}: missing h1")
        body = re.sub(r"\\n\\s*\\n", "\\n", text).encode()
        manifest["pages"].append({"file": rel, "bytes": len(body), "sha256": hashlib.sha256(body).hexdigest()})
    else:
        body = path.read_bytes()
        manifest["assets"].append({"file": rel, "bytes": len(body)})
    target.write_bytes(body)

if errors:
    print("BUILD FAILED:")
    for e in errors:
        print(" -", e)
    raise SystemExit(1)
(out / "manifest.json").write_text(json.dumps(manifest, indent=2))
print(f"BUILD OK: {len(manifest['pages'])} pages, {len(manifest['assets'])} assets -> dist/")
'''


# ---------------------------------------------------------------------------
# top-level generation
# ---------------------------------------------------------------------------


def generate_project_files(project: dict, root: Path, requirements: dict | None = None,
                           research: dict | None = None) -> dict:
    """Write a complete website project into `root`. Returns a file manifest."""
    requirements = requirements or util.jload(project.get("requirements_json"), {})
    blueprint = build_blueprint(project)
    content = author_content(project, blueprint, requirements)
    tokens = blueprint["tokens"]
    tokens["fonts"] = blueprint["fonts"]

    written: list[dict] = []

    def write(rel: str, text: str | bytes) -> None:
        path = util.safe_join(root, rel)
        path.parent.mkdir(parents=True, exist_ok=True)
        data = text.encode("utf-8") if isinstance(text, str) else text
        path.write_bytes(data)
        written.append({"path": rel, "bytes": len(data), "sha256": util.sha256_bytes(data)})

    site = "site"
    for page in blueprint["pages"]:
        html_text = render_page(page, blueprint, content)
        write(f"{site}/{page['file']}", html_text)
    write(f"{site}/css/styles.css", render_css(tokens))
    write(f"{site}/js/main.js", render_js())
    write(f"{site}/assets/logo.svg", logo_svg(blueprint["brand_name"], tokens))
    write(f"{site}/assets/og-cover.svg", cover_svg(blueprint["brand_name"], blueprint["tagline"], tokens))
    for i in range(1, 7):
        write(f"{site}/assets/tile-{i}.svg", tile_svg(i, tokens))
    for i in range(1, 4):
        write(f"{site}/assets/avatar-{i}.svg", avatar_svg(i, tokens))
    write(f"{site}/robots.txt", robots_txt())
    write(f"{site}/sitemap.xml", sitemap_xml(blueprint))
    write("build.mjs", build_mjs(blueprint))
    write("tests/checks.mjs", checks_mjs())
    write("build.py", build_py())
    write("README.md", build_readme(project, blueprint, content, requirements))
    write("content/content.json", util.jdump(content))
    write("content/requirements.json", util.jdump(requirements or {}))
    write("content/blueprint.json", util.jdump(blueprint))
    if research:
        write("content/stack.json", util.jdump(research))

    return {"blueprint": blueprint, "content": content, "files": written,
            "file_count": len(written),
            "total_bytes": sum(f["bytes"] for f in written)}
