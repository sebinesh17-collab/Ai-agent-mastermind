"""Multi-agent orchestration engine.

Real workflow engine: dependency graphs, parallel execution, persisted
checkpoints (the tasks table is the checkpoint store), bounded retries, model
routing decisions per task, agent execution records, artifacts, cancellation
and human-approval gates.
"""
from __future__ import annotations

import threading
import traceback
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

from . import db, engines, generation, models, registry, util, verify

RUNNERS: dict[str, "RunState"] = {}
_VERSION_LOCK = threading.Lock()

# Only genuinely high-impact tasks pause for explicit user approval. Task-level
# gating is checked in addition to the agent's declared approval policy.
APPROVAL_TASK_KEYS = {"deploy_execute", "publish", "rollback"}
_LOCK = threading.Lock()

# capability used for model routing per task key
TASK_CAPABILITY = {
    "intake": "Requirements engineering", "plan": "Complex planning", "research": "Technical research",
    "resources": "Technical research", "licensing": "Classification", "architecture": "Architecture analysis",
    "design": "UI/UX reasoning", "generate": "Code generation", "build": "Testing assistance",
    "verify": "Testing assistance", "seo_perf": "Marketing text", "security": "Security analysis",
    "repair": "Debugging", "acceptance": "Complex planning", "docs": "Documentation",
    "export": "Documentation", "deploy_prep": "Documentation", "enrich": "Marketing text",
    "translate": "Translation", "feedback_triage": "Classification", "monitor": "Debugging",
    "deploy_execute": "Documentation", "clarify": "Documentation", "improve": "Code generation",
    "marketing": "Marketing text", "media": "Media processing assistance",
}


class RunState:
    def __init__(self, run_id: str):
        self.run_id = run_id
        self.cancel = threading.Event()
        self.thread: threading.Thread | None = None


# ---------------------------------------------------------------------------
# task graph definitions
# ---------------------------------------------------------------------------


def graph_for(kind: str, payload: dict) -> list[dict]:
    if kind == "full_build":
        return [
            {"key": "intake", "name": "Project intake and requirements extraction", "dept": "intake"},
            {"key": "plan", "name": "Planning and task decomposition", "dept": "planning", "deps": ["intake"]},
            {"key": "research", "name": "Technical research and stack selection", "dept": "research", "deps": ["plan"]},
            {"key": "resources", "name": "Open-source resource discovery", "dept": "oss", "deps": ["plan"]},
            {"key": "licensing", "name": "Licence verification and attribution", "dept": "licensing", "deps": ["resources"]},
            {"key": "architecture", "name": "Architecture and data contracts", "dept": "architecture", "deps": ["research"]},
            {"key": "design", "name": "UX, design system and content model", "dept": "design", "deps": ["architecture"]},
            {"key": "generate", "name": "Website generation and workspace write", "dept": "frontend", "deps": ["design", "licensing"]},
            {"key": "enrich", "name": "Model-assisted copy refinement", "dept": "content", "deps": ["generate"], "optional": True},
            {"key": "build", "name": "Build execution", "dept": "devops", "deps": ["enrich"]},
            {"key": "verify", "name": "Application and accessibility verification", "dept": "qa", "deps": ["build"]},
            {"key": "seo_perf", "name": "SEO and performance review", "dept": "seo", "deps": ["build"]},
            {"key": "security", "name": "Security review", "dept": "security", "deps": ["build"]},
            {"key": "repair", "name": "Debugging and repair of failed checks", "dept": "debugging",
             "deps": ["verify", "seo_perf", "security"]},
            {"key": "acceptance", "name": "Acceptance verification and quality gate", "dept": "qa", "deps": ["repair"]},
            {"key": "docs", "name": "Documentation and attribution files", "dept": "content", "deps": ["acceptance"]},
            {"key": "export", "name": "Export package and deployment preparation", "dept": "devops", "deps": ["docs"]},
        ]
    if kind == "feedback_improvement":
        return [
            {"key": "feedback_triage", "name": "Feedback classification and impact analysis", "dept": "intake"},
            {"key": "plan", "name": "Improvement task planning", "dept": "planning", "deps": ["feedback_triage"]},
            {"key": "improve", "name": "Apply bounded improvement to the website", "dept": "frontend", "deps": ["plan"]},
            {"key": "build", "name": "Build execution", "dept": "devops", "deps": ["improve"]},
            {"key": "verify", "name": "Verification of the improved version", "dept": "qa", "deps": ["build"]},
            {"key": "acceptance", "name": "Acceptance and release note update", "dept": "qa", "deps": ["verify"]},
        ]
    if kind == "maintenance":
        return [
            {"key": "monitor", "name": "Run configured health and integrity monitors", "dept": "maintenance"},
            {"key": "repair", "name": "Repair planning for detected incidents", "dept": "debugging", "deps": ["monitor"]},
            {"key": "acceptance", "name": "Maintenance verification and reporting", "dept": "qa", "deps": ["repair"]},
        ]
    if kind == "translation":
        return [{"key": "translate", "name": "Localization job for requested locales", "dept": "marketing",
                 "dept_override": "translation_ext"}]
    if kind == "marketing":
        return [{"key": "marketing", "name": "Marketing artifact production", "dept": "marketing"}]
    if kind == "media":
        return [{"key": "media", "name": "Video storyboard and render preparation", "dept": "media"}]
    if kind == "clarification":
        return [{"key": "clarify", "name": "Clarification questions to the project owner", "dept": "email"}]
    if kind == "export":
        return [{"key": "export", "name": "Export and deployment preparation", "dept": "devops"}]
    if kind == "deploy":
        return [
            {"key": "export", "name": "Build the deployment package", "dept": "devops"},
            {"key": "deploy_execute", "name": "Execute deployment to the configured target", "dept": "devops",
             "deps": ["export"]},
        ]
    return [{"key": "intake", "name": "Custom task intake", "dept": "intake"}]


def start_run(project, kind: str = "full_build", payload: dict | None = None, async_run: bool = True) -> dict:
    project_id = project["id"] if hasattr(project, "__getitem__") else str(project)
    row = db.query_one("SELECT * FROM projects WHERE id=?", (project_id,))
    if row is None:
        return {"ok": False, "detail": "project not found"}
    payload = payload or {}
    run_id = util.new_id("run_")
    tasks = graph_for(kind, payload)
    db.insert("runs", {"id": run_id, "project_id": project_id, "kind": kind, "status": "queued",
                       "request_json": util.jdump(payload), "summary_json": "{}",
                       "error": "", "started_at": util.now_iso(), "finished_at": None,
                       "cancel_requested": 0})
    for i, task in enumerate(tasks):
        agent = None
        dept_key = task.get("dept_override", task["dept"])
        if dept_key.endswith("_ext"):
            agent = registry.resolve_extension(dept_key[:-4], task["name"])
        else:
            agent = registry.resolve_by_department(dept_key, task["name"])
        db.insert("tasks", {
            "id": f"{run_id}-T{i:02d}", "run_id": run_id, "project_id": project_id, "seq": i,
            "name": task["name"], "department": task.get("dept", dept_key), "agent_id": agent["id"] if agent else "",
            "status": "pending", "depends_on_json": util.jdump(task.get("deps", [])),
            "input_json": util.jdump({}), "output_json": "{}", "artifacts_json": "[]",
            "model_id": "", "model_reason": "", "attempts": 0, "started_at": None, "finished_at": None,
            "duration_ms": None, "error": "", "human_approval_required": 0, "approved_at": None,
        })
    db.audit("orchestrator", "run_started", run_id, {"kind": kind, "tasks": len(tasks), "payload_keys": list(payload)})
    if async_run:
        state = RunState(run_id)
        RUNNERS[run_id] = state
        state.thread = threading.Thread(target=_execute_run, args=(run_id,), daemon=True, name=f"run-{run_id}")
        state.thread.start()
    return {"ok": True, "run_id": run_id, "kind": kind, "tasks": len(tasks)}


# ---------------------------------------------------------------------------
# execution
# ---------------------------------------------------------------------------


def _execute_run(run_id: str) -> None:
    db.execute("UPDATE runs SET status='running' WHERE id=?", (run_id,))
    state = RUNNERS.get(run_id)
    try:
        for _round in range(60):  # bounded loop, never infinite
            if state and state.cancel.is_set():
                db.execute("UPDATE runs SET status='cancelled', finished_at=? WHERE id=?", (util.now_iso(), run_id))
                db.log_task("", run_id, "warning", "run cancelled by user request")
                return
            run = db.query_one("SELECT * FROM runs WHERE id=?", (run_id,))
            if run["cancel_requested"]:
                db.execute("UPDATE runs SET status='cancelled', finished_at=? WHERE id=?", (util.now_iso(), run_id))
                return
            tasks = [dict(t) for t in db.query("SELECT * FROM tasks WHERE run_id=? ORDER BY seq", (run_id,))]
            done = {t["id"].split("-T")[-1].zfill(2): t["status"] for t in tasks}
            by_index = {t["id"].split("-T")[-1].zfill(2): t for t in tasks}
            # map dependency keys to task indexes
            graph = graph_for(run["kind"], util.jload(run["request_json"], {}))
            key_to_index = {g["key"]: f"{i:02d}" for i, g in enumerate(graph)}

            ready = []
            for idx, task in by_index.items():
                if task["status"] != "pending":
                    continue
                deps = util.jload(task["depends_on_json"], [])
                graph_entry = graph[int(idx)]
                dep_indexes = [key_to_index[d] for d in deps if d in key_to_index]
                dep_states = [done.get(di, "pending") for di in dep_indexes]
                if any(s == "failed" for s in dep_states):
                    # a dependency failed: block only this branch, never the whole run
                    failed_dep = dep_indexes[dep_states.index("failed")]
                    db.execute("UPDATE tasks SET status='skipped_blocked', error=?, finished_at=? WHERE id=?",
                               (f"upstream task {failed_dep} failed; this task cannot run. "
                                "Independent branches continue and successful results are preserved.",
                                util.now_iso(), task["id"]))
                    db.log_task(task["id"], run_id, "warning",
                                "blocked by failed dependency; other branches continue")
                    continue
                # a blocked (not failed) upstream does not deadlock the graph: the downstream task is
                # allowed to run and reports the reduced input it received; the block is recorded in the ledger.
                if all(s in {"done", "skipped", "skipped_blocked", "failed_optional"} for s in dep_states):
                    if any(s == "skipped_blocked" for s in dep_states):
                        db.log_task(task["id"], run_id, "warning",
                                    "continuing with a blocked upstream task; some input may be missing")
                    ready.append(task)

            if not ready:
                if any(t["status"] == "awaiting_approval" for t in tasks):
                    db.execute("UPDATE runs SET status='awaiting_approval' WHERE id=?", (run_id,))
                    return
                break

            settings = db.get_settings()
            limit = max(1, min(int(settings.get("max_parallel_tasks", "4") or 4), 6))
            batch = ready[:limit]
            with ThreadPoolExecutor(max_workers=limit, thread_name_prefix="agent") as pool:
                futures = {pool.submit(_run_task, run_id, task): task for task in batch}
                for fut in as_completed(futures):
                    task = futures[fut]
                    try:
                        fut.result()
                    except Exception as exc:  # never let one task kill the run
                        db.execute("UPDATE tasks SET status='failed', error=?, finished_at=? WHERE id=?",
                                   (f"{type(exc).__name__}: {exc}", util.now_iso(), task["id"]))
                        db.log_task(task["id"], run_id, "error", traceback.format_exc()[-1500:])

        # finalise
        tasks = [dict(t) for t in db.query("SELECT * FROM tasks WHERE run_id=? ORDER BY seq", (run_id,))]
        if any(t["status"] == "awaiting_approval" for t in tasks):
            db.execute("UPDATE runs SET status='awaiting_approval' WHERE id=?", (run_id,))
            return
        failed = [t for t in tasks if t["status"] == "failed"]
        skipped = [t for t in tasks if t["status"] == "skipped_blocked"]
        status = "failed" if failed else "succeeded_with_warnings" if skipped else "succeeded"
        summary = {
            "tasks": len(tasks), "succeeded": sum(1 for t in tasks if t["status"] == "done"),
            "failed": len(failed), "skipped": len(skipped),
            "failed_tasks": [{"task": t["name"], "error": util.truncate(t["error"], 200)} for t in failed],
            "skipped_tasks": [{"task": t["name"], "reason": util.truncate(t["error"], 200)} for t in skipped],
        }
        db.execute("UPDATE runs SET status=?, summary_json=?, finished_at=? WHERE id=?",
                   (status, util.jdump(summary), util.now_iso(), run_id))
        _finalise_run(run_id, status, summary)
        db.audit("orchestrator", "run_finished", run_id, summary)
    except Exception as exc:
        db.execute("UPDATE runs SET status='failed', error=?, finished_at=? WHERE id=?",
                   (f"{type(exc).__name__}: {exc}", util.now_iso(), run_id))
        db.log_task("", run_id, "error", traceback.format_exc()[-2000:])
    finally:
        RUNNERS.pop(run_id, None)


def _run_task(run_id: str, task: dict) -> None:
    task_id = task["id"]
    run = db.query_one("SELECT * FROM runs WHERE id=?", (run_id,))
    project = db.query_one("SELECT * FROM projects WHERE id=?", (task["project_id"],))
    if project is None:
        db.execute("UPDATE tasks SET status='failed', error='project missing' WHERE id=?", (task_id,))
        return
    project = dict(project)

    # approval gate
    capability = TASK_CAPABILITY.get(task_key(run_id, task), "Classification")
    agent = db.query_one("SELECT * FROM agents WHERE id=?", (task["agent_id"],)) if task["agent_id"] else None
    approval_needed = (task_key(run_id, task) in APPROVAL_TASK_KEYS) or bool(
        agent and agent["human_approval"] == "requires_human_approval"
        and task_key(run_id, task) in {"deploy_execute", "publish"})
    if approval_needed and task["status"] == "pending" and not task["approved_at"]:
        db.execute("UPDATE tasks SET status='awaiting_approval', human_approval_required=1 WHERE id=?", (task_id,))
        db.log_task(task_id, run_id, "info",
                    f"task paused for human approval (agent {agent['name']} requires approval before executing)")
        return

    attempts = 0
    max_attempts = 2
    started = util.now_ms()
    db.execute("UPDATE tasks SET status='running', started_at=?, attempts=? WHERE id=?",
               (util.now_iso(), attempts, task_id))
    db.log_task(task_id, run_id, "info",
                f"agent={agent['name'] if agent else 'unassigned'} capability={capability}")

    while attempts < max_attempts:
        attempts += 1
        try:
            decision = models.route(capability, run_id=run_id, task_id=task_id,
                                    agent_id=task["agent_id"], settings=db.get_settings())
            if agent:
                prefer = util.jload(agent["eligible_models_json"], [])
                if prefer:
                    decision = models.route(capability, run_id=run_id, task_id=task_id,
                                            agent_id=task["agent_id"], prefer=prefer)
            db.execute("UPDATE tasks SET model_id=?, model_reason=?, attempts=? WHERE id=?",
                       (decision.get("chosen_model") or "", decision["reason"], attempts, task_id))
            db.log_task(task_id, run_id, "info",
                        f"routing: {decision.get('chosen_model')} — {decision['reason']} "
                        f"(live_inference_available={decision['live_inference_available']})")
            result = dispatch(run_id, task, project, capability, decision)
            status = result.pop("status", "done")
            artifacts = result.pop("artifacts", [])
            evidence = result.pop("evidence", [])
            db.execute("UPDATE tasks SET status=?, output_json=?, artifacts_json=?, finished_at=?, duration_ms=? WHERE id=?",
                       (status, util.jdump({k: v for k, v in result.items() if k != "big"}),
                        util.jdump(artifacts), util.now_iso(), util.now_ms() - started, task_id))
            for line in evidence[:25]:
                db.log_task(task_id, run_id, "info", str(line))
            _record_artifacts(project["id"], run_id, task_id, artifacts)
            if agent:
                db.insert("agent_runs", {
                    "agent_id": agent["id"], "run_id": run_id, "task_id": task_id, "status": status,
                    "model_id": decision.get("chosen_model") or "", "started_at": util.now_iso(),
                    "finished_at": util.now_iso(), "duration_ms": util.now_ms() - started,
                    "result_summary": util.truncate(util.jdump(result.get("summary", "")), 500), "error": "",
                })
            db.log_task(task_id, run_id, "info", f"completed with status={status}")
            return
        except Exception as exc:
            detail = f"{type(exc).__name__}: {exc}"
            db.log_task(task_id, run_id, "error", f"attempt {attempts} failed: {detail}\n{traceback.format_exc()[-800:]}")
            if attempts >= max_attempts:
                db.execute("UPDATE tasks SET status='failed', error=?, finished_at=?, duration_ms=? WHERE id=?",
                           (util.truncate(detail, 500), util.now_iso(), util.now_ms() - started, task_id))
                if agent:
                    db.insert("agent_runs", {
                        "agent_id": agent["id"], "run_id": run_id, "task_id": task_id, "status": "failed",
                        "model_id": "", "started_at": util.now_iso(), "finished_at": util.now_iso(),
                        "duration_ms": util.now_ms() - started, "result_summary": "", "error": util.truncate(detail, 500)})
                return


def task_key(run_id: str, task: dict) -> str:
    run = db.query_one("SELECT kind, request_json FROM runs WHERE id=?", (run_id,))
    graph = graph_for(run["kind"], util.jload(run["request_json"], {}))
    idx = int(task["id"].split("-T")[-1])
    return graph[idx]["key"] if idx < len(graph) else "intake"


def _record_artifacts(project_id: str, run_id: str, task_id: str, artifacts: list[dict]) -> None:
    for art in artifacts:
        if not isinstance(art, dict):
            continue
        path = art.get("path", "")
        db.insert("artifacts", {
            "id": util.new_id("art_"), "project_id": project_id, "run_id": run_id, "task_id": task_id,
            "kind": art.get("kind", "file"), "label": art.get("label", path),
            "path": path, "bytes": art.get("bytes", 0), "sha256": art.get("sha256", ""),
            "created_at": util.now_iso(),
        })


def _finalise_run(run_id: str, status: str, summary: dict) -> None:
    run = db.query_one("SELECT * FROM runs WHERE id=?", (run_id,))
    project_id = run["project_id"]
    if run["kind"] == "full_build" and status.startswith("succeeded"):
        db.execute("UPDATE projects SET status='delivered' WHERE id=?", (project_id,))
    elif run["kind"] == "feedback_improvement" and status.startswith("succeeded"):
        db.execute("UPDATE projects SET status='improved' WHERE id=?", (project_id,))


# ---------------------------------------------------------------------------
# task dispatch — real work per task key
# ---------------------------------------------------------------------------


def dispatch(run_id: str, task: dict, project: dict, capability: str, decision: dict) -> dict:
    key = task_key(run_id, task)
    run = db.query_one("SELECT * FROM runs WHERE id=?", (run_id,))
    payload = util.jload(run["request_json"], {})
    handler = HANDLERS.get(key)
    if handler is None:
        return {"status": "done", "summary": f"no handler registered for '{key}'", "artifacts": [], "evidence": []}
    return handler(run_id, task, project, payload, decision)


def _version_root(project_id: str, create: bool = False, label: str = "", notes: str = "",
                  run_id: str = "") -> Path:
    """Resolve the working version for a task.

    A version is created once per run (or once per project when no run id is
    given); creation is serialised so parallel tasks cannot each spawn their own
    version, which would break rollback ordering.
    """
    if run_id:
        row = db.query_one(
            "SELECT * FROM project_versions WHERE project_id=? AND notes LIKE ? ORDER BY version DESC LIMIT 1",
            (project_id, f"%run {run_id}%"))
        if row:
            return Path(row["root"])
    latest = db.query_one("SELECT * FROM project_versions WHERE project_id=? ORDER BY version DESC LIMIT 1",
                          (project_id,))
    if latest and not create:
        return Path(latest["root"])
    with _VERSION_LOCK:
        if run_id:
            row = db.query_one(
                "SELECT * FROM project_versions WHERE project_id=? AND notes LIKE ? ORDER BY version DESC LIMIT 1",
                (project_id, f"%run {run_id}%"))
            if row:
                return Path(row["root"])
        latest = db.query_one("SELECT * FROM project_versions WHERE project_id=? ORDER BY version DESC LIMIT 1",
                              (project_id,))
        version = (latest["version"] + 1) if latest else 1
        root = util.PROJECTS_DIR / project_id / f"v{version}"
        root.mkdir(parents=True, exist_ok=True)
        note_text = (notes + " " if notes else "") + (f"(run {run_id})" if run_id else "")
        db.insert("project_versions", {
            "project_id": project_id, "version": version, "label": label or f"v{version}",
            "notes": note_text.strip(), "root": str(root), "manifest_json": "{}", "tests_json": "{}",
            "created_at": util.now_iso(),
        })
        db.execute("UPDATE projects SET active_version=?, updated_at=? WHERE id=?",
                   (version, util.now_iso(), project_id))
        db.audit("orchestrator", "version_created", f"{project_id}:v{version}",
                 {"label": label, "run_id": run_id})
        return root


def _snapshot_new_version(project_id: str, label: str, notes: str = "", run_id: str = "") -> Path:
    """Create the next version by copying the current one, so improvements are
    reversible and the previous version remains on disk for rollback."""
    import shutil as _shutil
    row = db.query_one("SELECT * FROM project_versions WHERE project_id=? ORDER BY version DESC LIMIT 1", (project_id,))
    if row is None:
        return _version_root(project_id, create=True, label=label, notes=notes, run_id=run_id)
    version = row["version"] + 1
    root = util.PROJECTS_DIR / project_id / f"v{version}"
    _shutil.copytree(row["root"], root, dirs_exist_ok=True)
    db.insert("project_versions", {
        "project_id": project_id, "version": version, "label": label, "notes": notes,
        "root": str(root), "manifest_json": row["manifest_json"], "tests_json": "{}",
        "created_at": util.now_iso(),
    })
    db.execute("UPDATE projects SET active_version=?, updated_at=? WHERE id=?",
               (version, util.now_iso(), project_id))
    db.audit("orchestrator", "version_created", f"{project_id}:v{version}", {"label": label, "from": row["version"]})
    return root


def _latest_report(project_id: str) -> dict:
    row = db.query_one(
        "SELECT * FROM artifacts WHERE project_id=? AND kind='verification_report' ORDER BY created_at DESC LIMIT 1",
        (project_id,))
    if row is None:
        return {}
    path = Path(row["path"])
    if not path.exists():
        return {}
    return util.jload(path.read_text(encoding="utf-8"), {})


# --- handlers ---------------------------------------------------------------


def h_intake(run_id, task, project, payload, decision):
    result = engines.intake(project)
    db.execute("UPDATE projects SET brief_json=?, requirements_json=?, ptype=?, industry=?, status='planned' WHERE id=?",
               (util.jdump(result["brief"]), util.jdump(result["requirements"]),
                result["brief"]["archetype"], result["brief"]["archetype_label"], project["id"]))
    open_q = result["brief"]["open_questions"]
    return {"status": "done", "summary": result["summary"], "brief": result["brief"],
            "requirements": result["requirements"], "evidence": result["evidence"],
            "open_questions": open_q, "artifacts": [
                {"kind": "brief", "label": "project brief", "path": "content/brief.json",
                 "bytes": len(util.jdump(result["brief"]))}]}


def h_plan(run_id, task, project, payload, decision):
    requirements = util.jload(project.get("requirements_json"), {})
    result = engines.plan(project, requirements)
    db.execute("UPDATE projects SET plan_json=? WHERE id=?", (util.jdump(result), project["id"]))
    return {"status": "done", "summary": f"{len(result['tasks'])} tasks planned; {len(result['excluded_departments'])} departments excluded as unnecessary.",
            "plan": result,
            "evidence": [f"critical_path={' → '.join(result['critical_path'])}",
                         f"excluded={', '.join(result['excluded_departments'])}"], "artifacts": []}


def h_research(run_id, task, project, payload, decision):
    requirements = util.jload(project.get("requirements_json"), {})
    result = engines.research(project, requirements)
    db.execute("UPDATE projects SET research_json=?, stack_json=? WHERE id=?",
               (util.jdump(result), util.jdump(result["stack"]), project["id"]))
    return {"status": "done", "summary": result["summary"], "research": result,
            "evidence": [f"recommendation={result['recommendation']}",
                         f"alternatives_rejected={len(result['alternatives_considered'])}"], "artifacts": []}


def h_resources(run_id, task, project, payload, decision):
    research_result = util.jload(project.get("research_json"), {})
    result = engines.resource_discovery(project, research_result)
    db.execute("UPDATE projects SET resources_json=? WHERE id=?", (util.jdump(result), project["id"]))
    return {"status": "done", "summary": result["summary"], "used": [r["name"] for r in result["used"]],
            "evidence": [f"recorded={len(result['records'])} resources in the register"], "artifacts": []}


def h_licensing(run_id, task, project, payload, decision):
    resources = util.jload(project.get("resources_json"), {})
    used = resources.get("used", [])
    root = _version_root(project["id"], create=True, label="generated version",
                         notes="generated by the orchestration run", run_id=run_id)
    notice = engines.generation_attribution(used)
    path = root / "NOTICE.md"
    path.write_text(notice, encoding="utf-8")
    unlicensed = [r["name"] for r in used if not r.get("license_verified")]
    return {"status": "done",
            "summary": f"Attribution notice written for {len(used)} adopted resources; {len(unlicensed)} unverified licences flagged.",
            "evidence": [f"NOTICE.md bytes={path.stat().st_size}"], "unverified": unlicensed,
            "artifacts": [{"kind": "license_notice", "label": "third-party notices", "path": "NOTICE.md",
                           "bytes": path.stat().st_size, "sha256": util.sha256_file(path)}]}


def h_architecture(run_id, task, project, payload, decision):
    requirements = util.jload(project.get("requirements_json"), {})
    research_result = util.jload(project.get("research_json"), {})
    result = engines.architecture(project, research_result, requirements)
    root = _version_root(project["id"], create=True, label="generated version",
                         notes="generated by the orchestration run", run_id=run_id)
    (root / "content" / "architecture.json").parent.mkdir(parents=True, exist_ok=True)
    (root / "content" / "architecture.json").write_text(util.jdump(result), encoding="utf-8")
    db.execute("UPDATE projects SET arch_json=? WHERE id=?", (util.jdump(result), project["id"]))
    return {"status": "done", "summary": result["summary"], "evidence": [f"{len(result['components'])} components defined"],
            "artifacts": [{"kind": "architecture_spec", "label": "architecture", "path": "content/architecture.json",
                           "bytes": (root / "content" / "architecture.json").stat().st_size}]}


def h_design(run_id, task, project, payload, decision):
    blueprint = generation.build_blueprint(project)
    result = engines.design(project, blueprint)
    db.execute("UPDATE projects SET design_json=?, blueprint_json=? WHERE id=?",
               (util.jdump(result), util.jdump(blueprint), project["id"]))
    failed_contrast = [c for c in result["contrast_report"] if not c["wcag_aa_normal_text"]]
    return {"status": "done",
            "summary": f"Design system ready; {len(result['contrast_report'])} contrast pairs measured, "
                       f"{len(failed_contrast)} below 4.5:1 for normal text.",
            "contrast": result["contrast_report"], "pages": blueprint["pages"],
            "evidence": [f"{c['pair']}={c['ratio']}:1" for c in result["contrast_report"]], "artifacts": []}


def h_generate(run_id, task, project, payload, decision):
    root = _version_root(project["id"], create=True, label="generated version",
                         notes="generated by the orchestration run", run_id=run_id)
    requirements = util.jload(project.get("requirements_json"), {})
    research_result = util.jload(project.get("research_json"), {})
    result = generation.generate_project_files(project, root, requirements, research_result)
    db.execute("UPDATE project_versions SET manifest_json=? WHERE project_id=? AND version=?",
               (util.jdump({"files": result["files"], "file_count": result["file_count"],
                            "total_bytes": result["total_bytes"]}),
                project["id"], db.query_one("SELECT version FROM project_versions WHERE project_id=? ORDER BY version DESC LIMIT 1", (project["id"],))["version"]))
    db.execute("UPDATE projects SET blueprint_json=? WHERE id=?", (util.jdump(result["blueprint"]), project["id"]))
    artifacts = [{"kind": "project_version", "label": f["path"], "path": f["path"],
                  "bytes": f["bytes"], "sha256": f["sha256"]} for f in result["files"]]
    return {"status": "done",
            "summary": f"{result['file_count']} files generated ({result['total_bytes']} bytes) for "
                       f"{len(result['blueprint']['pages'])} pages.",
            "generated_files": [f["path"] for f in result["files"]],
            "evidence": [f"{f['path']} sha256={f['sha256'][:12]}" for f in result["files"][:8]],
            "artifacts": artifacts}


def h_enrich(run_id, task, project, payload, decision):
    """Optional AI copy refinement. Blocked without a key — reported, never faked."""
    settings = db.get_settings()
    model_id = decision.get("chosen_model")
    if not model_id or not engines.config_key_present(settings):
        return {"status": "skipped_blocked",
                "summary": "Model-assisted copy refinement skipped: no NVIDIA API key configured.",
                "error": "NVIDIA_API_KEY not set; deterministic copy is used instead.", "artifacts": [], "evidence": [
                    "provider call not attempted (no credential)"]}
    root = _version_root(project["id"], create=False)
    content = util.jload((root / "content" / "content.json").read_text(encoding="utf-8"), {})
    brief = util.jload(project.get("brief_json"), {})
    prompt = (
        "You are writing website copy. Return JSON only with keys headline, sub, cta_title, cta_body.\n"
        f"Business: {brief.get('name')} ({brief.get('archetype_label')})\nAudience: {brief.get('audience')}\n"
        f"Goals: {', '.join(brief.get('goals', []))}\nCurrent headline: {content.get('hero', {}).get('headline')}\n"
        "Rules: no invented statistics, no superlatives you cannot support, under 140 characters per headline, "
        "British English, plain language."
    )
    call = models.invoke(model_id, [{"role": "user", "content": prompt}], settings=settings, max_tokens=400)
    if not call.get("ok"):
        return {"status": "skipped_blocked", "summary": f"Model call failed: {call.get('status')}",
                "error": call.get("detail", ""), "artifacts": [], "evidence": [util.jdump(call)[:300]]}
    data = engines.extract_json(call["text"]) or {}
    if not data.get("headline"):
        return {"status": "skipped_blocked", "summary": "Model returned no usable content; deterministic copy kept.",
                "error": "unparsable model output", "artifacts": [], "evidence": [call["text"][:200]]}
    content["hero"]["headline"] = data.get("headline", content["hero"]["headline"])
    content["hero"]["sub"] = data.get("sub", content["hero"]["sub"])
    content["cta"]["title"] = data.get("cta_title", content["cta"]["title"])
    content["cta"]["body"] = data.get("cta_body", content["cta"]["body"])
    content["ai_enriched"] = {"model": model_id, "at": util.now_iso()}
    (root / "content" / "content.json").write_text(util.jdump(content), encoding="utf-8")
    blueprint = util.jload((root / "content" / "blueprint.json").read_text(encoding="utf-8"), generation.build_blueprint(project))
    for page in blueprint["pages"]:
        (root / "site" / page["file"]).write_text(generation.render_page(page, blueprint, content), encoding="utf-8")
    return {"status": "done", "summary": f"Copy refined via {model_id}; pages re-rendered.",
            "evidence": [f"model={model_id} latency_ms={call['latency_ms']}", f"usage={util.jdump(call.get('usage', {}))}"],
            "artifacts": [{"kind": "content", "label": "enriched content", "path": "content/content.json",
                           "bytes": (root / 'content' / 'content.json').stat().st_size}]}


def h_build(run_id, task, project, payload, decision):
    root = _version_root(project["id"], create=True, label="generated version",
                         notes="generated by the orchestration run", run_id=run_id)
    build = verify.run_build(root)
    db.log_task(task["id"], run_id, "info", f"build cmd: {build['command']} exit={build['exit_code']}")
    for line in (build["stdout"] or "").splitlines()[:12]:
        db.log_task(task["id"], run_id, "info", "build: " + line)
    status = "done" if build["ok"] else "failed"
    return {"status": status, "summary": f"build {'succeeded' if build['ok'] else 'failed'} via {build['tool']} in {build['duration_ms']} ms",
            "error": "" if build["ok"] else build["stderr"][-400:],
            "evidence": [f"$ {build['command']}", (build["stdout"] or build["stderr"])[-500:]],
            "artifacts": [{"kind": "build_log", "label": "build output", "path": f"runs/{run_id}/build.log",
                           "bytes": len(build["stdout"] + build["stderr"])}]}


def h_verify(run_id, task, project, payload, decision):
    root = _version_root(project["id"], create=True, label="generated version",
                         notes="generated by the orchestration run", run_id=run_id)
    report = verify.full_verification(root, run_id=run_id, project_id=project["id"])
    paths = verify.write_report(report, root / "checks")
    db.execute("UPDATE project_versions SET tests_json=? WHERE project_id=? AND version=?",
               (util.jdump(report["totals"]), project["id"],
                db.query_one("SELECT version FROM project_versions WHERE project_id=? ORDER BY version DESC LIMIT 1", (project["id"],))["version"]))
    failed = [c for c in report["checks"] if not c["ok"]]
    return {"status": "done",
            "summary": f"{report['totals']['passed']}/{report['totals']['checks']} checks passed "
                       f"(blockers={report['totals']['blockers']}, majors={report['totals']['majors']}, "
                       f"minors={report['totals']['minors']}); verdict={report['verdict']}",
            "verdict": report["verdict"], "failed_checks": [c["code"] for c in failed],
            "evidence": [f"{c['severity'].upper()} {c['code']} {c['title']} :: {c['evidence']}" for c in failed[:12]]
                        + [f"build exit={report['build']['exit_code']}"],
            "artifacts": [{"kind": "verification_report", "label": "verification report (json)",
                           "path": str(Path(paths["json"])), "bytes": Path(paths["json"]).stat().st_size},
                          {"kind": "verification_report_text", "label": "verification report (text)",
                           "path": paths["text"], "bytes": Path(paths["text"]).stat().st_size}]}


def h_seo_perf(run_id, task, project, payload, decision):
    root = _version_root(project["id"], create=True, label="generated version",
                         notes="generated by the orchestration run", run_id=run_id)
    pages = verify.parse_pages(root)
    checks = verify.check_seo(pages, root) + verify.check_performance(pages, root)
    failed = [c for c in checks if not c["ok"]]
    word_count = sum(len(c["evidence"].split()) for c in checks)
    return {"status": "done",
            "summary": f"SEO/performance review: {len(checks) - len(failed)}/{len(checks)} checks passed.",
            "failed_checks": [c["code"] for c in failed],
            "evidence": [f"{c['code']} {'ok' if c['ok'] else 'FAIL'} {c['title']} :: {c['evidence']}" for c in failed[:10]],
            "artifacts": []}


def h_security(run_id, task, project, payload, decision):
    root = _version_root(project["id"], create=True, label="generated version",
                         notes="generated by the orchestration run", run_id=run_id)
    pages = verify.parse_pages(root)
    checks = verify.check_security(pages, root)
    failed = [c for c in checks if not c["ok"]]
    db.ledger_set("security_and_isolation", 2 if not failed else 3,
                  evidence=f"security checks executed in run {run_id}: {len(checks)} checks, {len(failed)} failing",
                  limitations="Static analysis over generated files. Isolation is filesystem-scoped (path-guarded writes to the project version root); no OS-level container sandbox is used in single-user mode.")
    return {"status": "done",
            "summary": f"Security review: {len(checks) - len(failed)}/{len(checks)} checks passed.",
            "failed_checks": [c["code"] for c in failed],
            "evidence": [f"{c['code']} {'ok' if c['ok'] else 'FAIL'} {c['title']} :: {c['evidence']}" for c in checks],
            "artifacts": []}


def h_improve(run_id, task, project, payload, decision):
    """Feedback-to-code: apply a bounded, reviewable content improvement in a new
    version so the change is reversible."""
    root = _snapshot_new_version(project["id"], "feedback improvement",
                                 f"bounded content change derived from user feedback (run {run_id})")
    feedback = None
    if payload.get("feedback_id"):
        row = db.query_one("SELECT * FROM feedback WHERE id=?", (payload["feedback_id"],))
        feedback = dict(row) if row else None
    if feedback is None:
        return {"status": "failed", "error": "no feedback record supplied for this improvement run",
                "summary": "cannot apply an improvement without a feedback record", "artifacts": [], "evidence": []}
    result = engines.apply_feedback_improvement(project, root, feedback)
    db.execute("UPDATE feedback SET status='applied' WHERE id=?", (feedback["id"],))
    return {"status": "done", "summary": result["summary"],
            "applied": result["applied"], "deferred": result["deferred"],
            "evidence": [f"rule {a['rule']}: {a['detail']}" for a in result["applied"]]
                        + [f"deferred: {d}" for d in result["deferred"]]
                        + [f"re-rendered {p}" for p in result["pages"]],
            "artifacts": [{"kind": "improvement_notes", "label": "IMPROVEMENTS.md", "path": "IMPROVEMENTS.md",
                           "bytes": (root / "IMPROVEMENTS.md").stat().st_size},
                          {"kind": "roadmap", "label": "content/roadmap.json", "path": "content/roadmap.json",
                           "bytes": (root / "content" / "roadmap.json").stat().st_size}]}


def h_repair(run_id, task, project, payload, decision):
    """Deterministic repair of the failure classes this generator can produce."""
    root = _version_root(project["id"], create=True, label="generated version",
                         notes="generated by the orchestration run", run_id=run_id)
    report = verify.full_verification(root, run_id=run_id, project_id=project["id"])
    failed = [c for c in report["checks"] if not c["ok"] and c["severity"] in {"blocker", "major"}]
    if not failed:
        incident_plan = engines.incident_repair_plan(project["id"])
        db.ledger_set("maintenance_service", 1,
                      evidence=f"incident repair plan produced for {incident_plan['open_incidents']} open incident(s)",
                      limitations="Plan generation and rollback are implemented and require user approval; unattended auto-repair is intentionally not enabled.")
        return {"status": "done",
                "summary": f"no blocker or major check failures required code repair; "
                           f"{incident_plan['summary']}.",
                "repair_plan": incident_plan["plan"],
                "evidence": [f"verdict={report['verdict']} after {report['totals']['checks']} checks"]
                            + [f"incident {p['incident']} ({p['kind']}): {p['recommended_actions'][0]}" for p in incident_plan["plan"]][:5],
                "artifacts": []}
    repaired, unrepaired = [], []
    for check in failed:
        action = REPAIR_RULES.get(check["code"])
        if action is None:
            unrepaired.append({"code": check["code"], "title": check["title"], "evidence": check["evidence"]})
            continue
        try:
            detail = action(root, check)
            repaired.append({"code": check["code"], "action": detail})
            db.log_task(task["id"], run_id, "info", f"repaired {check['code']}: {detail}")
        except Exception as exc:
            unrepaired.append({"code": check["code"], "title": check["title"],
                               "evidence": f"repair raised {type(exc).__name__}: {exc}"})
    after = verify.full_verification(root, run_id=run_id, project_id=project["id"]) if repaired else report
    verify.write_report(after, root / "checks")
    status = "done" if repaired and after["totals"]["blockers"] == 0 else ("done" if not repaired else "failed")
    return {"status": status,
            "summary": f"repair applied to {len(repaired)} check(s); {len(unrepaired)} left for human review. "
                       f"verdict now {after['verdict']}.",
            "repaired": repaired, "unrepaired": unrepaired,
            "evidence": [f"repaired {r['code']}: {r['action']}" for r in repaired][:10]
                        + [f"unrepaired {u['code']}: {u['evidence'][:120]}" for u in unrepaired][:6],
            "artifacts": []}


def _repair_missing_reference(root: Path, check: dict) -> str:
    """Regenerate the missing asset/link target reported in the evidence."""
    evidence = check["evidence"]
    target = re_first(r"missing=\['([^']+)'\]", evidence) or re_first(r"broken=\['([^']+)'\]", evidence)
    if not target:
        raise ValueError("no target parsed from evidence")
    project_row = db.query_one("SELECT * FROM projects ORDER BY updated_at DESC LIMIT 1")
    project = dict(project_row)
    blueprint = util.jload((root / "content" / "blueprint.json").read_text(encoding="utf-8"),
                           generation.build_blueprint(project))
    tokens = blueprint["tokens"]
    target_path = root / "site" / target
    target_path.parent.mkdir(parents=True, exist_ok=True)
    if target.endswith(".html"):
        slug = target[:-5]
        content = util.jload((root / "content" / "content.json").read_text(encoding="utf-8"),
                             generation.author_content(project, blueprint, {}))
        page = {"slug": slug, "title": generation.PAGE_TITLES.get(slug, slug.title()), "file": target}
        if page not in blueprint["pages"]:
            blueprint["pages"].append(page)
            blueprint["nav"].append((slug, page["title"]))
        target_path.write_text(generation.render_page(page, blueprint, content), encoding="utf-8")
        (root / "site" / "sitemap.xml").write_text(generation.sitemap_xml(blueprint), encoding="utf-8")
        return f"generated missing page {target} and refreshed the sitemap"
    if target.endswith(".svg"):
        name = target.split("/")[-1]
        if name.startswith("tile-"):
            index = int(re_first(r"tile-(\d+)", name) or 1)
            target_path.write_text(generation.tile_svg(index, tokens), encoding="utf-8")
        elif name.startswith("avatar-"):
            index = int(re_first(r"avatar-(\d+)", name) or 1)
            target_path.write_text(generation.avatar_svg(index, tokens), encoding="utf-8")
        elif name == "og-cover.svg":
            target_path.write_text(generation.cover_svg(blueprint["brand_name"], blueprint["tagline"], tokens), encoding="utf-8")
        else:
            target_path.write_text(generation.logo_svg(blueprint["brand_name"], tokens), encoding="utf-8")
        return f"regenerated asset {target}"
    raise ValueError(f"no repair strategy for {target}")


def _repair_asset_path(root: Path, check: dict) -> str:
    return _repair_missing_reference(root, check)


def _repair_regenerate_site(root: Path, check: dict) -> str:
    record = db.query_one("SELECT * FROM projects ORDER BY updated_at DESC LIMIT 1")
    project = dict(record)
    blueprint = util.jload((root / "content" / "blueprint.json").read_text(encoding="utf-8"),
                           generation.build_blueprint(project))
    content = util.jload((root / "content" / "content.json").read_text(encoding="utf-8"),
                         generation.author_content(project, blueprint, {}))
    for page in blueprint["pages"]:
        (root / "site" / page["file"]).write_text(generation.render_page(page, blueprint, content), encoding="utf-8")
    (root / "site" / "sitemap.xml").write_text(generation.sitemap_xml(blueprint), encoding="utf-8")
    return "re-rendered every page and the sitemap from blueprint + content"


def re_first(pattern: str, text: str) -> str:
    import re
    m = re.search(pattern, text or "")
    return m.group(1) if m else ""


REPAIR_RULES = {
    "APP-006": _repair_missing_reference,
    "APP-007": _repair_missing_reference,
    "APP-011": _repair_regenerate_site,
    "APP-003": _repair_regenerate_site,
    "APP-004": _repair_regenerate_site,
    "SEO-001": _repair_regenerate_site,
    "SEO-002": _repair_regenerate_site,
    "SEO-005": _repair_regenerate_site,
}


def h_acceptance(run_id, task, project, payload, decision):
    root = _version_root(project["id"], create=True, label="generated version",
                         notes="generated by the orchestration run", run_id=run_id)
    report = verify.full_verification(root, run_id=run_id, project_id=project["id"])
    verify.write_report(report, root / "checks")
    version = db.query_one("SELECT * FROM project_versions WHERE project_id=? ORDER BY version DESC LIMIT 1", (project["id"],))
    acceptance = {
        "verdict": report["verdict"], "totals": report["totals"],
        "quality_gate": {
            "build_succeeded": report["build"]["ok"],
            "blockers_zero": report["totals"]["blockers"] == 0,
            "majors_zero": report["totals"]["majors"] == 0,
            "passed": report["verdict"] in {"pass", "pass_with_warnings"},
        },
        "checked_at": util.now_iso(), "version": version["version"] if version else None,
    }
    db.execute("UPDATE projects SET acceptance_json=? WHERE id=?", (util.jdump(acceptance), project["id"]))
    db.ledger_set("website_generation", 1,
                  evidence=f"version v{acceptance['version']} at {root}; build exit={report['build']['exit_code']}; "
                           f"{report['totals']['passed']}/{report['totals']['checks']} checks passed; report at checks/verification_report.json",
                  limitations="Verification is deterministic static analysis plus a real build; no browser rendering engine is available in this environment, so visual regression testing is limited to marked-up structure and measured payload.")
    status = "done"
    return {"status": status, "summary": f"Acceptance verdict: {report['verdict'].upper()} "
                                        f"({report['totals']['passed']}/{report['totals']['checks']} checks passed)",
            "acceptance": acceptance,
            "evidence": [f"build_exit={report['build']['exit_code']}",
                         f"blockers={report['totals']['blockers']} majors={report['totals']['majors']} minors={report['totals']['minors']}"],
            "artifacts": [{"kind": "verification_report", "label": "final verification report",
                           "path": str(root / 'checks' / 'verification_report.json'),
                           "bytes": (root / 'checks' / 'verification_report.json').stat().st_size}]}


def h_docs(run_id, task, project, payload, decision):
    root = _version_root(project["id"], create=True, label="generated version",
                         notes="generated by the orchestration run", run_id=run_id)
    project = dict(db.query_one("SELECT * FROM projects WHERE id=?", (project["id"],)))
    blueprint = util.jload((root / "content" / "blueprint.json").read_text(encoding="utf-8"),
                           generation.build_blueprint(project))
    checklist = engines.deployment_plan(project, root, db.query_one(
        "SELECT version FROM project_versions WHERE project_id=? ORDER BY version DESC LIMIT 1", (project["id"],))["version"])
    docs_dir = root / "checklists"
    docs_dir.mkdir(parents=True, exist_ok=True)
    (docs_dir / "launch_checklist.md").write_text(
        "# Launch checklist\n\n" + "\n".join(f"- [ ] {item[3:] if item[:2].isdigit() else item}" for item in checklist["checklist"]) + "\n",
        encoding="utf-8")
    (root / "DEPLOYMENT.md").write_text(checklist["markdown"], encoding="utf-8")
    pages = [f["path"] for f in util.jload(db.query_one(
        "SELECT manifest_json FROM project_versions WHERE project_id=? ORDER BY version DESC LIMIT 1",
        (project["id"],))["manifest_json"], {}).get("files", [])]
    return {"status": "done", "summary": f"Documentation written: README.md, DEPLOYMENT.md, launch checklist ({len(checklist['checklist'])} items).",
            "evidence": [f"files documented={len(pages)}"],
            "artifacts": [{"kind": "checklist", "label": "launch checklist", "path": "checklists/launch_checklist.md",
                           "bytes": (docs_dir / 'launch_checklist.md').stat().st_size},
                          {"kind": "deployment_plan", "label": "deployment plan", "path": "DEPLOYMENT.md",
                           "bytes": (root / 'DEPLOYMENT.md').stat().st_size}]}


def h_export(run_id, task, project, payload, decision):
    result = engines.export_version(project["id"])
    status = "done" if result.get("ok") else "failed"
    return {"status": status, "summary": result.get("detail", "export failed"),
            "error": "" if result.get("ok") else result.get("detail", ""),
            "evidence": [f"package={result.get('zip')} bytes={result.get('bytes')}"],
            "artifacts": [{"kind": "export_package", "label": Path(result["zip"]).name,
                           "path": result["zip"], "bytes": result["bytes"]}]}


def h_translate(run_id, task, project, payload, decision):
    root = _version_root(project["id"])   # locales are written into the latest version
    targets = payload.get("targets") or util.jload(project.get("brief_json"), {}).get("languages", ["ta"])
    targets = [t for t in targets if t != "en"] or ["ta"]
    results = []
    for lang in targets:
        res = engines.translate_project(project, root, lang, run_id=run_id)
        results.append({"lang": lang, "status": res.get("status"), "coverage": res.get("coverage"),
                        "detail": res.get("detail")})
        db.log_task(task["id"], run_id, "info",
                    f"{lang}: status={res.get('status')} coverage={res.get('coverage')}% engine={res.get('engine')}")
    if any(r["status"] == "blocked_insufficient_coverage" for r in results):
        status = "skipped_blocked"
        error = ("Translation coverage insufficient: the curated glossary does not cover the site copy and no "
                 "NVIDIA API key is configured for the translation model. Reported as blocked rather than fabricated.")
    else:
        status, error = "done", ""
    return {"status": status, "error": error, "summary": "; ".join(
                f"{r['lang']}: {r['status']} ({r['coverage']}%)" for r in results),
            "results": results,
            "evidence": [f"{r['lang']} {r['detail']}" for r in results],
            "artifacts": [{"kind": "locales", "label": f"locales/{r['lang']}", "path": f"locales/{r['lang']}",
                           "bytes": 0} for r in results]}


def h_feedback_triage(run_id, task, project, payload, decision):
    analysis = engines.analyze_feedback(project["id"], payload.get("text", ""),
                                        payload.get("channel", "console"), payload.get("author", ""))
    return {"status": "done",
            "summary": f"feedback analysed: {analysis['summary']}",
            "analysis": analysis,
            "evidence": [f"category={analysis['category']} sentiment={analysis['sentiment']} priority={analysis['priority']}",
                         f"duplicate_of={analysis['duplicate_of'] or 'none'}",
                         f"redactions={util.jload(analysis['analysis_json'], {}).get('redactions', [])}"],
            "artifacts": []}


def h_monitor(run_id, task, project, payload, decision):
    result = engines.run_monitors(project["id"])
    if not result.get("ok"):
        return {"status": "failed", "error": result.get("detail", ""), "summary": "monitoring could not run",
                "artifacts": [], "evidence": [result.get("detail", "")]}
    failing = [r for r in result["results"] if not r["ok"]]
    return {"status": "done",
            "summary": f"{len(result['results']) - len(failing)}/{len(result['results'])} monitor checks passed; "
                       f"{len(result['incidents_created'])} incident(s) opened.",
            "results": result["results"], "incidents": result["incidents_created"],
            "evidence": [f"{r['check']}: {'ok' if r['ok'] else 'FAIL'} — {r['detail']}" for r in result["results"]],
            "artifacts": []}


def h_marketing(run_id, task, project, payload, decision):
    result = engines.marketing_assets(project)
    return {"status": "done", "summary": result["summary"],
            "publishing": result["publishing"],
            "evidence": [f"{a['kind']} on {a['channel']}: {a['title']}" for a in result["assets"]]
                        + [f"publishing state={result['publishing']['state']}: {result['publishing']['detail']}"],
            "artifacts": [{"kind": "marketing_asset", "label": a["title"], "path": "", "bytes": len(a["body"])}
                          for a in result["assets"]]}


def h_media(run_id, task, project, payload, decision):
    result = engines.media_assets(project)
    return {"status": "done", "summary": f"{result['scenes']} scenes storyboarded ({result['total_seconds']}s). {result['detail']}",
            "media": result,
            "evidence": [f"ffmpeg={result['ffmpeg'] or 'not found'}", result["detail"]],
            "artifacts": [{"kind": "media", "label": a, "path": f"{result['dir']}/{a}",
                           "bytes": (Path(result['dir']) / a).stat().st_size} for a in result["artifacts"]]}


def h_clarify(run_id, task, project, payload, decision):
    result = engines.clarification_questions(project["id"], run_id)
    message = result.get("message", {})
    return {"status": "done", "summary": result.get("detail", "no questions"),
            "questions": result.get("questions", []),
            "evidence": [f"message status={message.get('status')} detail={message.get('detail')}"],
            "artifacts": []}


def h_deploy_execute(run_id, task, project, payload, decision):
    """Deployment execution. No hosting target is configured in single-user mode,
    so this reports the real blocker instead of claiming a deployment."""
    settings = db.get_settings()
    authorized = str(settings.get("deploy_authorized", "false")).lower() in {"1", "true", "yes", "on"}
    target = str(settings.get("deploy_target", "") or "")
    if not target:
        return {"status": "skipped_blocked",
                "summary": "Deployment not executed: no hosting target is configured.",
                "error": ("No deploy_target setting is present. The export package and DEPLOYMENT.md contain "
                          "the exact handover steps; configure a target and authorization to enable execution."),
                "artifacts": [], "evidence": [f"deploy_authorized={authorized} deploy_target={'set' if target else 'unset'}"]}
    return {"status": "skipped_blocked",
            "summary": f"Deployment adapter not implemented for target '{target}'.",
            "error": "Publishing adapters require per-provider credentials and are out of scope for the single-user edition.",
            "artifacts": [], "evidence": [f"target={target}"]}


HANDLERS = {
    "intake": h_intake, "plan": h_plan, "research": h_research, "resources": h_resources,
    "licensing": h_licensing, "architecture": h_architecture, "design": h_design,
    "generate": h_generate, "enrich": h_enrich, "build": h_build, "verify": h_verify,
    "seo_perf": h_seo_perf, "security": h_security, "repair": h_repair, "acceptance": h_acceptance,
    "docs": h_docs, "export": h_export, "translate": h_translate, "feedback_triage": h_feedback_triage,
    "monitor": h_monitor, "marketing": h_marketing, "media": h_media, "clarify": h_clarify,
    "deploy_execute": h_deploy_execute, "improve": h_improve,
}


# ---------------------------------------------------------------------------
# control surface used by the API
# ---------------------------------------------------------------------------


def cancel_run(run_id: str) -> dict:
    state = RUNNERS.get(run_id)
    if state:
        state.cancel.set()
    db.execute("UPDATE runs SET cancel_requested=1 WHERE id=?", (run_id,))
    db.audit("user", "run_cancel_requested", run_id)
    return {"ok": True, "detail": "cancellation requested; running tasks finish, pending tasks will not start"}


def approve_task(task_id: str) -> dict:
    row = db.query_one("SELECT * FROM tasks WHERE id=?", (task_id,))
    if row is None:
        return {"ok": False, "detail": "task not found"}
    db.execute("UPDATE tasks SET approved_at=?, status='pending' WHERE id=?", (util.now_iso(), task_id))
    db.audit("user", "task_approved", task_id)
    run_id = row["run_id"]
    run = db.query_one("SELECT * FROM runs WHERE id=?", (run_id,))
    if run["status"] in {"awaiting_approval", "succeeded_with_warnings", "failed"}:
        db.execute("UPDATE runs SET status='running' WHERE id=?", (run_id,))
        state = RunState(run_id)
        RUNNERS[run_id] = state
        state.thread = threading.Thread(target=_execute_run, args=(run_id,), daemon=True)
        state.thread.start()
    return {"ok": True, "detail": f"task {task_id} approved and released for execution"}


def resume_interrupted_runs() -> int:
    """Called at boot: re-queue runs that were mid-flight when the process stopped."""
    rows = db.query("SELECT id FROM runs WHERE status IN ('running','queued','awaiting_approval')")
    count = 0
    for row in rows:
        run_id = row["id"]
        if run_id in RUNNERS:
            continue
        state = RunState(run_id)
        RUNNERS[run_id] = state
        state.thread = threading.Thread(target=_execute_run, args=(run_id,), daemon=True)
        state.thread.start()
        count += 1
    return count


def run_detail(run_id: str) -> dict:
    run = db.query_one("SELECT * FROM runs WHERE id=?", (run_id,))
    if run is None:
        return {}
    tasks = []
    for row in db.query("SELECT * FROM tasks WHERE run_id=? ORDER BY seq", (run_id,)):
        task = dict(row)
        task["depends_on"] = util.jload(row["depends_on_json"], [])
        task["output"] = util.jload(row["output_json"], {})
        task["artifacts"] = util.jload(row["artifacts_json"], [])
        task["agent_name"] = ""
        if row["agent_id"]:
            agent = db.query_one("SELECT name, department FROM agents WHERE id=?", (row["agent_id"],))
            if agent:
                task["agent_name"] = agent["name"]
                task["agent_department"] = agent["department"]
        tasks.append(task)
    return {"run": {**dict(run), "request": util.jload(run["request_json"], {}),
                    "summary": util.jload(run["summary_json"], {})},
            "tasks": tasks,
            "logs": [dict(l) for l in db.query("SELECT * FROM task_logs WHERE run_id=? ORDER BY id LIMIT 800", (run_id,))]}
