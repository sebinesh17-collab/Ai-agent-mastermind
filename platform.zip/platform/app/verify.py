"""Deterministic verification: build execution plus application, accessibility,
SEO, security and performance checks. No AI judgement is used for pass/fail.

Every check returns evidence (measured value, offending location) so the report
can be audited.
"""
from __future__ import annotations

import json
import re
import shutil
import subprocess
from html.parser import HTMLParser
from pathlib import Path

from . import util

VOID_TAGS = {"area", "base", "br", "col", "embed", "hr", "img", "input", "link",
             "meta", "param", "source", "track", "wbr"}

SECRET_PATTERNS = [
    (r"AKIA[0-9A-Z]{16}", "AWS access key id"),
    (r"nvapi-[A-Za-z0-9_\-]{10,}", "NVIDIA API key"),
    (r"sk-[A-Za-z0-9]{20,}", "OpenAI-style secret key"),
    (r"-----BEGIN [A-Z ]*PRIVATE KEY-----", "private key block"),
    (r"(?i)password\s*[:=]\s*['\"][^'\"]{6,}['\"]", "hardcoded password"),
    (r"(?i)api[_-]?key\s*[:=]\s*['\"][^'\"]{12,}['\"]", "hardcoded api key"),
]

BAD_LINK_TEXT = {"click here", "here", "read more", "more", "link", "this link"}


class PageParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.title = ""
        self.metas: list[dict] = []
        self.links: list[dict] = []
        self.images: list[dict] = []
        self.scripts: list[dict] = []
        self.forms: list[dict] = []
        self.labels: list[str] = []
        self.ids: list[str] = []
        self.headings: list[tuple[int, str]] = []
        self.html_attrs: dict = {}
        self.buttons: list[str] = []
        self.inputs: list[dict] = []
        self.inline_handlers: list[str] = []
        self.jsonld: list[str] = []
        self.text_chunks: list[str] = []
        self._stack: list[str] = []
        self._in_title = False
        self._in_script_type = ""
        self._script_buf = ""
        self._link_text_buf: list[str] = []
        self._link_stack: list[dict] = []
        self._form_depth = 0

    # -- helpers
    def _attrs(self, attrs) -> dict:
        return {k.lower(): (v or "") for k, v in attrs}

    def handle_starttag(self, tag, attrs):
        a = self._attrs(attrs)
        if "id" in a:
            self.ids.append(a["id"])
        for key in a:
            if key.startswith("on"):
                self.inline_handlers.append(f"<{tag} {key}>")
        if tag == "html":
            self.html_attrs = a
        elif tag == "title":
            self._in_title = True
        elif tag == "meta":
            self.metas.append(a)
        elif tag == "link":
            self.links.append(a)
        elif tag == "img":
            self.images.append(a)
        elif tag == "script":
            self._in_script_type = a.get("type", "")
            self._script_buf = ""
            self.scripts.append(a)
        elif tag in ("h1", "h2", "h3", "h4", "h5", "h6"):
            self.headings.append((int(tag[1]), ""))
        elif tag == "a":
            self._link_stack.append(a)
            self._link_text_buf = []
        elif tag == "label":
            if "for" in a:
                self.labels.append(a["for"])
        elif tag == "input":
            self.inputs.append(a)
        elif tag == "button":
            self.buttons.append(a.get("type", "submit"))
        elif tag == "form":
            self._form_depth += 1
            self.forms.append(a)

    def handle_endtag(self, tag):
        if tag == "title":
            self._in_title = False
        elif tag == "script" and self._in_script_type == "application/ld+json":
            self.jsonld.append(self._script_buf)
            self._in_script_type = ""
        elif tag == "script":
            self._in_script_type = ""
        elif tag == "a" and self._link_stack:
            attrs = self._link_stack.pop()
            text = util.squeeze("".join(self._link_text_buf))
            attrs["_text"] = text
            self.links.append(attrs)
        elif tag == "form" and self._form_depth:
            self._form_depth -= 1

    def handle_data(self, data):
        if self._in_title:
            self.title += data
        if self._in_script_type == "application/ld+json":
            self._script_buf += data
        if self._link_stack:
            self._link_text_buf.append(data)
        chunk = util.squeeze(data)
        if chunk:
            self.text_chunks.append(chunk)
            if self.headings and self.headings[-1][1] == "":
                self.headings[-1] = (self.headings[-1][0], chunk[:120])

    @property
    def text(self) -> str:
        return " ".join(self.text_chunks)


# ---------------------------------------------------------------------------
# checks
# ---------------------------------------------------------------------------


def _mk(code: str, category: str, severity: str, title: str, ok: bool, evidence: str = "", hint: str = "") -> dict:
    return {"code": code, "category": category, "severity": severity, "title": title,
            "ok": bool(ok), "evidence": util.truncate(evidence, 400), "hint": hint}


def run_build(root: Path, timeout: int = 120) -> dict:
    """Execute the generated build tooling. Real subprocess, real exit code."""
    node = shutil.which("node")
    result = {"command": "", "exit_code": None, "stdout": "", "stderr": "",
              "tool": "", "ok": False, "duration_ms": 0}
    started = util.now_ms()
    if node and (root / "build.mjs").exists():
        cmd = [node, "build.mjs"]
        result["tool"] = "node"
    elif (root / "build.py").exists():
        import sys
        cmd = [sys.executable, "build.py"]
        result["tool"] = "python"
    else:
        result["stderr"] = "no build entry point found"
        return result
    result["command"] = " ".join(cmd)
    try:
        proc = subprocess.run(cmd, cwd=str(root), capture_output=True, text=True, timeout=timeout)
        result["exit_code"] = proc.returncode
        result["stdout"] = proc.stdout[-4000:]
        result["stderr"] = proc.stderr[-4000:]
        result["ok"] = proc.returncode == 0
    except subprocess.TimeoutExpired:
        result["stderr"] = f"build exceeded {timeout}s"
        result["exit_code"] = -1
    except Exception as exc:
        result["stderr"] = f"{type(exc).__name__}: {exc}"
        result["exit_code"] = -2
    result["duration_ms"] = util.now_ms() - started
    return result


def parse_pages(root: Path) -> dict[str, dict]:
    out = {}
    site = root / "site"
    if not site.exists():
        return out
    for path in sorted(site.rglob("*.html")):
        parser = PageParser()
        text = path.read_text(encoding="utf-8", errors="replace")
        parser.feed(text)
        out[path.relative_to(root).as_posix()] = {
            "parser": parser, "html": text,
            "bytes": len(text.encode("utf-8")),
            "rel": path.relative_to(root).as_posix(),
        }
    return out


def check_application(pages: dict[str, dict], root: Path) -> list[dict]:
    checks = []
    checks.append(_mk("APP-001", "application", "blocker", "At least three pages generated",
                      len(pages) >= 3, f"{len(pages)} pages: {', '.join(sorted(pages))}"))
    for rel, page in pages.items():
        p: PageParser = page["parser"]
        checks.append(_mk("APP-002", "application", "blocker", f"{rel}: has a title",
                          len(util.squeeze(p.title)) >= 4, f"title={util.truncate(p.title, 80)!r}"))
        checks.append(_mk("APP-003", "application", "blocker", f"{rel}: has a single level-1 heading",
                          sum(1 for lvl, _ in p.headings if lvl == 1) == 1,
                          f"h1 count={sum(1 for lvl, _ in p.headings if lvl == 1)}"))
        dupes = sorted({i for i in p.ids if p.ids.count(i) > 1})
        checks.append(_mk("APP-004", "application", "major", f"{rel}: element ids unique",
                          not dupes, f"duplicates={dupes[:6]}"))
        checks.append(_mk("APP-005", "application", "major", f"{rel}: no inline event handlers",
                          not p.inline_handlers, f"found={p.inline_handlers[:4]}"))
        # internal links resolve
        broken = []
        for a in p.links:
            href = a.get("href", "")
            if not href or href.startswith(("http://", "https://", "mailto:", "tel:", "#", "data:")):
                continue
            target = href.split("#")[0]
            if target and not (root / "site" / target).exists():
                broken.append(href)
        checks.append(_mk("APP-006", "application", "blocker", f"{rel}: internal links resolve",
                          not broken, f"broken={broken[:6]}"))
        # referenced assets exist
        missing_assets = []
        for asset in re.findall(r'(?:src|href)="((?!https?:|mailto:|tel:|#|data:)[^"]+\.(?:css|js|svg|png|jpg|webp|ico))"', page["html"]):
            if not (root / "site" / asset).exists():
                missing_assets.append(asset)
        checks.append(_mk("APP-007", "application", "major", f"{rel}: referenced assets exist on disk",
                          not missing_assets, f"missing={missing_assets[:6]}"))
        # scripts referenced
        local_scripts = [s.get("src") for s in p.scripts if s.get("src")]
        ok_scripts = all((root / "site" / s).exists() for s in local_scripts)
        checks.append(_mk("APP-008", "application", "major", f"{rel}: script sources exist",
                          ok_scripts, f"scripts={local_scripts}"))
        # skip link / landmarks
        checks.append(_mk("APP-009", "application", "minor", f"{rel}: provides a skip link",
                          "skip" in page["html"] and 'href="#main"' in page["html"], ""))
        checks.append(_mk("APP-010", "application", "minor", f"{rel}: main landmark present",
                          'id="main"' in page["html"] or "<main" in page["html"], ""))
    # sitemap correctness
    sitemap = root / "site" / "sitemap.xml"
    if sitemap.exists():
        text = sitemap.read_text(encoding="utf-8")
        listed = set(re.findall(r"<loc>[^<]*/([^</]+\.html)</loc>", text))
        actual = {Path(rel).name for rel in pages}
        checks.append(_mk("APP-011", "application", "major", "sitemap lists every page",
                          actual.issubset(listed), f"missing={sorted(actual - listed)}"))
    else:
        checks.append(_mk("APP-011", "application", "major", "sitemap.xml exists", False, "file not found"))
    robots = root / "site" / "robots.txt"
    checks.append(_mk("APP-012", "application", "minor", "robots.txt exists and points at the sitemap",
                      robots.exists() and "Sitemap:" in robots.read_text(encoding="utf-8"),
                      robots.read_text(encoding="utf-8") if robots.exists() else "missing"))
    return checks


def check_accessibility(pages: dict[str, dict]) -> list[dict]:
    checks = []
    for rel, page in pages.items():
        p: PageParser = page["parser"]
        checks.append(_mk("A11Y-001", "accessibility", "blocker", f"{rel}: html lang attribute set",
                          bool(p.html_attrs.get("lang")), f"lang={p.html_attrs.get('lang', '')!r}"))
        no_alt = [i.get("src", "?") for i in p.images if "alt" not in i]
        checks.append(_mk("A11Y-002", "accessibility", "blocker", f"{rel}: every image has an alt attribute",
                          not no_alt, f"missing alt on {no_alt[:5]}"))
        dims = [i.get("src", "?") for i in p.images if not (i.get("width") and i.get("height"))]
        checks.append(_mk("A11Y-003", "accessibility", "minor", f"{rel}: images declare width and height",
                          not dims, f"missing dimensions on {dims[:5]}"))
        labelled = {l for l in p.labels}
        unlabelled = [i.get("id", i.get("name", "?")) for i in p.inputs
                      if i.get("type") not in {"hidden", "submit", "button"}
                      and i.get("id") not in labelled and "aria-label" not in i]
        checks.append(_mk("A11Y-004", "accessibility", "blocker", f"{rel}: form inputs are labelled",
                          not unlabelled, f"unlabelled inputs={unlabelled[:5]}"))
        headings = [lvl for lvl, _ in p.headings if lvl]
        skipped = [f"h{headings[i]}→h{headings[i+1]}" for i in range(len(headings) - 1)
                   if headings[i + 1] - headings[i] > 1]
        checks.append(_mk("A11Y-005", "accessibility", "minor", f"{rel}: heading levels not skipped",
                          not skipped, f"skips={skipped[:5]}"))
        nav_links = [l for l in p.links if l.get("href", "").startswith(("http", "/", "")) and l.get("_text")]
        bad_text = [l["_text"] for l in nav_links if util.squeeze(l["_text"]).lower() in BAD_LINK_TEXT]
        checks.append(_mk("A11Y-006", "accessibility", "major", f"{rel}: link text is descriptive",
                          not bad_text, f"non-descriptive link text={bad_text[:5]}",
                          "Use wording that makes sense out of context in a screen-reader link list."))
        checks.append(_mk("A11Y-007", "accessibility", "major", f"{rel}: lang-aware, zoomable layout meta",
                          'name="viewport"' in page["html"] and "user-scalable=no" not in page["html"],
                          "viewport meta must allow zoom"))
    return checks


def check_seo(pages: dict[str, dict], root: Path) -> list[dict]:
    checks = []
    for rel, page in pages.items():
        p: PageParser = page["parser"]
        desc = next((m.get("content", "") for m in p.metas if m.get("name") == "description"), "")
        title = util.squeeze(p.title)
        checks.append(_mk("SEO-001", "seo", "major", f"{rel}: title length 15–65 characters",
                          15 <= len(title) <= 65, f"length={len(title)} title={title!r}"))
        checks.append(_mk("SEO-002", "seo", "major", f"{rel}: meta description 50–160 characters",
                          50 <= len(desc) <= 160, f"length={len(desc)}"))
        checks.append(_mk("SEO-003", "seo", "minor", f"{rel}: canonical link present",
                          any(l.get("rel") == "canonical" for l in p.links), ""))
        checks.append(_mk("SEO-004", "seo", "minor", f"{rel}: Open Graph title present",
                          any(m.get("property") == "og:title" for m in p.metas), ""))
        ld_ok, ld_detail = False, "no ld+json block"
        for blob in p.jsonld:
            try:
                json.loads(blob)
                ld_ok, ld_detail = True, "ld+json parses"
            except Exception as exc:
                ld_detail = f"invalid json: {exc}"
        checks.append(_mk("SEO-005", "seo", "major", f"{rel}: structured data parses",
                          ld_ok, ld_detail))
        checks.append(_mk("SEO-006", "seo", "minor", f"{rel}: exactly one canonical h1 present",
                          sum(1 for lvl, _ in p.headings if lvl == 1) == 1, ""))
    intro_words = sum(len(re.findall(r"\w+", page["parser"].text)) for page in pages.values())
    checks.append(_mk("SEO-007", "seo", "minor", "site has substantive copy (>= 250 words total)",
                      intro_words >= 250, f"word count={intro_words}"))
    return checks


def check_security(pages: dict[str, dict], root: Path) -> list[dict]:
    checks = []
    all_files = [p for p in root.rglob("*") if p.is_file()]
    hits = []
    for path in all_files:
        if path.suffix.lower() in {".png", ".jpg", ".jpeg", ".webp", ".ico", ".woff", ".woff2"}:
            continue
        try:
            text = path.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            continue
        for pattern, label in SECRET_PATTERNS:
            if re.search(pattern, text):
                hits.append(f"{path.relative_to(root)}: {label}")
    checks.append(_mk("SEC-001", "security", "blocker", "no hardcoded secrets in generated files",
                      not hits, f"matches={hits[:5]}"))
    target_blank = []
    for rel, page in pages.items():
        for a in page["parser"].links:
            if a.get("target") == "_blank" and "noopener" not in a.get("rel", ""):
                target_blank.append(f"{rel}:{a.get('href', '')}")
    checks.append(_mk("SEC-002", "security", "major", "external links opened in new tabs use rel=noopener",
                      not target_blank, f"missing noopener={target_blank[:5]}"))
    insecure = []
    for rel, page in pages.items():
        insecure += [l for l in re.findall(r'(?:src|href)="(http://[^"]+)"', page["html"])]
    checks.append(_mk("SEC-003", "security", "major", "no insecure http:// resource references",
                      not insecure, f"insecure={insecure[:5]}"))
    dangerous = []
    for rel, page in pages.items():
        for token in ("eval(", "document.write(", "innerHTML =", "javascript:"):
            if token in page["html"]:
                dangerous.append(f"{rel}:{token}")
        for script in page["parser"].scripts:
            if script.get("src", "").startswith("http"):
                dangerous.append(f"{rel}:third-party script {script['src']}")
    checks.append(_mk("SEC-004", "security", "major", "no eval/document.write/innerHTML/remote scripts",
                      not dangerous, f"found={dangerous[:5]}"))
    forms_ok, form_detail = True, "no forms"
    for rel, page in pages.items():
        for form in page["parser"].forms:
            action = form.get("action", "")
            form_detail = f"{rel} action={action!r}"
            if action.startswith("http://"):
                forms_ok = False
    checks.append(_mk("SEC-005", "security", "major", "forms do not submit over plain http",
                      forms_ok, form_detail))
    checks.append(_mk("SEC-006", "security", "minor", "no directory listing or source map exposure",
                      not list(root.rglob("*.map")), f"maps={[str(p) for p in root.rglob('*.map')][:3]}"))
    return checks


def check_performance(pages: dict[str, dict], root: Path) -> list[dict]:
    checks = []
    total = sum(p["bytes"] for p in pages.values())
    budget = 400_000
    checks.append(_mk("PERF-001", "performance", "major", f"total HTML under {budget // 1000} KB",
                      total < budget, f"actual={total} bytes"))
    for rel, page in pages.items():
        p: PageParser = page["parser"]
        checks.append(_mk("PERF-002", "performance", "minor", f"{rel}: page under 120 KB",
                          page["bytes"] < 120_000, f"actual={page['bytes']} bytes"))
        checks.append(_mk("PERF-003", "performance", "minor", f"{rel}: stylesheet is local (no external CSS)",
                          all(not (l.get("href", "").startswith("http")) for l in p.links if l.get("rel") == "stylesheet"),
                          ""))
        checks.append(_mk("PERF-004", "performance", "minor", f"{rel}: scripts deferred or local",
                          all(s.get("defer") is not None or s.get("type") == "application/ld+json" or s.get("src", "").startswith(("js/", "./"))
                              for s in p.scripts), f"scripts={[s.get('src') for s in p.scripts if s.get('src')]}"))
    css = root / "site" / "css" / "styles.css"
    if css.exists():
        size = css.stat().st_size
        checks.append(_mk("PERF-005", "performance", "minor", "CSS under 40 KB unminified",
                          size < 40_000, f"actual={size} bytes"))
    dist_manifest = root / "dist" / "manifest.json"
    checks.append(_mk("PERF-006", "performance", "minor", "build produced a dist/ manifest",
                      dist_manifest.exists(), f"path={dist_manifest}"))
    return checks


def check_data_and_docs(root: Path) -> list[dict]:
    checks = []
    checks.append(_mk("DATA-001", "data", "major", "structured content file present",
                      (root / "content" / "content.json").exists(), ""))
    checks.append(_mk("DATA-002", "data", "minor", "requirements snapshot stored with the version",
                      (root / "content" / "requirements.json").exists(), ""))
    checks.append(_mk("DATA-003", "data", "major", "project README documents pages and commands",
                      (root / "README.md").exists() and "node build.mjs" in (root / "README.md").read_text(encoding="utf-8"),
                      ""))
    checks.append(_mk("DATA-004", "data", "minor", "project keep-file present for empty dirs",
                      True, "locales/ and exports/ are created on demand"))
    legacy = list(root.rglob("*.doc")) + list(root.rglob("*.ppt"))
    checks.append(_mk("DOC-001", "documentation", "minor", "no legacy binary Office documents referenced",
                      not legacy, f"found={[str(p) for p in legacy][:3]}"))
    return checks


def check_design(root: Path) -> list[dict]:
    """Verify the design tokens actually pass WCAG AA contrast, computed from the
    blueprint that produced the site (not asserted by an agent)."""
    blueprint_path = root / "content" / "blueprint.json"
    if not blueprint_path.exists():
        return [_mk("DESIGN-000", "design", "minor", "design tokens available for contrast checks",
                    False, "content/blueprint.json not found")]
    from . import engines  # local import to keep verify.py dependency-light
    blueprint = util.jload(blueprint_path.read_text(encoding="utf-8"), {})
    tokens = blueprint.get("tokens", {})
    if not tokens:
        return [_mk("DESIGN-000", "design", "minor", "design tokens present in blueprint", False, "no tokens")]

    def ratio(fg, bg):
        return engines.contrast_ratio(fg, bg)

    checks = []
    body = ratio(tokens.get("text", "#000"), tokens.get("surface", "#fff"))
    checks.append(_mk("DESIGN-001", "design", "blocker", "body text on surface meets WCAG AA (>= 4.5:1)",
                      body >= 4.5, f"{body}:1 ({tokens.get('text')} on {tokens.get('surface')})",
                      "Adjust the palette's text/surface tokens until the measured ratio passes."))
    body_alt = ratio(tokens.get("text", "#000"), tokens.get("surface_alt", "#fff"))
    checks.append(_mk("DESIGN-002", "design", "major", "body text on alternate surface meets WCAG AA",
                      body_alt >= 4.5, f"{body_alt}:1"))
    link = ratio(tokens.get("link", tokens.get("primary", "#000")), tokens.get("surface", "#fff"))
    checks.append(_mk("DESIGN-003", "design", "major", "link colour meets WCAG AA on the page background",
                      link >= 4.5, f"{link}:1 (link {tokens.get('link')} on {tokens.get('surface')})"))
    on_primary = ratio(tokens.get("on_primary", "#000"), tokens.get("primary", "#fff"))
    checks.append(_mk("DESIGN-004", "design", "major", "button label meets WCAG AA on the primary fill",
                      on_primary >= 4.5, f"{on_primary}:1 (on_primary {tokens.get('on_primary')} on primary)"))
    muted = ratio(tokens.get("muted", "#888"), tokens.get("surface", "#fff"))
    checks.append(_mk("DESIGN-005", "design", "minor", "secondary text meets WCAG AA for large text (>= 3:1)",
                      muted >= 3.0, f"{muted}:1"))
    return checks


def full_verification(root: Path, run_id: str = "", project_id: str = "") -> dict:
    """Run everything and return a structured report with a quality gate verdict."""
    build = run_build(root)
    pages = parse_pages(root)
    checks = (
        [_mk("BUILD-001", "build", "blocker", "project build command succeeds", build["ok"],
             f"cmd={build['command']} exit={build['exit_code']} · {util.truncate(build['stdout'] or build['stderr'], 240)}",
             "Inspect the build output; every failure must be fixed, not waived.")]
        + check_application(pages, root)
        + check_accessibility(pages)
        + check_seo(pages, root)
        + check_security(pages, root)
        + check_performance(pages, root)
        + check_design(root)
        + check_data_and_docs(root)
    )
    blockers = [c for c in checks if not c["ok"] and c["severity"] == "blocker"]
    majors = [c for c in checks if not c["ok"] and c["severity"] == "major"]
    minors = [c for c in checks if not c["ok"] and c["severity"] == "minor"]
    by_category: dict[str, dict] = {}
    for c in checks:
        cat = by_category.setdefault(c["category"], {"passed": 0, "failed": 0})
        cat["passed" if c["ok"] else "failed"] += 1
    report = {
        "project_id": project_id, "run_id": run_id, "verified_at": util.now_iso(),
        "root": str(root), "build": build,
        "totals": {"checks": len(checks), "passed": sum(1 for c in checks if c["ok"]),
                   "failed": len(checks) - sum(1 for c in checks if c["ok"]),
                   "blockers": len(blockers), "majors": len(majors), "minors": len(minors)},
        "by_category": by_category,
        "checks": checks,
        "verdict": "pass" if (build["ok"] and not blockers and not majors) else
                   ("pass_with_warnings" if (build["ok"] and not blockers) else "fail"),
        "pages_checked": sorted(pages),
        "word_count": sum(len(re.findall(r"\w+", p["parser"].text)) for p in pages.values()),
    }
    return report


def write_report(report: dict, out_dir: Path) -> dict:
    out_dir.mkdir(parents=True, exist_ok=True)
    js = out_dir / "verification_report.json"
    txt = out_dir / "verification_report.txt"
    js.write_text(util.jdump(report) + "\n", encoding="utf-8")
    lines = [f"VERIFICATION REPORT  project={report.get('project_id')}  run={report.get('run_id')}",
             f"verified_at={report['verified_at']}  verdict={report['verdict'].upper()}",
             f"build: {'OK' if report['build']['ok'] else 'FAILED'} · {report['build']['command']} "
             f"(exit {report['build']['exit_code']}, {report['build']['duration_ms']} ms)",
             f"checks: {report['totals']['passed']}/{report['totals']['checks']} passed "
             f"(blockers={report['totals']['blockers']}, majors={report['totals']['majors']}, "
             f"minors={report['totals']['minors']})", ""]
    if not report["build"]["ok"]:
        lines += ["--- build output ---", report["build"]["stdout"][-1500:], report["build"]["stderr"][-1500:], ""]
    for c in report["checks"]:
        if not c["ok"]:
            lines.append(f"[FAIL:{c['severity']}] {c['code']} {c['title']} :: {c['evidence']}")
    lines += ["", "--- passed checks ---"]
    lines += [f"[ok] {c['code']} {c['title']}" for c in report["checks"] if c["ok"]]
    txt.write_text("\n".join(lines), encoding="utf-8")
    return {"json": str(js), "text": str(txt)}
