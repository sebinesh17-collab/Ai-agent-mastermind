"""Shared utilities: ids, time, hashing, JSON, safe paths, text helpers."""
from __future__ import annotations

import hashlib
import json
import os
import re
import secrets
import time
import unicodedata
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
# The data root is overridable so tests can run against an isolated database.
DATA_DIR = Path(os.environ.get("PLATFORM_DATA_DIR", str(ROOT / "data")))
PROJECTS_DIR = DATA_DIR / "projects"
EXPORT_DIR = DATA_DIR / "exports"
DB_PATH = DATA_DIR / "platform.db"
STATIC_DIR = Path(__file__).resolve().parent / "static"


def now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def now_ms() -> int:
    return int(time.time() * 1000)


def new_id(prefix: str = "") -> str:
    token = secrets.token_hex(6)
    stamp = time.strftime("%y%m%d%H%M%S")
    return f"{prefix}{stamp}-{token}" if prefix else f"{stamp}-{token}"


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_text(text: str) -> str:
    return sha256_bytes(text.encode("utf-8"))


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def jdump(obj) -> str:
    return json.dumps(obj, ensure_ascii=False, default=str)


def jload(text, default=None):
    if text in (None, ""):
        return default if default is not None else {}
    try:
        return json.loads(text)
    except Exception:
        return default if default is not None else {}


def slugify(text: str, max_len: int = 60) -> str:
    text = unicodedata.normalize("NFKD", str(text))
    text = re.sub(r"[^\w\s-]", "", text, flags=re.UNICODE).strip().lower()
    text = re.sub(r"[\s_]+", "-", text)
    text = re.sub(r"-{2,}", "-", text)
    return (text[:max_len].strip("-") or "item")


def safe_join(base: Path, *parts: str) -> Path:
    """Join path parts under base, refusing traversal outside base."""
    base = base.resolve()
    candidate = base.joinpath(*parts).resolve()
    if base != candidate and base not in candidate.parents:
        raise ValueError("path escapes workspace root")
    return candidate


def word_count(text: str) -> int:
    return len(re.findall(r"\S+", text or ""))


def truncate(text: str, limit: int = 240) -> str:
    text = (text or "").strip().replace("\n", " ")
    return text if len(text) <= limit else text[: limit - 1] + "\u2026"


def ensure_dirs() -> None:
    for d in (DATA_DIR, PROJECTS_DIR, EXPORT_DIR):
        d.mkdir(parents=True, exist_ok=True)


def human_bytes(n: int) -> str:
    for unit in ("B", "KB", "MB", "GB"):
        if n < 1024 or unit == "GB":
            return f"{n:.0f} {unit}" if unit == "B" else f"{n:.1f} {unit}"
        n /= 1024.0
    return f"{n:.1f} GB"


_MULTI_WS = re.compile(r"\s+")


def squeeze(text: str) -> str:
    return _MULTI_WS.sub(" ", (text or "").strip())


def first_sentences(text: str, n: int = 2) -> str:
    parts = re.split(r"(?<=[.!?])\s+", squeeze(text))
    return " ".join(parts[:n])


def env_flag(name: str, default: bool = False) -> bool:
    raw = os.environ.get(name)
    if raw is None:
        return default
    return raw.strip().lower() in {"1", "true", "yes", "on"}
